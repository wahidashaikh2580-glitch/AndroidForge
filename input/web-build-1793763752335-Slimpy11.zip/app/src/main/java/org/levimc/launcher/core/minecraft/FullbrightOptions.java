package org.levimc.launcher.core.minecraft;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;

/**
 * Fullbright: raises Minecraft's brightness option (gfx_gamma) in options.txt before launch.
 * The player's original value is saved next to it and restored when Fullbright is turned off.
 */
final class FullbrightOptions {
    private static final String OPTIONS = "options.txt";
    private static final String BACKUP = "slimpy_fullbright_backup.txt";
    private static final String KEY = "gfx_gamma";
    private static final String FULLBRIGHT_VALUE = "25.000000";
    private static final String ABSENT = "<absent>";

    private FullbrightOptions() {}

    static void sync(boolean enabled, File... gameDataDirs) throws IOException {
        IOException failure = null;
        for (File gameDataDir : gameDataDirs) {
            if (gameDataDir == null) continue;
            try {
                syncRoot(enabled, new File(gameDataDir, "minecraftpe"));
            } catch (IOException error) {
                if (failure == null) failure = error;
                else failure.addSuppressed(error);
            }
        }
        if (failure != null) throw failure;
    }

    private static void syncRoot(boolean enabled, File dir) throws IOException {
        File options = new File(dir, OPTIONS);
        File backup = new File(dir, BACKUP);
        if (!enabled && !backup.isFile()) return; // never touched, nothing to undo

        List<String> lines = options.isFile()
                ? new ArrayList<>(Files.readAllLines(options.toPath(), StandardCharsets.UTF_8))
                : new ArrayList<>();
        int index = -1;
        for (int i = 0; i < lines.size(); i++) {
            if (lines.get(i).startsWith(KEY + ":")) { index = i; break; }
        }

        if (enabled) {
            if (!dir.isDirectory() && !dir.mkdirs()) throw new IOException("Cannot create " + dir);
            if (!backup.isFile()) {
                String original = index >= 0 ? lines.get(index).substring(KEY.length() + 1) : ABSENT;
                writeAtomic(backup, original);
            }
            String line = KEY + ":" + FULLBRIGHT_VALUE;
            if (index >= 0) lines.set(index, line);
            else lines.add(line);
        } else {
            String original = new String(Files.readAllBytes(backup.toPath()), StandardCharsets.UTF_8).trim();
            if (index >= 0) {
                if (ABSENT.equals(original)) lines.remove(index);
                else lines.set(index, KEY + ":" + original);
            } else if (!ABSENT.equals(original) && options.isFile()) {
                lines.add(KEY + ":" + original);
            }
        }

        if (options.isFile() || !lines.isEmpty()) {
            writeAtomic(options, String.join("\n", lines) + "\n");
        }
        if (!enabled && !backup.delete()) throw new IOException("Cannot remove " + backup);
    }

    private static void writeAtomic(File target, String content) throws IOException {
        File tmp = new File(target.getParentFile(), target.getName() + ".slimpy_tmp");
        Files.write(tmp.toPath(), content.getBytes(StandardCharsets.UTF_8));
        Files.move(tmp.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING);
    }
}
