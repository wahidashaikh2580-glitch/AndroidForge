#pragma once

#include <slimpy/Export.hpp>
#include <cstddef>
#include <cstdint>
#include <string_view>

namespace slimpy::memory {

enum class SignatureId : std::uint16_t {
    VersionString,
    NormalTick,
    RenderItem,
    GetFov,
    ClientInstanceUpdate,
    ClientInstanceGetLocalPlayer,
    ContainerScreenControllerDtor,
    ContainerScreenControllerOpen,
    ChatScreenDtor,
    ChatScreenOpen,
    RenderLevel,
    TessellatorBegin,
    TessellatorColor,
    TessellatorVertex,
    MeshHelpersRenderMeshImmediately2,
    RenderMaterialGroupCommon,
    SurvivalModeStartDestroyBlock,
    GameModeStartDestroyBlock,
    GameModeStopDestroyBlock,
    SurvivalModeStartBuildBlock,
    GameModeStartBuildBlock,
    SurvivalModeUseItem,
    GameModeUseItem,
    SurvivalModeUseItemAsAttack,
    GameModeUseItemAsAttack,
    SurvivalModeUseItemOn,
    GameModeUseItemOn,
    SurvivalModeInteract,
    GameModeInteract,
    SurvivalModeAttack,
    GameModeAttackInternal,
    LevelGetHitResult,
    ContainerScreenControllerOnContainerSlotSelected,
    ContainerScreenControllerGetItemStack,
    ClientInstanceGetPacketSender,
    ItemInHandRendererRenderFirstPerson,
    ActorGetOffhandSlot,
    ItemInHandRendererRenderHand,
    ActorRenderDispatcherRender,
    ItemInHandRenderObject,
    ItemInHandRendererTransformWorldMatrixFromJson,
    ItemInHandRendererApplyDefaultItemTransforms,
    UpdatePlayerFromCamera,
    NameTagThirdPersonPatch,
    ContainerScreenControllerHandleSelectSlot,
    ContainerScreenControllerGetSelectedSlotInfo,
    Count
};

inline constexpr std::size_t SignatureCount = static_cast<std::size_t>(SignatureId::Count);

struct SignatureDefinition {
    SignatureId id;
    std::string_view pattern;
    std::string_view rtti{};
    std::size_t vtableSlot = 0;
};

SLIMPY_API bool resolveAll(std::string_view libraryName = "libminecraftpe.so");
SLIMPY_API std::uintptr_t resolve(SignatureId id);
SLIMPY_API void clear();

}
