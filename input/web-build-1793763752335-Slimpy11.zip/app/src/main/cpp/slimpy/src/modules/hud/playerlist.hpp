#pragma once
#include "../Module.hpp"
#include "hudtext.hpp"
#include <chrono>
#include <string>
#include <vector>

// Tab-style player list. Tracks the server's PlayerListPacket and shows the names while the key /
// on-screen shortcut is held (or toggled).
class PlayerListModule : public Module {
public:
    PlayerListModule();
    void onInit() override;
    void onDisable() override;
    void onFrame() override;
    void onKeybindEvent(const std::string& key, bool isDown) override;
    void loadConfig(const nlohmann::json& j) override;
    void saveConfig(nlohmann::json& j) override;

private:
    void rebuild();
    void hide();

    slimpy::hud::Style m_style;
    bool m_holdToShow = true;
    int m_rowsPerColumn = 12;

    bool m_active = false;
    bool m_drawn = false;
    bool m_hookReady = false;
    std::uint64_t m_version = ~0ull;
    // Two generations so text pointers handed to the renderer stay valid for one extra frame.
    std::vector<std::string> m_lines[2];
    int m_current = 0;
    std::string m_title;
};
