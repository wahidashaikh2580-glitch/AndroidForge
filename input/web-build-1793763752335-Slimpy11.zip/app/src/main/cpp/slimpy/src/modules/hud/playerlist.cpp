#include "playerlist.hpp"
#include "core/GameHooks.hpp"
#include "core/memory/Hooks.hpp"
#include <slimpy/events/EventBus.hpp>
#include <slimpy/sdk/Offsets.hpp>
#include <pl/memory/Vtable.hpp>
#include <algorithm>
#include <array>
#include <atomic>
#include <cctype>
#include <cstdint>
#include <map>
#include <mutex>

namespace {

namespace net = slimpy::sdk::offsets;

// Itanium typeinfo name of PacketHandlerDispatcherInstance<PlayerListPacket, false>. The handler's
// vtable slot comes from the SDK offsets. No byte signature, so it survives game updates unless the
// class is renamed.
constexpr const char* kDispatcherRtti = "31PacketHandlerDispatcherInstanceI16PlayerListPacketLb0EE";
constexpr std::size_t kMaxEntriesPerPacket = 1024;
constexpr std::size_t kMaxNameLength = 256;
constexpr std::size_t kMaxShown = 120;
constexpr auto kStaleAfter = std::chrono::seconds(5);

using Uuid = std::array<std::uint64_t, 2>;
using HandleFn = void (*)(void*, const void*, void*, void*);

HandleFn handleOriginal = nullptr;
slimpy::hooks::Handle handleHook = nullptr;
std::mutex rosterMutex;
std::map<Uuid, std::string> roster;
std::atomic<std::uint64_t> rosterVersion{0};

template <class T>
T readAt(const void* base, std::size_t offset) {
    return *reinterpret_cast<const T*>(reinterpret_cast<std::uintptr_t>(base) + offset);
}

// Reads the packet without modifying it. Every pointer is sanity-checked first.
void recordPacket(const void* packet) {
    const auto begin = readAt<std::uintptr_t>(packet, net::PlayerListPacket::mEntriesBegin);
    const auto end = readAt<std::uintptr_t>(packet, net::PlayerListPacket::mEntriesEnd);
    if (!begin || end < begin) return;
    const auto bytes = end - begin;
    if (bytes == 0 || bytes % net::PlayerListEntry::Size != 0) return;
    const auto count = bytes / net::PlayerListEntry::Size;
    if (count > kMaxEntriesPerPacket) return;

    std::lock_guard lock(rosterMutex);
    bool changed = false;
    for (std::size_t i = 0; i < count; ++i) {
        const void* entry = reinterpret_cast<const void*>(begin + i * net::PlayerListEntry::Size);
        const Uuid id{readAt<std::uint64_t>(entry, net::PlayerListEntry::mUuid),
                      readAt<std::uint64_t>(entry, net::PlayerListEntry::mUuid + 8)};
        const auto variant = readAt<std::uint32_t>(entry, net::PlayerListEntry::mVariantIndex);
        if (variant == static_cast<std::uint32_t>(net::PlayerListEntry::AddVariant)) {
            const auto& name = readAt<std::string>(entry, net::PlayerListEntry::mName);
            if (name.empty() || name.size() > kMaxNameLength) continue;
            roster[id] = name;
            changed = true;
        } else if (variant == static_cast<std::uint32_t>(net::PlayerListEntry::RemoveVariant)) {
            changed |= roster.erase(id) > 0;
        }
    }
    if (changed) rosterVersion.fetch_add(1, std::memory_order_release);
}

void handleDetour(void* self, const void* origin, void* callback, void* packetRef) {
    // packetRef is a std::shared_ptr<Packet>&; its first word is the Packet*.
    if (packetRef) {
        if (const void* packet = *reinterpret_cast<void**>(packetRef)) recordPacket(packet);
    }
    if (handleOriginal) handleOriginal(self, origin, callback, packetRef);
}

bool installHook() {
    if (handleHook) return true;
    const auto target = pl::memory::resolveVtableFunction(kDispatcherRtti,
        net::PacketHandlerDispatcher::HandlePacketVtableIndex, "libminecraftpe.so");
    if (!target) return false;
    handleHook = slimpy::hooks::install(reinterpret_cast<void*>(target),
        reinterpret_cast<void*>(handleDetour), reinterpret_cast<void**>(&handleOriginal));
    return handleHook != nullptr;
}

void clearRoster() {
    std::lock_guard lock(rosterMutex);
    if (roster.empty()) return;
    roster.clear();
    rosterVersion.fetch_add(1, std::memory_order_release);
}

bool hasLocalPlayer() {
    void* client = slimpy::core::gamehooks::clientInstance();
    if (!client) return false;
    auto table = *reinterpret_cast<void***>(client);
    if (!table) return false;
    using Fn = void* (*)(void*);
    return reinterpret_cast<Fn>(table[net::VTable::ClientInstanceGetLocalPlayer])(client) != nullptr;
}

// Drops the roster after the player has been out of a world for a while (the server will not resend
// it on the next join otherwise). Runs even while the module is off so the list is never stale.
void watchWorld() {
    static std::chrono::steady_clock::time_point lastCheck{};
    static std::chrono::steady_clock::time_point missingSince{};
    static bool inWorld = false;
    const auto now = std::chrono::steady_clock::now();
    if (now - lastCheck < std::chrono::milliseconds(500)) return;
    lastCheck = now;
    if (hasLocalPlayer()) {
        inWorld = true;
        missingSince = {};
        return;
    }
    if (!inWorld) return;
    if (missingSince == std::chrono::steady_clock::time_point{}) missingSince = now;
    if (now - missingSince >= kStaleAfter) {
        inWorld = false;
        clearRoster();
    }
}

bool lessNoCase(const std::string& a, const std::string& b) {
    const auto n = std::min(a.size(), b.size());
    for (std::size_t i = 0; i < n; ++i) {
        const int x = std::tolower(static_cast<unsigned char>(a[i]));
        const int y = std::tolower(static_cast<unsigned char>(b[i]));
        if (x != y) return x < y;
    }
    return a.size() < b.size();
}

}

PlayerListModule::PlayerListModule()
    : Module("Player List", "Shows the players on the server while the key or shortcut is held.") {
    m_style.posX = 120.0f;
    m_style.posY = 60.0f;
    m_style.size = 20.0f;
    m_style.background = true;
}

void PlayerListModule::onInit() {
    m_hookReady = installHook();
    slimpy::events::bus().subscribe<slimpy::events::FrameEvent>([](auto&) { watchWorld(); });
}

void PlayerListModule::onDisable() {
    m_active = false;
    hide();
}

void PlayerListModule::onKeybindEvent(const std::string&, bool isDown) {
    if (m_holdToShow) m_active = isDown;
    else if (isDown) m_active = !m_active;
}

void PlayerListModule::hide() {
    if (!m_drawn) return;
    m_drawn = false;
    submitDrawCommands(moduleId, {});
}

void PlayerListModule::rebuild() {
    std::vector<std::string> names;
    {
        std::lock_guard lock(rosterMutex);
        names.reserve(roster.size());
        for (const auto& [id, name] : roster) names.push_back(name);
        m_version = rosterVersion.load(std::memory_order_acquire);
    }
    std::sort(names.begin(), names.end(), lessNoCase);
    const std::size_t total = names.size();
    if (names.size() > kMaxShown) names.resize(kMaxShown);

    m_current ^= 1;
    m_lines[m_current] = std::move(names);
    m_title = "Players (" + std::to_string(total) + ")";
}

void PlayerListModule::onFrame() {
    if (!m_active) {
        hide();
        return;
    }
    if (!m_hookReady) {
        slimpy::hud::submit(moduleId, m_style, "Player list unavailable on this game version");
        m_drawn = true;
        return;
    }
    if (m_version != rosterVersion.load(std::memory_order_acquire)) rebuild();

    const auto& names = m_lines[m_current];
    const int rows = std::clamp(m_rowsPerColumn, 4, 30);
    const std::size_t columns = names.empty() ? 1 : (names.size() + rows - 1) / rows;
    const float size = m_style.size;
    const float rowH = size + 4.0f;
    const float pad = 8.0f;

    std::vector<float> colW(columns, 0.0f);
    for (std::size_t i = 0; i < names.size(); ++i)
        colW[i / rows] = std::max(colW[i / rows], slimpy::hud::textWidth(names[i], size));
    const float titleW = slimpy::hud::textWidth(m_title, size);
    float width = pad * 2.0f;
    for (float w : colW) width += w + pad;
    width = std::max(width, titleW + pad * 2.0f);
    const std::size_t shownRows = std::min<std::size_t>(names.size(), rows);
    const float height = pad * 2.0f + rowH * static_cast<float>(shownRows + 1);

    std::vector<PLModMenu_DrawCommand> cmds;
    cmds.reserve(names.size() + 2);
    if (m_style.background) {
        PLModMenu_DrawCommand bg = {};
        bg.type = PL_DRAW_RECT_FILLED;
        bg.x = m_style.posX; bg.y = m_style.posY; bg.w = width; bg.h = height;
        bg.color = static_cast<std::uint32_t>(m_style.backgroundOpacity * 255.0f) << 24;
        cmds.push_back(bg);
    }
    PLModMenu_DrawCommand title = {};
    title.type = PL_DRAW_TEXT;
    title.x = m_style.posX + pad; title.y = m_style.posY + pad; title.w = titleW; title.h = rowH;
    title.color = m_style.textColor;
    title.size = size;
    title.text = m_title.c_str();
    cmds.push_back(title);

    float x = m_style.posX + pad;
    for (std::size_t c = 0; c < columns; ++c) {
        for (std::size_t r = 0; r < static_cast<std::size_t>(rows); ++r) {
            const std::size_t i = c * rows + r;
            if (i >= names.size()) break;
            PLModMenu_DrawCommand t = {};
            t.type = PL_DRAW_TEXT;
            t.x = x; t.y = m_style.posY + pad + rowH * static_cast<float>(r + 1);
            t.w = colW[c]; t.h = rowH;
            t.color = m_style.textColor;
            t.size = size;
            t.text = names[i].c_str();
            cmds.push_back(t);
        }
        x += colW[c] + pad;
    }
    submitDrawCommands(moduleId, cmds);
    m_drawn = true;
}

void PlayerListModule::loadConfig(const nlohmann::json& j) {
    Module::loadConfig(j);
    m_style.load(j);
    m_holdToShow = j.value("m_holdToShow", m_holdToShow);
    m_rowsPerColumn = std::clamp(j.value("m_rowsPerColumn", m_rowsPerColumn), 4, 30);
}

void PlayerListModule::saveConfig(nlohmann::json& j) {
    Module::saveConfig(j);
    m_style.save(j);
    j["m_holdToShow"] = m_holdToShow;
    j["m_rowsPerColumn"] = m_rowsPerColumn;
}
