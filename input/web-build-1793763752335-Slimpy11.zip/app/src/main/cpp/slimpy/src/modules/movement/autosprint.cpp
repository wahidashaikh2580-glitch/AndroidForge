#include "autosprint.hpp"
#include "core/GameHooks.hpp"
#include <slimpy/sdk/Offsets.hpp>
#include <slimpy/sdk/input/MoveInput.hpp>
#include <slimpy/sdk/world/Actor.hpp>

namespace {

// The tick hook reports the player it ran for; only touch the local one.
void* localPlayerOf(void* client) {
    if (!client) return nullptr;
    auto table = *reinterpret_cast<void***>(client);
    if (!table) return nullptr;
    using Fn = void* (*)(void*);
    return reinterpret_cast<Fn>(table[slimpy::sdk::offsets::VTable::ClientInstanceGetLocalPlayer])(client);
}

}

AutoSprintModule::AutoSprintModule()
    : Module("Auto Sprint", "Sprints automatically while moving forward.") {}

void AutoSprintModule::onInit() {
    slimpy::events::bus().subscribe<slimpy::events::LocalPlayerPreTickEvent>(
        [this](auto& event) { onPreTick(event); });
}

void AutoSprintModule::onPreTick(slimpy::events::LocalPlayerPreTickEvent& event) {
    if (!enabled || !event.player) return;
    if (localPlayerOf(slimpy::core::gamehooks::clientInstance()) != event.player) return;

    auto* input = slimpy::sdk::moveInputComponent(event.player);
    if (!input) return;

    using Flag = MoveInputState::Flag;
    auto& state = input->mInputState;
    if (state.test(Flag::SneakDown) || state.test(Flag::SprintDown)) return;
    if (state.test(Flag::Up) || state.test(Flag::UpLeft) || state.test(Flag::UpRight)) {
        state.set(Flag::SprintDown, true);
    }
}
