#pragma once

namespace slimpy::fov {

// Installs the single engine GetFov hook (idempotent). Needs signatures to be resolved first.
bool install();

// World-camera FOV in degrees, as last returned by the engine (zoom already applied).
float worldFov();

// Divides the world-camera field of view. 1.0 = no zoom. Lock-free, safe from any thread.
void setZoom(float factor);

}
