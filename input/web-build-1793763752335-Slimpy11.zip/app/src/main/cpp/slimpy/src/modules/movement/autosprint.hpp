#pragma once
#include "../Module.hpp"
#include <slimpy/events/EventBus.hpp>

// Keeps the sprint input held while the player is pushing forward and not sneaking.
class AutoSprintModule : public Module {
public:
    AutoSprintModule();
    void onInit() override;

private:
    void onPreTick(slimpy::events::LocalPlayerPreTickEvent& event);
};
