#include "FovHook.hpp"
#include "core/memory/Hooks.hpp"
#include <slimpy/memory/Signatures.hpp>
#include <atomic>
#include <cmath>
#include <mutex>

namespace slimpy::fov {
namespace {

constexpr float kDegToRad = 0.017453292519943295f;

float (*original)(void*, float, int) = nullptr;
slimpy::hooks::Handle handle = nullptr;
std::mutex installMutex;
std::atomic<float> zoomFactor{1.0f};
std::atomic<float> lastFov{70.0f};

// `variable` is non-zero for the world camera (the same discriminator Motion Blur relied on).
float detour(void* self, float delta, int variable) {
    float value = original ? original(self, delta, variable) : 70.0f;
    if (!variable || !std::isfinite(value) || value <= 1.0f || value >= 179.0f) return value;
    const float zoom = zoomFactor.load(std::memory_order_relaxed);
    if (zoom > 1.0001f) {
        // Zoom divides the projection scale (tan of half-FOV), which keeps it perceptually linear.
        value = 2.0f * std::atan(std::tan(value * 0.5f * kDegToRad) / zoom) / kDegToRad;
    }
    lastFov.store(value, std::memory_order_relaxed);
    return value;
}

}

bool install() {
    std::lock_guard lock(installMutex);
    if (handle) return true;
    const auto address = slimpy::memory::resolve(slimpy::memory::SignatureId::GetFov);
    if (!address) return false;
    handle = slimpy::hooks::install(reinterpret_cast<void*>(address), reinterpret_cast<void*>(detour), reinterpret_cast<void**>(&original));
    return handle != nullptr;
}

float worldFov() {
    return lastFov.load(std::memory_order_relaxed);
}

void setZoom(float factor) {
    zoomFactor.store(factor < 1.0f ? 1.0f : factor, std::memory_order_relaxed);
}

}
