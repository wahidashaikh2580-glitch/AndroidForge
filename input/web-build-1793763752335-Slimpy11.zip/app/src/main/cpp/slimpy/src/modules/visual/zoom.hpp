#pragma once
#include "../Module.hpp"
#include <chrono>

// Narrows the world-camera FOV while active. Hold or toggle via the module's key / on-screen shortcut.
class ZoomModule : public Module {
public:
    ZoomModule();
    void onInit() override;
    void onDisable() override;
    void onFrame() override;
    void onKeybindEvent(const std::string& key, bool isDown) override;
    void loadConfig(const nlohmann::json& j) override;
    void saveConfig(nlohmann::json& j) override;

private:
    float m_zoomLevel = 4.0f;
    float m_smoothSpeed = 0.35f;
    bool m_holdToZoom = true;

    bool m_active = false;
    float m_current = 1.0f;
    std::chrono::steady_clock::time_point m_last{};
};
