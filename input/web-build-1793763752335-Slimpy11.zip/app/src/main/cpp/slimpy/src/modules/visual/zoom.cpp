#include "zoom.hpp"
#include "core/FovHook.hpp"
#include <algorithm>
#include <cmath>

namespace {
constexpr float kMinZoom = 1.1f;
constexpr float kMaxZoom = 10.0f;
// Smoothing rate (1/s) at m_smoothSpeed == 1.0; lower speeds ease more slowly.
constexpr float kMaxRate = 30.0f;
}

ZoomModule::ZoomModule()
    : Module("Zoom", "Zooms the world camera while the key or shortcut is held.") {}

void ZoomModule::onInit() {
    slimpy::fov::install();
}

void ZoomModule::onDisable() {
    m_active = false;
    m_current = 1.0f;
    slimpy::fov::setZoom(1.0f);
}

void ZoomModule::onKeybindEvent(const std::string&, bool isDown) {
    // Any trigger source (hardware key or on-screen shortcut) drives the zoom.
    if (m_holdToZoom) m_active = isDown;
    else if (isDown) m_active = !m_active;
}

void ZoomModule::onFrame() {
    const auto now = std::chrono::steady_clock::now();
    const float dt = m_last == std::chrono::steady_clock::time_point{}
        ? 0.0f : std::min(0.1f, std::chrono::duration<float>(now - m_last).count());
    m_last = now;

    const float target = m_active ? std::clamp(m_zoomLevel, kMinZoom, kMaxZoom) : 1.0f;
    if (m_current == target) return;
    const float t = 1.0f - std::exp(-dt * kMaxRate * std::clamp(m_smoothSpeed, 0.05f, 1.0f));
    m_current += (target - m_current) * t;
    if (std::abs(target - m_current) < 0.002f) m_current = target;
    slimpy::fov::setZoom(m_current);
}

void ZoomModule::loadConfig(const nlohmann::json& j) {
    Module::loadConfig(j);
    m_zoomLevel = std::clamp(j.value("m_zoomLevel", m_zoomLevel), kMinZoom, kMaxZoom);
    m_smoothSpeed = std::clamp(j.value("m_smoothSpeed", m_smoothSpeed), 0.05f, 1.0f);
    m_holdToZoom = j.value("m_holdToZoom", m_holdToZoom);
}

void ZoomModule::saveConfig(nlohmann::json& j) {
    Module::saveConfig(j);
    j["m_holdToZoom"] = m_holdToZoom;
    j["m_zoomLevel"] = m_zoomLevel;
    j["m_smoothSpeed"] = m_smoothSpeed;
}
