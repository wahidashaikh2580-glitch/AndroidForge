# Slimpy

Minimal MCPE (Minecraft Bedrock, Android, arm64-v8a) performance client.
Six features only: **Motion Blur, Block Overlay, FPS Counter (+ Unlock FPS), CPS Counter, View Model, Third-Person Nametag.**

Open this folder in Android Studio (Ladybug or newer, JDK 17, NDK 28.2.13676358).

## STATUS — stage 1 (read this first)

| Part | State |
|---|---|
| Native mod `libSlimpy.so` (`app/src/main/cpp/slimpy`) | **Written, never compiled.** 7 modules, 50 -> 7 trimmed. |
| App identity | applicationId `org.levimc.launcher` (see below), label "Slimpy", icon from supplied logo. |
| Launcher Java/Kotlin (221 files) | Game launches. `libSlimpy.so` is installed as a bundled mod (`ModManager.installBundledMod`) and loaded at launch. Rest is **still Levi code**, not yet stripped. In-app logo replaced with the supplied image. |
| Build | **Never built or run.** CI-ready packaging added; first real build will likely surface errors. |

### Building from a source ZIP (AndroidForge / CI)
The ZIP root is the Gradle project root (`settings.gradle`, `gradlew`, `app/`). It is built to work without git:
- The empty `preloader` / `libHttpClient` submodules are fetched from GitHub by CMake at configure time
  (`app/src/main/cpp/CMakeLists.txt`), tracking `main` of each repo, **not pinned** — if upstream moved, pin a commit there.
- `app/google-services.json` is a **placeholder** so the Google Services plugin doesn't fail; Firebase does nothing useful with it.
  Crashlytics mapping/symbol upload is disabled. Both go away in stage 2.
- nlohmann_json 3.11.3 and glm 1.0.1 are fetched (pinned). Needs network on the build machine.
- Needs JDK 17, Gradle 8.13 (wrapper), NDK 28.2.13676358, compileSdk 36. Pick the **debug** variant; release is unsigned.
- The AndroidForge repo itself could not be read, so its exact ZIP/workflow rules are unverified.

### Deliberate deviation: package and application ID are still `org.levimc.launcher`
The preloader/bridge look up Java classes and JNI symbols by full package name, and the closed prebuilt libs
(`libgxcore.so`, `libinbuiltmods.so`) were built for the Levi package. With `com.slimpy.client`, extracted Minecraft
libraries were dropped at launch (libc++_shared.so, then libHttpClient.Android.so missing). Until those closed libs are
replaced, the app ID stays; only the label and icon are Slimpy. **Uninstall the real Levi Launcher before installing.**

## Layout
- `app/src/main/cpp/slimpy/` — native mod. One file per feature in `src/modules/{visual,hud}`.
  - `visual/motionblur`, `visual/viewmodel`, `visual/thirdpersonnametag`, `visual/fpsunlocker` (shown as "Unlock FPS"), `visual/blockoverlay`
  - `hud/fpscounter`, `hud/cpscounter`, `hud/hudtext.hpp` (shared HUD draw helper)
  - `src/config` persists settings to `config.json` in the mod's config dir (debounced, written off the render thread).
  - `src/core/memory/Signatures.cpp` — trimmed to the 46 signatures these modules use.
  - Upstream: BedrockTools by RadiantByte, MIT (`LICENSE-BedrockTools-MIT.txt`).
- Launcher: Levi Launchroid (Apache-2.0, `LICENSE`).

## How the features work
- **FPS Counter**: counts frames, refreshes the text twice per second. **CPS Counter**: observes mouse-down events (never consumes them) in a 64-entry ring buffer; no allocation on the input path.
- **Unlock FPS**: sets `eglSwapInterval(0)` and optionally sleeps to a target FPS (0 = uncapped). The display, driver or compositor can still cap frame rate; this only removes VSync.
- **Block Overlay**: hooks the level render, reads the engine hit result, draws 12 edges via the game tessellator. Zero work when disabled apart from one branch in the hook. The block position is read from `HitResult+32` and **checked against the hit point at runtime**, falling back to a ray nudge if they disagree. The offset is inferred from struct layout, not verified on a device.
- **Motion Blur / View Model / Third-Person Nametag**: unchanged upstream implementations (not yet re-audited or optimised).

## Game version
Signatures target the version declared by the upstream mod (Minecraft `1.26.60.X`). Not re-validated.

## Stage 2 (needs compile feedback)
Remove from the launcher: Firebase/Crashlytics/Play Games/billing, Microsoft login and account code, CurseForge, news/changelog,
world editor + `worldtools` native lib + `libinbuiltmods.so` (closed binary, hard-codes the Levi package), Levi inbuilt mods and overlays;
replace `MainActivity` with a small version-select/launch screen; load `libSlimpy.so` directly from `MinecraftRuntimePreparer`;
rewrite strings (1100 lines, many Levi), drop non-English locales, then re-run a leftover-branding scan.

## Stage 2 changes (this revision)

Added (native, `libSlimpy.so`):
- **Zoom** (`modules/visual/zoom.*`) - hold/toggle via the module key or on-screen shortcut; level and smoothing in the menu. Shares one `GetFov` hook (`core/FovHook.*`) with Motion Blur.
- **Auto Sprint** (`modules/movement/autosprint.*`) - sets the sprint input while moving forward. Reads the game's entity registry through EnTT (fetched in CMake if the preloader does not provide it).

Fullbright and Tab list were not in this revision; they are covered in "Stage 3" below.

Removed: worlds/content/news/CurseForge/instances/about/quick-launch/mod-catalog screens, the update checker (it pointed at Levi's repo), Levi's built-in in-game mod list, the worldtools native lib, Play Games and Glide dependencies, personalize/updates/about settings tabs.

None of this has been compiled or run; build it and report any errors.

## Stage 3 changes (Fullbright + Player List)

- **Player List** (`modules/hud/playerlist.*`) - Tab-style list, shown while the module key / on-screen shortcut is held
  (or toggled, `Hold To Show` off). Hooks the PlayerListPacket handler through its RTTI vtable
  (`PacketHandlerDispatcherInstance<PlayerListPacket,false>`, slot 2 from `sdk/offsets/Network.hpp`), so it adds **no byte
  signature**. It only reads the packet, keeps a uuid->name roster, and clears it ~5 s after leaving a world. If the RTTI
  lookup fails on a game version, the module shows "Player list unavailable on this game version" instead of crashing.
- **Fullbright** (Settings -> Fullbright) - a launcher switch, not a native hook (there is no verified signature for the
  engine's light/gamma path). Before each launch it sets `gfx_gamma` in `options.txt` to a very high value and stores your
  original value in `slimpy_fullbright_backup.txt`; switching it off restores the original. Takes effect on the next launch.
  Code: `core/minecraft/FullbrightOptions.java`, called from `MinecraftRuntimePreparer.kt`.

Neither feature has been compiled with the Android toolchain or run on a device. The native file was syntax-checked only
against stub headers. Unverified assumptions: the RTTI type name / slot above, the PlayerListEntry offsets, and that the
game honours an out-of-range `gfx_gamma`.
