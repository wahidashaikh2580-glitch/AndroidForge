package com.slimpy.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import kotlinx.coroutines.*

// ── Colours ───────────────────────────────────────────────────────────────────
private object C {
    val BG        = Color.parseColor("#000000")
    val SURFACE   = Color.parseColor("#0D0D0D")
    val BORDER    = Color.parseColor("#1A1A1A")
    val ACCENT    = Color.parseColor("#FFFFFF")
    val DIM       = Color.parseColor("#444444")
    val TEXT      = Color.parseColor("#EEEEEE")
    val TEXT_DIM  = Color.parseColor("#666666")
    val ON_GREEN  = Color.parseColor("#00E676")
    val OFF_GREY  = Color.parseColor("#2A2A2A")
}

class MainActivity : Activity(), CoroutineScope by MainScope() {

    private val settingsFile get() = "${filesDir.absolutePath}/slimpy.bin"
    private val moduleCount  get() = NativeBridge.nativeModuleCount()

    // ── Toggle buttons — indexed by module id ────────────────────────────────
    private val toggleViews = mutableMapOf<Int, View>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // load libslimpy.so
        try { System.loadLibrary("slimpy") } catch (_: Throwable) {}

        // restore persisted settings
        NativeBridge.nativeLoadSettings(settingsFile)

        setContentView(buildRoot())
        window.decorView.setBackgroundColor(C.BG)
    }

    override fun onStop() {
        super.onStop()
        NativeBridge.nativeSaveSettings(settingsFile)
    }

    override fun onDestroy() {
        super.onDestroy()
        cancel() // cancel coroutines
    }

    // ── Root layout ──────────────────────────────────────────────────────────
    private fun buildRoot(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(C.BG)
        }

        root.addView(buildHeader())
        root.addView(buildDivider())

        val scroll = ScrollView(this).apply {
            setBackgroundColor(C.BG)
        }
        val moduleList = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, dp(24))
            setBackgroundColor(C.BG)
        }

        for (i in 0 until moduleCount) {
            moduleList.addView(buildModuleRow(i))
        }

        scroll.addView(moduleList)
        root.addView(scroll, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        root.addView(buildDivider())
        root.addView(buildFooter())

        return root
    }

    // ── Header: "SLIMPY" title + detect button ───────────────────────────────
    private fun buildHeader(): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(20), dp(20), dp(20), dp(16))
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(C.BG)
        }

        val title = TextView(this).apply {
            text = "SLIMPY"
            setTextColor(C.ACCENT)
            textSize = 22f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            letterSpacing = 0.15f
        }

        val spacer = View(this)
        val detectBtn = buildTextButton("DETECT MC") {
            runDetect()
        }

        row.addView(title)
        row.addView(spacer, LinearLayout.LayoutParams(0, 1, 1f))
        row.addView(detectBtn)

        return row
    }

    // ── Single module row ─────────────────────────────────────────────────────
    private fun buildModuleRow(id: Int): View {
        val name    = NativeBridge.nativeModuleName(id)
        val enabled = NativeBridge.nativeModuleEnabled(id)

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(20), dp(14), dp(20), dp(14))
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(C.BG)
            isClickable = true
            isFocusable = true
        }

        // subtle top border
        val wrapper = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(C.BG)
        }
        val topLine = View(this).apply {
            setBackgroundColor(C.BORDER)
        }
        wrapper.addView(topLine, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 1
        ))
        wrapper.addView(row)

        val nameView = TextView(this).apply {
            text = name
            setTextColor(C.TEXT)
            textSize = 15f
            typeface = Typeface.MONOSPACE
        }

        val spacer = View(this)

        val toggle = buildToggle(enabled)
        toggleViews[id] = toggle

        row.addView(nameView)
        row.addView(spacer, LinearLayout.LayoutParams(0, 1, 1f))
        row.addView(toggle)

        row.setOnClickListener {
            val nowOn = NativeBridge.nativeModuleToggle(id)
            updateToggle(toggle, nowOn)
            NativeBridge.nativeSaveSettings(settingsFile)
        }

        return wrapper
    }

    // ── Toggle pill ───────────────────────────────────────────────────────────
    private fun buildToggle(enabled: Boolean): TextView {
        return TextView(this).apply {
            text = if (enabled) "ON" else "OFF"
            setTextColor(if (enabled) C.ON_GREEN else C.TEXT_DIM)
            textSize = 12f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            letterSpacing = 0.1f
            setPadding(dp(10), dp(4), dp(10), dp(4))
            background = pillDrawable(if (enabled) C.ON_GREEN else C.DIM, 4f)
            gravity = Gravity.CENTER
        }
    }

    private fun updateToggle(view: View, enabled: Boolean) {
        (view as? TextView)?.apply {
            text = if (enabled) "ON" else "OFF"
            setTextColor(if (enabled) Color.BLACK else C.TEXT_DIM)
            background = pillDrawable(if (enabled) C.ON_GREEN else C.DIM, 4f)
        }
    }

    // ── Footer: hook self-test button + status line ───────────────────────────
    private fun buildFooter(): View {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), dp(20))
            setBackgroundColor(C.BG)
        }

        val statusView = TextView(this).apply {
            text = "ready"
            setTextColor(C.TEXT_DIM)
            textSize = 11f
            typeface = Typeface.MONOSPACE
        }

        val hookBtn = buildTextButton("LOADER SELF-TEST") {
            launch(Dispatchers.IO) {
                val result = NativeBridge.nativeHookSelfTest()
                withContext(Dispatchers.Main) {
                    statusView.text = result.lines().lastOrNull() ?: result
                    statusView.setTextColor(
                        if (result.contains("PASSED")) C.ON_GREEN else Color.parseColor("#FF5252")
                    )
                }
            }
        }

        col.addView(hookBtn)
        col.addView(statusView, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).also { it.topMargin = dp(8) })

        return col
    }

    // ── Detect Minecraft — IO coroutine, no ANR ───────────────────────────────
    private fun buildStatusToast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    private fun runDetect() {
        launch(Dispatchers.IO) {
            val detected = MinecraftImport.detectInstalled(this@MainActivity)
            val msg = if (!detected.installed) {
                detected.message
            } else {
                val result = MinecraftImport.importFromDetected(this@MainActivity, detected)
                if (result.ok && result.libDir != null && result.mainLibPath != null) {
                    val rc = NativeBridge.nativeImportMinecraft(result.mainLibPath.absolutePath)
                    if (rc == 0) "MC loaded OK — ${result.message}"
                    else "import staged but dlopen failed: ${NativeBridge.nativeLastError()}"
                } else {
                    result.message
                }
            }
            withContext(Dispatchers.Main) { buildStatusToast(msg) }
        }
    }

    // ── Manual APK pick (unchanged logic, still needed) ───────────────────────
    private fun pickApks() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        startActivityForResult(intent, REQ_PICK_APKS)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_PICK_APKS || resultCode != RESULT_OK) return
        val uris: List<Uri> = buildList {
            data?.clipData?.let { clip -> for (i in 0 until clip.itemCount) add(clip.getItemAt(i).uri) }
            data?.data?.let { add(it) }
        }
        if (uris.isEmpty()) return
        launch(Dispatchers.IO) {
            val result = MinecraftImport.importFromPickedUris(this@MainActivity, uris)
            val msg = if (result.ok && result.mainLibPath != null) {
                val rc = NativeBridge.nativeImportMinecraft(result.mainLibPath.absolutePath)
                if (rc == 0) "MC loaded OK" else "dlopen failed: ${NativeBridge.nativeLastError()}"
            } else result.message
            withContext(Dispatchers.Main) { buildStatusToast(msg) }
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    private fun dp(n: Int) = (n * resources.displayMetrics.density + 0.5f).toInt()

    private fun buildDivider() = View(this).apply {
        setBackgroundColor(C.BORDER)
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 1
        )
    }

    private fun buildTextButton(label: String, onClick: () -> Unit): TextView {
        return TextView(this).apply {
            text = label
            setTextColor(C.TEXT_DIM)
            textSize = 11f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            letterSpacing = 0.1f
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = pillDrawable(C.BORDER, 3f)
            gravity = Gravity.CENTER
            isClickable = true
            isFocusable = true
            setOnClickListener { onClick() }
        }
    }

    private fun pillDrawable(strokeColor: Int, radius: Float): android.graphics.drawable.GradientDrawable {
        return android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.RECTANGLE
            cornerRadius = dp(radius.toInt()).toFloat()
            setColor(Color.TRANSPARENT)
            setStroke(1, strokeColor)
        }
    }

    companion object {
        private const val REQ_PICK_APKS = 1001
    }
}
