# Slimpy

Compact MCPE (Minecraft Bedrock, Android, arm64-v8a) client with a minimal launcher.
Features: **Zoom, AutoSprint, Fullbright, Tab (player list)**, plus Motion Blur, Block Overlay, FPS Counter (+ Unlock FPS), CPS Counter, View Model, Third-Person Nametag.

Open this folder in Android Studio (JDK 17, NDK 28.2.13676358). Needs network at configure time (preloader, libHttpClient, nlohmann_json, glm, EnTT are fetched).

## STATUS (read first)
- **Never compiled or run.** Native code was syntax-checked with host clang against stubs; Java/Kotlin was checked with a custom reference checker only (no Android SDK available). Expect a few build errors on the first real build.
- Signatures target Minecraft 1.26.60.x and are **not verified on a device**. AutoSprint (MoveInputComponent via EnTT) and Tab (PlayerListPacket handler) rely on layouts/offsets inferred from existing headers.
- Fullbright is signature-free (screen-space additive blend), so it brightens the whole frame, including the UI layer if drawn after it; it is not true gamma.
- Package/application ID remains `org.levimc.launcher` (closed prebuilt libs and the preloader bind to it). Uninstall the real Levi Launcher first.

## New modules
- **Zoom**: hooks the FOV chain; hold-to-zoom key, configurable factor.
- **AutoSprint**: sets the sprint flag on the local player's move input while moving forward and not sneaking.
- **Fullbright**: post-level blend pass lightening dark areas.
- **Tab**: hooks the PlayerListPacket handler, keeps a mutex-guarded uuid->name list (max 40, 10 per column), shown while the key is held.

## Launcher changes
Removed: Firebase/Crashlytics/Play Games/Glide, CurseForge, news/changelog, world/content editors, instances manager, settings screens, mod catalog, localisations (English only), worldtools native lib, unused layouts/drawables/strings, blanket ProGuard keep. Kept: version select, APK import, Microsoft sign-in, Play Store ownership check, overlay/mod-menu bridge used by the native mod.
Launcher UI is a single compact screen (Launch, version, import APK, account).

## Layout
- `app/src/main/cpp/slimpy/` — native mod. One file per feature in `src/modules/{visual,hud}`.
  - `visual/motionblur`, `visual/viewmodel`, `visual/thirdpersonnametag`, `visual/fpsunlocker` (shown as "Unlock FPS"), `visual/blockoverlay`
  - `hud/fpscounter`, `hud/cpscounter`, `hud/hudtext.hpp` (shared HUD draw helper)
  - `src/config` persists settings to `config.json` in the mod's config dir (debounced, written off the render thread).
  - `src/core/memory/Signatures.cpp` — trimmed to the 46 signatures these modules use.
  - Upstream: BedrockTools by RadiantByte, MIT (`LICENSE-BedrockTools-MIT.txt`).
- Launcher: Levi Launchroid (Apache-2.0, `LICENSE`).

## How the features work
- **FPS Counter**: counts frames, refreshes the text twice per second. **CPS Counter**: observes mouse-down events (never consumes them) in a 64-entry ring buffer; no allocation on the input path.
- **Unlock FPS**: sets `eglSwapInterval(0)` and optionally sleeps to a target FPS (0 = uncapped). The display, driver or compositor can still cap frame rate; this only removes VSync.
- **Block Overlay**: hooks the level render, reads the engine hit result, draws 12 edges via the game tessellator. Zero work when disabled apart from one branch in the hook. The block position is read from `HitResult+32` and **checked against the hit point at runtime**, falling back to a ray nudge if they disagree. The offset is inferred from struct layout, not verified on a device.
- **Motion Blur / View Model / Third-Person Nametag**: upstream implementations.

## Game version
Signatures target the version declared by the upstream mod (Minecraft `1.26.60.X`). Not re-validated.

