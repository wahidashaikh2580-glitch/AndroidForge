-keepattributes Signature,InnerClasses,EnclosingMethod,*Annotation*,SourceFile,LineNumberTable

-keepclasseswithmembers,includedescriptorclasses class * {
    native <methods>;
}

# Classes bound by name from the native preloader / mod (JNI)
-keep,includedescriptorclasses class org.levimc.launcher.core.minecraft.** { *; }
-keep,includedescriptorclasses class org.levimc.launcher.util.NativeBridgeHelper { *; }
-keep,includedescriptorclasses class org.levimc.launcher.preloader.** { *; }
-keep,includedescriptorclasses class org.levimc.launcher.core.mods.** { *; }

-keep class org.levimc.launcher.R$drawable { *; }
-keep class org.levimc.launcher.** implements android.os.Parcelable {
    public static final android.os.Parcelable$Creator CREATOR;
}

# Gson-serialised models
-keep class org.levimc.launcher.settings.FeatureSettings {
    !static !transient <fields>;
    <init>();
}

-keep class org.levimc.launcher.core.auth.MsftAccountStore$MsftAccount {
    !static !transient <fields>;
    <init>();
}

-keep class org.levimc.launcher.core.versions.VersionProfileMetadata {
    !static !transient <fields>;
    <init>();
}

-dontwarn java.awt.**
-dontwarn javafx.**
-dontwarn javax.swing.**
-dontwarn com.sun.net.httpserver.**
-dontwarn java.net.http.**
-dontwarn reactor.**
-dontwarn org.reactivestreams.**
-dontwarn io.netty.**
-dontwarn net.lenni0451.commons.httpclient.executor.HttpClientExecutor
-dontwarn lombok.Generated
