package org.levimc.launcher.core.mods.inbuilt.overlay;

import android.app.Activity;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;

import org.json.JSONObject;
import org.levimc.launcher.core.mods.inbuilt.ExternalModBridge;
import org.levimc.launcher.core.mods.inbuilt.manager.InbuiltModManager;
import org.levimc.launcher.core.mods.inbuilt.model.ModIds;
import org.levimc.launcher.preloader.PreloaderInput;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * In-game overlay host: mod menu button + menu, native HUD layer, and the on-screen
 * buttons registered by the native Slimpy module (Zoom / Tab List).
 */
public class InbuiltOverlayManager {
    public interface HudEditorSelectionListener {
        void onHudEditorSelectionChanged(int currentSizeDp);
    }

    private static final int START_X = 50;
    private static final int START_Y = 150;

    private static volatile InbuiltOverlayManager instance;
    private final Activity activity;
    private final List<BaseOverlayButton> overlays = new ArrayList<>();
    private final Map<String, ExternalButtonOverlay> externalButtonOverlayMap = new HashMap<>();
    private final Map<String, BaseOverlayButton> modOverlayMap = new HashMap<>();
    private ModMenuButton modMenuButton;
    private ModMenuOverlay modMenuOverlay;
    private HudOverlay hudOverlay;
    private BaseOverlayButton selectedHudEditorOverlay;
    private String selectedDisplayModId;
    private HudEditorSelectionListener hudEditorSelectionListener;
    private boolean hudEditorMode;
    private boolean modMenuOpenedFromButton;
    private int modMenuShortcutHeld = KeyEvent.KEYCODE_UNKNOWN;
    private long lastVisibilityStateHash = Long.MIN_VALUE;
    private volatile boolean launcherHudHidden;

    public InbuiltOverlayManager(Activity activity) {
        this.activity = activity;
        instance = this;
    }

    public static InbuiltOverlayManager getInstance() {
        return instance;
    }

    private ModMenuOverlay getOrCreateModMenuOverlay() {
        if (modMenuOverlay == null) {
            modMenuOverlay = new ModMenuOverlay(activity);
            modMenuOverlay.setCallback(new ModMenuOverlay.ModMenuCallback() {
                @Override
                public void onModToggled(String modId, boolean enabled) {
                }

                @Override
                public void onButtonOpacityChanged(int opacity) {
                    if (modMenuButton != null) modMenuButton.refreshOpacity();
                }
            });
        }
        return modMenuOverlay;
    }

    public void showModMenu() {
        InbuiltModManager manager = InbuiltModManager.getInstance(activity);
        if (!manager.isModMenuEnabled()) return;
        activity.runOnUiThread(() -> {
            if (activity.isFinishing() || activity.isDestroyed()) return;
            modMenuOpenedFromButton = false;
            getOrCreateModMenuOverlay().show();
        });
    }

    public void hideModMenu() {
        activity.runOnUiThread(() -> {
            modMenuOpenedFromButton = false;
            if (modMenuOverlay != null && modMenuOverlay.isShowing()) modMenuOverlay.hide();
        });
    }

    public void toggleModMenuFromButton() {
        InbuiltModManager manager = InbuiltModManager.getInstance(activity);
        if (!manager.isModMenuEnabled()) return;
        if (manager.isPauseMenuOnly() && (!PreloaderInput.isPauseMenuOpen() || !PreloaderInput.isShowingMenu())) {
            hideModMenu();
            return;
        }
        activity.runOnUiThread(() -> {
            if (activity.isFinishing() || activity.isDestroyed()) return;
            ModMenuOverlay overlay = getOrCreateModMenuOverlay();
            if (overlay.isShowing()) {
                modMenuOpenedFromButton = false;
                overlay.hide();
            } else {
                modMenuOpenedFromButton = true;
                overlay.show();
            }
        });
    }

    public boolean isModMenuShowing() {
        return modMenuOverlay != null && modMenuOverlay.isShowing();
    }

    public void showEnabledOverlays() {
        InbuiltModManager manager = InbuiltModManager.getInstance(activity);
        if (!manager.isModMenuEnabled()) return;
        if (hudOverlay == null) hudOverlay = new HudOverlay(activity);
        hudOverlay.show();
        modMenuButton = new ModMenuButton(activity);
        modMenuButton.show(START_X, START_Y);
        refreshExternalButtons();
        refreshRuntimeVisibility();
    }

    public void setLauncherHudHidden(boolean hidden) {
        if (launcherHudHidden == hidden) return;
        launcherHudHidden = hidden;
        refreshRuntimeVisibility();
    }

    public void handleModToggle(String modId, boolean enabled) {
    }

    public boolean isModActive(String modId) {
        return false;
    }

    // ---- native on-screen buttons -------------------------------------------------------

    public void handleExternalModuleToggle(String moduleId, boolean enabled) {
        if (enabled) showExternalButtonsForModule(moduleId);
        else hideExternalButtonsForModule(moduleId);
    }

    private void refreshExternalButtons() {
        InbuiltModManager manager = InbuiltModManager.getInstance(activity);
        Set<String> enabledModules = new HashSet<>();
        int extCount = ExternalModBridge.getExternalModCount();
        for (int i = 0; i < extCount; i++) {
            try {
                JSONObject obj = new JSONObject(ExternalModBridge.getExternalModInfo(i));
                String moduleId = obj.optString("module_id", "");
                if (moduleId.isEmpty()) continue;
                boolean nativeEnabled = obj.optBoolean("enabled", false);
                boolean enabled = manager.resolveExternalModuleEnabled(moduleId, nativeEnabled);
                if (enabled != nativeEnabled) ExternalModBridge.toggleExternalMod(moduleId, enabled);
                if (enabled) enabledModules.add(moduleId);
            } catch (Exception ignored) {
            }
        }
        for (String moduleId : enabledModules) showExternalButtonsForModule(moduleId);
        List<ExternalButtonOverlay> stale = new ArrayList<>();
        for (ExternalButtonOverlay overlay : externalButtonOverlayMap.values()) {
            if (!enabledModules.contains(overlay.getModuleId())) stale.add(overlay);
        }
        for (ExternalButtonOverlay overlay : stale) removeExternalOverlay(overlay);
    }

    private void showExternalButtonsForModule(String moduleId) {
        if (moduleId == null || moduleId.isEmpty()) return;
        InbuiltModManager manager = InbuiltModManager.getInstance(activity);
        DisplayMetrics metrics = activity.getResources().getDisplayMetrics();
        int centerX = metrics.widthPixels / 2 - (int) (26 * metrics.density);
        int centerY = metrics.heightPixels / 2 - (int) (26 * metrics.density);
        int buttonCount = ExternalModBridge.getExternalButtonCount();
        for (int i = 0; i < buttonCount; i++) {
            ExternalModBridge.ExternalButton button = ExternalModBridge.getExternalButton(i);
            if (button == null || !moduleId.equals(button.moduleId)) continue;
            if (!button.defaultVisible || !button.moduleEnabled) continue;
            if (externalButtonOverlayMap.containsKey(button.buttonId)) continue;
            int savedX = manager.getOverlayPositionX(button.positionKey(), centerX);
            int savedY = manager.getOverlayPositionY(button.positionKey(), centerY);
            ExternalButtonOverlay overlay = new ExternalButtonOverlay(activity, button);
            overlay.show(savedX, savedY);
            overlays.add(overlay);
            externalButtonOverlayMap.put(button.buttonId, overlay);
            modOverlayMap.put(button.positionKey(), overlay);
        }
    }

    private void hideExternalButtonsForModule(String moduleId) {
        List<ExternalButtonOverlay> toHide = new ArrayList<>();
        for (ExternalButtonOverlay overlay : externalButtonOverlayMap.values()) {
            if (moduleId.equals(overlay.getModuleId())) toHide.add(overlay);
        }
        for (ExternalButtonOverlay overlay : toHide) removeExternalOverlay(overlay);
    }

    private void removeExternalOverlay(ExternalButtonOverlay overlay) {
        if (overlay == selectedHudEditorOverlay) selectHudEditorOverlay(null);
        overlay.hide();
        overlays.remove(overlay);
        externalButtonOverlayMap.remove(overlay.getButtonId());
        modOverlayMap.remove(overlay.getModId());
    }

    public void hideAllOverlays() {
        releaseModMenuShortcut();
    }

    // ---- input --------------------------------------------------------------------------

    public boolean handleModMenuShortcut(KeyEvent event) {
        int keyCode = event.getKeyCode();
        int action = event.getAction();
        if (keyCode == modMenuShortcutHeld) {
            if (action == KeyEvent.ACTION_UP) modMenuShortcutHeld = KeyEvent.KEYCODE_UNKNOWN;
            return action == KeyEvent.ACTION_DOWN || action == KeyEvent.ACTION_UP;
        }
        if (action != KeyEvent.ACTION_DOWN || event.getRepeatCount() != 0
                || (!event.hasNoModifiers() && !KeyEvent.isModifierKey(keyCode))) return false;
        InbuiltModManager manager = InbuiltModManager.getInstance(activity);
        if (!manager.isModMenuEnabled() || keyCode == KeyEvent.KEYCODE_UNKNOWN
                || keyCode != manager.getModMenuKeybind()) return false;
        if (manager.isPauseMenuOnly() && !isModMenuShowing() && !PreloaderInput.isPauseMenuOpen()) return false;
        modMenuShortcutHeld = keyCode;
        toggleModMenuFromButton();
        return true;
    }

    public void releaseModMenuShortcut() {
        modMenuShortcutHeld = KeyEvent.KEYCODE_UNKNOWN;
    }

    /** Module keybinds are handled natively; nothing to do on the Java side. */
    public boolean handleKeyEvent(KeyEvent event) {
        return false;
    }

    public void releaseKeybinds() {
    }

    public boolean handleScrollEvent(float scrollDelta) {
        if (launcherHudHidden && InbuiltModManager.getInstance(activity).isLauncherHudHideEnabled()) return false;
        for (ExternalButtonOverlay overlay : externalButtonOverlayMap.values()) {
            if (overlay.onScroll(scrollDelta)) return true;
        }
        return false;
    }

    public boolean handleTouchEvent(MotionEvent event) {
        return false;
    }

    public boolean handleMouseEvent(MotionEvent event) {
        return false;
    }

    public void applyConfigurationChanges(String modId) {
        BaseOverlayButton overlay = modOverlayMap.get(modId);
        if (overlay != null) overlay.applyConfigurationChanges();
    }

    // ---- HUD editor ---------------------------------------------------------------------

    public void setHudEditorMode(boolean active) {
        hudEditorMode = active;
        for (BaseOverlayButton overlay : overlays) overlay.setHudEditorMode(active);
        if (hudOverlay != null) hudOverlay.setHudEditorMode(active);
        if (modMenuButton != null) {
            if (active) {
                modMenuButton.setVisibility(View.GONE);
            } else {
                InbuiltModManager manager = InbuiltModManager.getInstance(activity);
                modMenuButton.show(manager.getOverlayPositionX(ModIds.MOD_MENU, START_X),
                        manager.getOverlayPositionY(ModIds.MOD_MENU, START_Y));
            }
        }
        refreshRuntimeVisibility();
        if (active) selectFirstHudEditorOverlay();
        else selectHudEditorOverlay(null);
    }

    public void setHudEditorSelectionListener(HudEditorSelectionListener listener) {
        hudEditorSelectionListener = listener;
        if (listener != null) listener.onHudEditorSelectionChanged(getSelectedHudEditorButtonSize());
    }

    public void selectHudEditorOverlay(BaseOverlayButton overlay) {
        if (!hudEditorMode && overlay != null) return;
        selectedDisplayModId = null;
        if (selectedHudEditorOverlay == overlay) {
            notifySelectionListener();
            return;
        }
        if (selectedHudEditorOverlay != null) selectedHudEditorOverlay.setHudEditorSelected(false);
        selectedHudEditorOverlay = overlay;
        if (selectedHudEditorOverlay != null) selectedHudEditorOverlay.setHudEditorSelected(true);
        notifySelectionListener();
    }

    public void selectHudEditorDisplay(String modId) {
        if (!hudEditorMode || modId == null) return;
        if (selectedHudEditorOverlay != null) {
            selectedHudEditorOverlay.setHudEditorSelected(false);
            selectedHudEditorOverlay = null;
        }
        selectedDisplayModId = modId;
        notifySelectionListener();
    }

    private void notifySelectionListener() {
        if (hudEditorSelectionListener != null) {
            hudEditorSelectionListener.onHudEditorSelectionChanged(getSelectedHudEditorButtonSize());
        }
    }

    public int getSelectedHudEditorButtonSize() {
        if (selectedHudEditorOverlay != null) return selectedHudEditorOverlay.getCurrentButtonSizeDp();
        if (selectedDisplayModId != null) {
            return InbuiltModManager.getInstance(activity).getOverlayButtonSize(selectedDisplayModId);
        }
        return 0;
    }

    public void setSelectedHudEditorButtonSize(int sizeDp) {
        InbuiltModManager manager = InbuiltModManager.getInstance(activity);
        if (selectedHudEditorOverlay != null) {
            manager.setOverlayButtonSize(selectedHudEditorOverlay.getOverlayConfigKey(), sizeDp);
            selectedHudEditorOverlay.applyConfigurationChanges();
        } else if (selectedDisplayModId != null) {
            manager.setOverlayButtonSize(selectedDisplayModId, sizeDp);
        }
    }

    private void selectFirstHudEditorOverlay() {
        if (selectedHudEditorOverlay != null) {
            selectedHudEditorOverlay.setHudEditorSelected(true);
            notifySelectionListener();
        } else if (selectedDisplayModId != null) {
            notifySelectionListener();
        } else {
            selectHudEditorOverlay(overlays.isEmpty() ? null : overlays.get(0));
        }
    }

    public void resetAllPositionsToCenter() {
        DisplayMetrics metrics = activity.getResources().getDisplayMetrics();
        int centerX = metrics.widthPixels / 2 - (int) (26 * metrics.density);
        int centerY = metrics.heightPixels / 2 - (int) (26 * metrics.density);
        InbuiltModManager manager = InbuiltModManager.getInstance(activity);
        for (Map.Entry<String, BaseOverlayButton> entry : modOverlayMap.entrySet()) {
            manager.setOverlayPosition(entry.getKey(), centerX, centerY);
            entry.getValue().updatePosition(centerX, centerY);
        }
        Set<String> explicitHudModules = new HashSet<>();
        ExternalModBridge.HudEditorElement[] hudElements = ExternalModBridge.getHudEditorElements();
        if (hudElements != null) {
            for (ExternalModBridge.HudEditorElement element : hudElements) {
                if (element == null || element.moduleId == null || element.positionKeyX == null || element.positionKeyY == null) continue;
                explicitHudModules.add(element.moduleId);
                float elementX = metrics.widthPixels * 0.5f - Math.max(1f, element.width) * 0.5f;
                float elementY = metrics.heightPixels * 0.5f - Math.max(1f, element.height) * 0.5f;
                ExternalModBridge.setExternalModConfig(element.moduleId, element.positionKeyX, String.valueOf(elementX));
                ExternalModBridge.setExternalModConfig(element.moduleId, element.positionKeyY, String.valueOf(elementY));
            }
        }
        ExternalModBridge.DrawCommand[] cmds = ExternalModBridge.getDrawCommands();
        if (cmds != null) {
            Set<String> processed = new HashSet<>();
            for (ExternalModBridge.DrawCommand cmd : cmds) {
                if (cmd.moduleId != null && !explicitHudModules.contains(cmd.moduleId) && processed.add(cmd.moduleId)) {
                    ExternalModBridge.setExternalModConfig(cmd.moduleId, "hudPosX", String.valueOf(centerX));
                    ExternalModBridge.setExternalModConfig(cmd.moduleId, "hudPosY", String.valueOf(centerY));
                }
            }
        }
    }

    // ---- visibility ---------------------------------------------------------------------

    public void refreshRuntimeVisibility() {
        lastVisibilityStateHash = Long.MIN_VALUE;
        tick();
    }

    public void tick() {
        InbuiltModManager manager = InbuiltModManager.getInstance(activity);
        boolean isPauseOnly = manager.isPauseMenuOnly();
        boolean isPauseOpen = PreloaderInput.isPauseMenuOpen();
        boolean isHudScreenOpen = PreloaderInput.isHudScreenOpen();
        boolean isShowingMenu = PreloaderInput.isShowingMenu();
        boolean menuButtonHidden = ExternalModBridge.isFloatingModMenuButtonHidden();
        boolean showGameOverlays = isHudScreenOpen && !isShowingMenu && !isPauseOpen;
        boolean hideLauncherOverlays = launcherHudHidden && manager.isLauncherHudHideEnabled();
        boolean inbuiltVisible = hudEditorMode || showGameOverlays;

        for (BaseOverlayButton overlay : overlays) {
            if (!hideLauncherOverlays && (inbuiltVisible || manager.isOverlayShowEverywhere(overlay.getOverlayConfigKey()))) {
                overlay.tick();
            }
        }

        long stateHash = manager.getOverlayVisibilityRevision();
        stateHash = 31L * stateHash + (hideLauncherOverlays ? 1L : 0L);
        stateHash = 31L * stateHash + (isPauseOnly ? 1L : 0L);
        stateHash = 31L * stateHash + (isPauseOpen ? 1L : 0L);
        stateHash = 31L * stateHash + (isHudScreenOpen ? 1L : 0L);
        stateHash = 31L * stateHash + (isShowingMenu ? 1L : 0L);
        stateHash = 31L * stateHash + (menuButtonHidden ? 1L : 0L);
        stateHash = 31L * stateHash + (hudEditorMode ? 1L : 0L);
        stateHash = 31L * stateHash + overlays.size();
        for (BaseOverlayButton overlay : overlays) stateHash = 31L * stateHash + System.identityHashCode(overlay);
        stateHash = 31L * stateHash + (modMenuButton == null ? 0L : System.identityHashCode(modMenuButton));
        stateHash = 31L * stateHash + (hudOverlay == null ? 0L : System.identityHashCode(hudOverlay));
        if (stateHash == lastVisibilityStateHash) return;
        lastVisibilityStateHash = stateHash;

        activity.runOnUiThread(() -> {
            if (modMenuButton != null) {
                int visibility = !hideLauncherOverlays && !menuButtonHidden && !hudEditorMode
                        && (!isPauseOnly || (isPauseOpen && isShowingMenu)) ? View.VISIBLE : View.GONE;
                modMenuButton.setVisibility(visibility);
                if (!hudEditorMode && visibility == View.GONE && modMenuOpenedFromButton && isModMenuShowing()) {
                    hideModMenu();
                }
            }
            if (hudOverlay != null) {
                int visibility = !hideLauncherOverlays && (hudOverlay.isHudEditorMode() || showGameOverlays)
                        ? View.VISIBLE : View.GONE;
                if (hudOverlay.getVisibility() != visibility) hudOverlay.setVisibility(visibility);
            }
            for (BaseOverlayButton overlay : overlays) {
                if (overlay.overlayView == null) continue;
                boolean visible = !hideLauncherOverlays
                        && (inbuiltVisible || manager.isOverlayShowEverywhere(overlay.getOverlayConfigKey()));
                int visibility = visible ? View.VISIBLE : View.GONE;
                if (overlay.overlayView.getVisibility() != visibility) overlay.overlayView.setVisibility(visibility);
            }
        });
    }
}
