package org.levimc.launcher.util;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

/** Fixed theme. The old wallpaper/accent customisation was removed; the API stays so callers need no changes. */
public class PersonalizationManager {
    public static final int ACCENT = 0xFF26A69A;

    public PersonalizationManager(Context context) {}

    public int getAccentColor() { return ACCENT; }
    public boolean hasBackgroundImage() { return false; }
    public static int getChangeGeneration() { return 0; }
    public static int getBackgroundEffectGeneration() { return 0; }

    public void applyToActivity(Activity activity) {}
    public void refreshBackgroundEffects(Activity activity) {}
    public void applyBackgroundImageEffects(ImageView view) {}
    public void applyAccentToView(View view, Context context) {}

    public void applySolidAccentText(TextView textView, int accentColor) {
        textView.getPaint().setShader(null);
        textView.setTextColor(accentColor);
    }
}
