package org.levimc.launcher.core.mods.inbuilt.overlay;

import org.levimc.launcher.R;

public class ModIconHelper {
    public static int getModIcon(String modId) {
        return R.drawable.ic_settings;
    }
}
