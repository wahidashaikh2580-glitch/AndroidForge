#pragma once
#include "../Module.hpp"
#include <atomic>

// Signature-free fullbright: a screen-space "screen blend" lift applied right
// after the world is drawn (before the HUD). No game memory is touched.
class FullbrightModule : public Module {
public:
    FullbrightModule();
    void onInit() override;
    void onEnable() override;
    void onDisable() override;
    void onMenuRegistered() override;
    void loadConfig(const nlohmann::json& j) override;
    void saveConfig(nlohmann::json& j) override;

    std::atomic<float> strength{0.5f};
    std::atomic_bool active{false};
};
