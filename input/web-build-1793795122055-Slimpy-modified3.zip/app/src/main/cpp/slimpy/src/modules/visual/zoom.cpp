#include "zoom.hpp"
#include "core/Fov.hpp"
#include "modules/ModuleUi.hpp"
#include <algorithm>
#include <chrono>
#include <cmath>

namespace {
using Clock = std::chrono::steady_clock;
ZoomModule* g_zoom = nullptr;
// Render-thread only.
float g_level = 1.0f;
Clock::time_point g_last{};
bool g_hasLast = false;
constexpr float kPi = 3.14159265358979f;
}

ZoomModule::ZoomModule() : Module("Zoom", "Hold the key or on-screen button to zoom in.") {
    keybind = 31; // Android KEYCODE_C
    g_zoom = this;
}

ZoomModule::~ZoomModule() {
    if (g_zoom == this) g_zoom = nullptr;
}

void ZoomModule::onInit() {
    slimpy::core::fov::addFilter(&ZoomModule::apply);
}

void ZoomModule::onDisable() {
    m_held.store(false, std::memory_order_relaxed);
}

void ZoomModule::onKeybindEvent(const std::string& key, bool isDown) {
    if (key == "keybind") m_held.store(isDown, std::memory_order_relaxed);
}

void ZoomModule::onMenuRegistered() {
    using namespace slimpy::ui;
    Schema schema;
    node(schema, "factor", "Zoom", NodeType::SliderFloat, "1.1", "10", "0.1", "How far the view zooms in.");
    node(schema, "smoothness", "Smoothness", NodeType::SliderInt, "0", "10", "1", "0 = instant.");
    node(schema, "keybind", "Key", NodeType::Keybind);
    publish(moduleId, schema, "Zoom");
    holdButton(moduleId, "slimpy.Zoom.Button", "Zoom", "Z", [this](bool down) {
        m_held.store(down && enabled, std::memory_order_relaxed);
    });
}

float ZoomModule::apply(float fov) {
    ZoomModule* zoom = g_zoom;
    if (!zoom) return fov;
    const bool want = zoom->enabled && zoom->m_held.load(std::memory_order_relaxed);
    const float target = want ? zoom->m_factor.load(std::memory_order_relaxed) : 1.0f;
    if (g_level == 1.0f && target == 1.0f) {
        g_hasLast = false;
        return fov;
    }
    const auto now = Clock::now();
    const float dt = g_hasLast ? std::min(std::chrono::duration<float>(now - g_last).count(), 0.1f) : 0.0f;
    g_last = now;
    g_hasLast = true;
    const float tau = static_cast<float>(zoom->m_smoothness.load(std::memory_order_relaxed)) * 0.03f;
    const float blend = tau <= 0.0f ? 1.0f : 1.0f - std::exp(-dt / tau);
    g_level += (target - g_level) * blend;
    if (std::fabs(target - g_level) < 0.002f) g_level = target;
    if (g_level <= 1.0005f) return fov;
    // Zoom the image, not the angle: halve the tangent of the half-angle.
    const float half = fov * kPi / 360.0f;
    return 2.0f * std::atan(std::tan(half) / g_level) * 180.0f / kPi;
}

void ZoomModule::loadConfig(const nlohmann::json& j) {
    Module::loadConfig(j);
    m_factor.store(std::clamp(j.value("factor", m_factor.load()), 1.1f, 10.0f));
    m_smoothness.store(std::clamp(j.value("smoothness", m_smoothness.load()), 0, 10));
}

void ZoomModule::saveConfig(nlohmann::json& j) {
    Module::saveConfig(j);
    j["factor"] = m_factor.load();
    j["smoothness"] = m_smoothness.load();
}
