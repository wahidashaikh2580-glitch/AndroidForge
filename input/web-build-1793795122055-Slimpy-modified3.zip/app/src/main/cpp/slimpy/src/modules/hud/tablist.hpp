#pragma once
#include "../Module.hpp"
#include <atomic>
#include <mutex>
#include <string>
#include <vector>
#include <pl/ModMenu.hpp>

// Hold-to-show list of the players the server has announced (PlayerListPacket).
class TabListModule : public Module {
public:
    TabListModule();
    ~TabListModule() override;
    void onInit() override;
    void onEnable() override;
    void onDisable() override;
    void onFrame() override;
    void onMenuRegistered() override;
    void onKeybindEvent(const std::string& key, bool isDown) override;
    void loadConfig(const nlohmann::json& j) override;
    void saveConfig(nlohmann::json& j) override;

    void onPlayerListPacket(const void* packet);
    void clearPlayers();

private:
    void rebuild(float surfaceWidth);
    void hide();

    std::mutex m_mutex;
    std::vector<std::pair<std::string, std::string>> m_players; // uuid bytes -> name
    std::vector<std::string> m_sorted;                          // render thread copy
    std::atomic_bool m_dirty{true};
    std::atomic_bool m_held{false};
    std::atomic<int> m_size{20};

    // Render thread only.
    std::vector<pl::modmenu::DrawCommand> m_commands;
    bool m_shown = false;
    float m_builtWidth = -1.0f;
    int m_builtSize = -1;
};
