#pragma once
#include "../Module.hpp"
#include <atomic>
#include <string>

// Hold-to-zoom. Rewrites the world FOV through the shared GetFov hook.
class ZoomModule : public Module {
public:
    ZoomModule();
    ~ZoomModule() override;
    void onInit() override;
    void onDisable() override;
    void onMenuRegistered() override;
    void onKeybindEvent(const std::string& key, bool isDown) override;
    void loadConfig(const nlohmann::json& j) override;
    void saveConfig(nlohmann::json& j) override;

    static float apply(float fovDegrees);

private:
    std::atomic_bool m_held{false};
    std::atomic<float> m_factor{4.0f};
    std::atomic<int> m_smoothness{5};
};
