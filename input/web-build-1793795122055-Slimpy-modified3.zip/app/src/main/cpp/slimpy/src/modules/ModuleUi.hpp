#pragma once
// Small helpers shared by modules that need a menu schema or an on-screen hold button.
#include "ModuleRegistry.hpp"
#include "core/Runtime.hpp"
#include <pl/ModMenu.hpp>
#include <pl/ModMenuConfig.hpp>
#include <functional>
#include <string>
#include <string_view>

namespace slimpy::ui {

using Schema = pl::modmenu::ConfigSchemaBuilder;
using NodeType = pl::modmenu::ConfigControlTypeV2;

inline void node(Schema& schema, const char* key, const char* title, NodeType type,
                 const char* low = "", const char* high = "", const char* step = "", const char* description = "") {
    pl::modmenu::ConfigNodeV2 n;
    n.id = key;
    n.key = key;
    n.title = title;
    n.description = description;
    n.category = "main";
    n.type = type;
    n.minValue = low;
    n.maxValue = high;
    n.step = step;
    schema.node(std::move(n));
}

inline void publish(std::string_view moduleId, Schema& schema, const char* title) {
    schema.defaultCategory("main").category("main", title);
    pl::modmenu::setConfigSchemaJson(moduleId, schema.toJson());
}

// On-screen button that reports held / released (touch alternative to a key).
inline void holdButton(const std::string& moduleId, const char* buttonId, const char* name,
                       const char* label, std::function<void(bool)> onHold) {
    pl::modmenu::ButtonBuilder(buttonId, name)
        .moduleId(moduleId)
        .modId(slimpy::core::Runtime::get().modId())
        .label(label)
        .behavior(pl::modmenu::ButtonBehavior::Hold)
        .onEvent([onHold = std::move(onHold)](std::string_view, pl::modmenu::ButtonEvent event, float) {
            if (event == pl::modmenu::ButtonEvent::Down) onHold(true);
            else if (event == pl::modmenu::ButtonEvent::Up) onHold(false);
        })
        .registerButton();
}

}
