#include "autosprint.hpp"
#include "modules/ModuleUi.hpp"
#include <slimpy/events/EventBus.hpp>
#include <slimpy/sdk/input/MoveInput.hpp>

namespace {
AutoSprintModule* g_module = nullptr;

void onPreTick(slimpy::events::LocalPlayerPreTickEvent& event) {
    if (!g_module || !g_module->enabled) return;
    auto* input = slimpy::sdk::moveInputComponent(event.player);
    if (!input) return;
    using Flag = MoveInputState::Flag;
    auto& state = input->mInputState;
    if (state.test(Flag::SneakDown) || input->mFlagValues.test(static_cast<std::size_t>(MoveInputComponent::Flag::Sneaking))) return;
    const bool forward = state.test(Flag::Up) || state.mAnalogMoveVector.y > 0.3f;
    if (!forward) return;
    state.set(Flag::SprintDown, true);
    input->mRawInputState.set(Flag::SprintDown, true);
}
}

AutoSprintModule::AutoSprintModule() : Module("Auto Sprint", "Sprints automatically while moving forward.") {
    g_module = this;
}

void AutoSprintModule::onInit() {
    slimpy::events::bus().subscribe<slimpy::events::LocalPlayerPreTickEvent>(onPreTick);
}
