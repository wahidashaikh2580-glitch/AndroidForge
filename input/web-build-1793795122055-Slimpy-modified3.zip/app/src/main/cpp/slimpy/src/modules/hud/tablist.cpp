#include "tablist.hpp"
#include "core/memory/Hooks.hpp"
#include "modules/hud/hudtext.hpp"
#include "modules/ModuleUi.hpp"
#include <slimpy/events/EventBus.hpp>
#include <slimpy/memory/Signatures.hpp>
#include <slimpy/sdk/Offsets.hpp>
#include <algorithm>
#include <cctype>
#include <chrono>
#include <cstring>

namespace {
namespace net = slimpy::sdk::offsets;
using Clock = std::chrono::steady_clock;

TabListModule* g_module = nullptr;

// PacketHandlerDispatcherInstance<PlayerListPacket>::handle(
//     const NetworkIdentifier&, NetEventCallback&, std::shared_ptr<Packet>&) const
// All reference arguments arrive as pointers; the shared_ptr's first word is the Packet*.
using HandleFn = void (*)(void*, void*, void*, void*);
HandleFn g_original = nullptr;
slimpy::hooks::Handle g_hook = nullptr;

void handleDetour(void* self, void* networkId, void* callback, void* packetRef) {
    if (g_module && packetRef) {
        const void* packet = *reinterpret_cast<void* const*>(packetRef);
        if (packet) g_module->onPlayerListPacket(packet); // read before the original may consume it
    }
    if (g_original) g_original(self, networkId, callback, packetRef);
}

// libc++ std::string: bit 0 of the first byte set = heap layout.
bool readName(const std::byte* string, std::string& out) {
    const auto first = static_cast<unsigned>(std::to_integer<unsigned char>(string[0]));
    const char* data;
    std::size_t length;
    if (first & 1u) {
        length = *reinterpret_cast<const std::size_t*>(string + 8);
        data = *reinterpret_cast<const char* const*>(string + 16);
    } else {
        length = first >> 1;
        data = reinterpret_cast<const char*>(string + 1);
    }
    if (!data || length == 0 || length > 48) return false;
    out.assign(data, length);
    return true;
}

std::string lower(const std::string& value) {
    std::string out = value;
    for (auto& c : out) c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
    return out;
}

constexpr std::size_t kMaxShown = 40;
constexpr std::size_t kPerColumn = 10;
}

TabListModule::TabListModule() : Module("Tab List", "Hold the key or button to see who is online.") {
    keybind = 61; // Android KEYCODE_TAB
    g_module = this;
}

TabListModule::~TabListModule() {
    if (g_module == this) g_module = nullptr;
    if (g_hook) slimpy::hooks::remove(g_hook);
    g_hook = nullptr;
}

void TabListModule::onInit() {
    using slimpy::memory::SignatureId;
    if (!g_hook) {
        const auto target = slimpy::memory::resolve(SignatureId::PlayerListPacketHandler);
        if (target) g_hook = slimpy::hooks::install(reinterpret_cast<void*>(target), reinterpret_cast<void*>(handleDetour), reinterpret_cast<void**>(&g_original));
    }
    // Drop the list once the local player has been gone for a few seconds
    // (a single null frame during a dimension change must not wipe it).
    slimpy::events::bus().subscribe<slimpy::events::ClientInstanceUpdateEvent>([this](auto& event) {
        static Clock::time_point goneSince{};
        static bool gone = false;
        void* client = event.clientInstance;
        void* player = nullptr;
        if (client) {
            auto table = *reinterpret_cast<void***>(client);
            using Fn = void* (*)(void*);
            if (table) player = reinterpret_cast<Fn>(table[slimpy::sdk::offsets::VTable::ClientInstanceGetLocalPlayer])(client);
        }
        if (player) { gone = false; return; }
        if (!gone) { gone = true; goneSince = Clock::now(); return; }
        if (Clock::now() - goneSince > std::chrono::seconds(3)) { clearPlayers(); goneSince = Clock::now(); }
    });
}

void TabListModule::onEnable() {
    m_shown = false;
    m_builtWidth = -1.0f;
    hide();
}

void TabListModule::onDisable() {
    m_held.store(false, std::memory_order_relaxed);
    hide();
}

void TabListModule::hide() {
    if (m_commands.empty() && !m_shown) return;
    m_commands.clear();
    m_shown = false;
    pl::modmenu::submitDrawCommands(moduleId, std::span<const pl::modmenu::DrawCommand>{});
}

void TabListModule::onKeybindEvent(const std::string& key, bool isDown) {
    if (key == "keybind") m_held.store(isDown, std::memory_order_relaxed);
}

void TabListModule::onMenuRegistered() {
    using namespace slimpy::ui;
    Schema schema;
    node(schema, "textSize", "Text Size", NodeType::SliderInt, "10", "40", "1");
    node(schema, "keybind", "Key", NodeType::Keybind);
    publish(moduleId, schema, "Tab List");
    holdButton(moduleId, "slimpy.TabList.Button", "Tab List", "Tab", [this](bool down) {
        m_held.store(down && enabled, std::memory_order_relaxed);
    });
}

void TabListModule::clearPlayers() {
    {
        std::lock_guard lock(m_mutex);
        if (m_players.empty()) return;
        m_players.clear();
    }
    m_dirty.store(true, std::memory_order_release);
}

void TabListModule::onPlayerListPacket(const void* packet) {
    const auto base = reinterpret_cast<std::uintptr_t>(packet);
    const auto begin = *reinterpret_cast<const std::uintptr_t*>(base + net::PlayerListPacket::mEntriesBegin);
    const auto end = *reinterpret_cast<const std::uintptr_t*>(base + net::PlayerListPacket::mEntriesEnd);
    if (!begin || end < begin) return;
    const auto bytes = end - begin;
    if (bytes % net::PlayerListEntry::Size != 0 || bytes / net::PlayerListEntry::Size > 1024) return; // layout mismatch
    bool changed = false;
    std::string name;
    std::lock_guard lock(m_mutex);
    for (auto entry = begin; entry < end; entry += net::PlayerListEntry::Size) {
        const auto* raw = reinterpret_cast<const std::byte*>(entry);
        const std::string uuid(reinterpret_cast<const char*>(raw + net::PlayerListEntry::mUuid), 16);
        const auto variant = *reinterpret_cast<const std::int32_t*>(raw + net::PlayerListEntry::mVariantIndex);
        auto found = std::find_if(m_players.begin(), m_players.end(), [&](const auto& p) { return p.first == uuid; });
        if (variant == net::PlayerListEntry::RemoveVariant) {
            if (found != m_players.end()) { m_players.erase(found); changed = true; }
        } else if (variant == net::PlayerListEntry::AddVariant && readName(raw + net::PlayerListEntry::mName, name)) {
            if (found == m_players.end()) { m_players.emplace_back(uuid, name); changed = true; }
            else if (found->second != name) { found->second = name; changed = true; }
        }
    }
    if (changed) m_dirty.store(true, std::memory_order_release);
}

void TabListModule::onFrame() {
    if (!m_held.load(std::memory_order_relaxed)) {
        hide();
        return;
    }
    const float width = pl::modmenu::getHudSurfaceSize().width;
    const int size = m_size.load(std::memory_order_relaxed);
    if (m_dirty.exchange(false, std::memory_order_acq_rel) || !m_shown || width != m_builtWidth || size != m_builtSize) {
        {
            std::lock_guard lock(m_mutex);
            m_sorted.clear();
            for (const auto& player : m_players) m_sorted.push_back(player.second);
        }
        std::sort(m_sorted.begin(), m_sorted.end(), [](const std::string& a, const std::string& b) { return lower(a) < lower(b); });
        rebuild(width);
        m_builtWidth = width;
        m_builtSize = size;
        m_shown = true;
        pl::modmenu::submitDrawCommands(moduleId, m_commands);
    }
}

void TabListModule::rebuild(float surfaceWidth) {
    using pl::modmenu::DrawCommand;
    const float size = static_cast<float>(m_size.load(std::memory_order_relaxed));
    const float pad = size * 0.5f, rowHeight = size + 4.0f, gap = size;
    const std::size_t count = std::min(m_sorted.size(), kMaxShown);
    const std::size_t columns = std::max<std::size_t>(1, (count + kPerColumn - 1) / kPerColumn);
    const std::string title = "Players (" + std::to_string(m_sorted.size()) + ")";

    std::vector<float> widths(columns, 0.0f);
    for (std::size_t i = 0; i < count; ++i) widths[i / kPerColumn] = std::max(widths[i / kPerColumn], slimpy::hud::textWidth(m_sorted[i], size));
    float total = pad * 2 + gap * (columns - 1);
    for (float w : widths) total += w;
    total = std::max(total, slimpy::hud::textWidth(title, size) + pad * 2);
    const std::size_t rows = std::min(count, kPerColumn);
    const float height = pad * 2 + rowHeight * (rows + 1);
    const float x0 = std::max(0.0f, (surfaceWidth - total) * 0.5f), y0 = 12.0f;

    m_commands.clear();
    m_commands.reserve(count + 2);
    DrawCommand bg;
    bg.type = pl::modmenu::DrawCommandType::RectFilled;
    bg.x = x0; bg.y = y0; bg.w = total; bg.h = height; bg.color = 0xA0000000u;
    m_commands.push_back(std::move(bg));
    auto text = [&](float x, float y, float w, const std::string& value, std::uint32_t color) {
        DrawCommand cmd;
        cmd.type = pl::modmenu::DrawCommandType::Text;
        cmd.x = x; cmd.y = y; cmd.w = w; cmd.h = rowHeight; cmd.size = size; cmd.color = color;
        cmd.text = value;
        m_commands.push_back(std::move(cmd));
    };
    text(x0 + pad, y0 + pad, total - pad * 2, title, 0xFFFFD34Eu);
    float x = x0 + pad;
    for (std::size_t column = 0; column < columns; ++column) {
        for (std::size_t row = 0; row < kPerColumn; ++row) {
            const std::size_t index = column * kPerColumn + row;
            if (index >= count) break;
            text(x, y0 + pad + rowHeight * (row + 1), widths[column], m_sorted[index], 0xFFFFFFFFu);
        }
        x += widths[column] + gap;
    }
}

void TabListModule::loadConfig(const nlohmann::json& j) {
    Module::loadConfig(j);
    m_size.store(std::clamp(j.value("textSize", m_size.load()), 10, 40));
    m_dirty.store(true, std::memory_order_release);
}

void TabListModule::saveConfig(nlohmann::json& j) {
    Module::saveConfig(j);
    j["textSize"] = m_size.load();
}
