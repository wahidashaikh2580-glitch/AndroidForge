#include "Fov.hpp"
#include "memory/Hooks.hpp"
#include <slimpy/memory/Signatures.hpp>
#include <array>
#include <atomic>
#include <cmath>
#include <mutex>

namespace slimpy::core::fov {
namespace {

using GetFovFn = float (*)(void*, float, int);
GetFovFn original = nullptr;
slimpy::hooks::Handle handle = nullptr;
std::mutex registration;
std::array<Filter, 4> filters{};
std::array<Observer, 4> observers{};
std::atomic_size_t filterCount{0};
std::atomic_size_t observerCount{0};

float detour(void* self, float delta, int variable) {
    float value = original ? original(self, delta, variable) : 70.0f;
    // `variable` marks the world camera FOV; other callers (hand, UI) pass 0.
    if (!variable || !std::isfinite(value) || value <= 1.0f || value >= 179.0f) return value;
    const auto filterTotal = filterCount.load(std::memory_order_acquire);
    for (std::size_t i = 0; i < filterTotal; ++i) value = filters[i](value);
    const auto observerTotal = observerCount.load(std::memory_order_acquire);
    for (std::size_t i = 0; i < observerTotal; ++i) observers[i](value);
    return value;
}

bool install() {
    if (handle) return true;
    const auto target = slimpy::memory::resolve(slimpy::memory::SignatureId::GetFov);
    if (!target) return false;
    handle = slimpy::hooks::install(reinterpret_cast<void*>(target), reinterpret_cast<void*>(detour), reinterpret_cast<void**>(&original));
    return handle != nullptr;
}

template <class Fn, std::size_t N>
bool add(std::array<Fn, N>& list, std::atomic_size_t& count, Fn fn) {
    if (!fn) return false;
    std::lock_guard lock(registration);
    const auto n = count.load(std::memory_order_relaxed);
    if (n >= N || !install()) return false;
    list[n] = fn;
    count.store(n + 1, std::memory_order_release);
    return true;
}

}

bool addFilter(Filter filter) { return add(filters, filterCount, filter); }
bool addObserver(Observer observer) { return add(observers, observerCount, observer); }

void uninstall() {
    std::lock_guard lock(registration);
    if (handle) slimpy::hooks::remove(handle);
    handle = nullptr;
    filterCount.store(0, std::memory_order_release);
    observerCount.store(0, std::memory_order_release);
}

}
