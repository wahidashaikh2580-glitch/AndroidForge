#pragma once
#include "../Module.hpp"

// Keeps sprint held while moving forward (not sneaking).
class AutoSprintModule : public Module {
public:
    AutoSprintModule();
    void onInit() override;
};
