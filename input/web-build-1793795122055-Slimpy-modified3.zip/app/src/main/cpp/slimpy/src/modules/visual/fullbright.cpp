#include "fullbright.hpp"
#include "core/RenderLevel.hpp"
#include "modules/ModuleUi.hpp"
#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <algorithm>

namespace {

FullbrightModule* g_module = nullptr;

// Render-thread state. GL objects are created on first use and released on the
// first frame after the module is turned off.
struct Gl {
    GLuint program = 0;
    GLint strengthLocation = -1;
    EGLContext context = EGL_NO_CONTEXT;
} g_gl;

constexpr const char* kVertex =
    "#version 300 es\n"
    "void main(){vec2 p=vec2(float((gl_VertexID<<1)&2),float(gl_VertexID&2));"
    "gl_Position=vec4(p*2.0-1.0,0.0,1.0);}\n";
constexpr const char* kFragment =
    "#version 300 es\nprecision mediump float;uniform float u_s;out vec4 o;"
    "void main(){o=vec4(vec3(u_s),1.0);}\n";

GLuint compile(GLenum type, const char* source) {
    GLuint shader = glCreateShader(type);
    glShaderSource(shader, 1, &source, nullptr);
    glCompileShader(shader);
    GLint ok = 0;
    glGetShaderiv(shader, GL_COMPILE_STATUS, &ok);
    if (!ok) { glDeleteShader(shader); return 0; }
    return shader;
}

bool build() {
    GLuint vs = compile(GL_VERTEX_SHADER, kVertex);
    GLuint fs = compile(GL_FRAGMENT_SHADER, kFragment);
    if (!vs || !fs) {
        if (vs) glDeleteShader(vs);
        if (fs) glDeleteShader(fs);
        return false;
    }
    GLuint program = glCreateProgram();
    glAttachShader(program, vs);
    glAttachShader(program, fs);
    glLinkProgram(program);
    glDeleteShader(vs);
    glDeleteShader(fs);
    GLint ok = 0;
    glGetProgramiv(program, GL_LINK_STATUS, &ok);
    if (!ok) { glDeleteProgram(program); return false; }
    g_gl.program = program;
    g_gl.strengthLocation = glGetUniformLocation(program, "u_s");
    g_gl.context = eglGetCurrentContext();
    return true;
}

void release() {
    if (g_gl.program && g_gl.context == eglGetCurrentContext()) glDeleteProgram(g_gl.program);
    g_gl = {};
}

void post(void*, void*, void*) {
    FullbrightModule* module = g_module;
    if (!module) return;
    if (!module->active.load(std::memory_order_acquire)) {
        if (g_gl.program) release();
        return;
    }
    EGLContext context = eglGetCurrentContext();
    EGLSurface surface = eglGetCurrentSurface(EGL_DRAW);
    EGLDisplay display = eglGetCurrentDisplay();
    if (context == EGL_NO_CONTEXT || surface == EGL_NO_SURFACE || display == EGL_NO_DISPLAY) return;
    GLint major = 0;
    glGetIntegerv(GL_MAJOR_VERSION, &major);
    if (major < 3) return;

    // Only the full-size scene target (same guard Motion Blur uses): skips shadow
    // maps, UI atlases and other offscreen passes.
    GLint viewport[4]{};
    glGetIntegerv(GL_VIEWPORT, viewport);
    EGLint width = 0, height = 0;
    if (!eglQuerySurface(display, surface, EGL_WIDTH, &width) || !eglQuerySurface(display, surface, EGL_HEIGHT, &height)) return;
    if (viewport[0] != 0 || viewport[1] != 0 || viewport[2] != width || viewport[3] != height || width < 64 || height < 64) return;
    GLint depthBits = 0;
    glGetIntegerv(GL_DEPTH_BITS, &depthBits);
    if (depthBits == 0) return;

    if (g_gl.program && g_gl.context != context) g_gl = {}; // context was recreated
    if (!g_gl.program && !build()) {
        module->active.store(false, std::memory_order_release); // don't retry a broken driver every frame
        return;
    }

    GLint program = 0, vao = 0, srcRgb = 0, dstRgb = 0, srcA = 0, dstA = 0, eqRgb = 0, eqA = 0;
    GLboolean mask[4]{};
    glGetIntegerv(GL_CURRENT_PROGRAM, &program);
    glGetIntegerv(GL_VERTEX_ARRAY_BINDING, &vao);
    glGetIntegerv(GL_BLEND_SRC_RGB, &srcRgb);
    glGetIntegerv(GL_BLEND_DST_RGB, &dstRgb);
    glGetIntegerv(GL_BLEND_SRC_ALPHA, &srcA);
    glGetIntegerv(GL_BLEND_DST_ALPHA, &dstA);
    glGetIntegerv(GL_BLEND_EQUATION_RGB, &eqRgb);
    glGetIntegerv(GL_BLEND_EQUATION_ALPHA, &eqA);
    glGetBooleanv(GL_COLOR_WRITEMASK, mask);
    const GLboolean blend = glIsEnabled(GL_BLEND), depth = glIsEnabled(GL_DEPTH_TEST),
                    cull = glIsEnabled(GL_CULL_FACE), scissor = glIsEnabled(GL_SCISSOR_TEST),
                    stencil = glIsEnabled(GL_STENCIL_TEST);

    glDisable(GL_DEPTH_TEST);
    glDisable(GL_CULL_FACE);
    glDisable(GL_SCISSOR_TEST);
    glDisable(GL_STENCIL_TEST);
    glEnable(GL_BLEND);
    glBlendEquation(GL_FUNC_ADD);
    glBlendFunc(GL_ONE_MINUS_DST_COLOR, GL_ONE); // dst + (1 - dst) * grey
    glColorMask(GL_TRUE, GL_TRUE, GL_TRUE, GL_FALSE);
    glBindVertexArray(0);
    glUseProgram(g_gl.program);
    glUniform1f(g_gl.strengthLocation, std::clamp(module->strength.load(std::memory_order_relaxed), 0.0f, 1.0f) * 0.8f);
    glDrawArrays(GL_TRIANGLES, 0, 3);

    glUseProgram(static_cast<GLuint>(program));
    glBindVertexArray(static_cast<GLuint>(vao));
    glColorMask(mask[0], mask[1], mask[2], mask[3]);
    glBlendEquationSeparate(static_cast<GLenum>(eqRgb), static_cast<GLenum>(eqA));
    glBlendFuncSeparate(static_cast<GLenum>(srcRgb), static_cast<GLenum>(dstRgb), static_cast<GLenum>(srcA), static_cast<GLenum>(dstA));
    if (!blend) glDisable(GL_BLEND);
    if (depth) glEnable(GL_DEPTH_TEST);
    if (cull) glEnable(GL_CULL_FACE);
    if (scissor) glEnable(GL_SCISSOR_TEST);
    if (stencil) glEnable(GL_STENCIL_TEST);
}

}

FullbrightModule::FullbrightModule() : Module("Fullbright", "Lifts dark areas so caves and nights are visible.") {
    g_module = this;
}

void FullbrightModule::onInit() {
    slimpy::core::renderlevel::addPost(post);
}

void FullbrightModule::onEnable() { active.store(true, std::memory_order_release); }
void FullbrightModule::onDisable() { active.store(false, std::memory_order_release); }

void FullbrightModule::onMenuRegistered() {
    using namespace slimpy::ui;
    Schema schema;
    node(schema, "strength", "Strength", NodeType::SliderFloat, "0.05", "1", "0.05", "Screen-space brightness lift.");
    publish(moduleId, schema, "Fullbright");
}

void FullbrightModule::loadConfig(const nlohmann::json& j) {
    Module::loadConfig(j);
    strength.store(std::clamp(j.value("strength", strength.load()), 0.05f, 1.0f));
}

void FullbrightModule::saveConfig(nlohmann::json& j) {
    Module::saveConfig(j);
    j["strength"] = strength.load();
}
