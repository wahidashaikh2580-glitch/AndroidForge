#pragma once

namespace slimpy::core::renderlevel {

// LevelRenderer::renderLevel is hooked exactly once and fans out to listeners.
// `pre` runs before the world is drawn, `post` after it (still on the render thread).
using Listener = void (*)(void* levelRenderer, void* screenContext, void* view);

bool addPre(Listener listener);
bool addPost(Listener listener);
void uninstall();

}
