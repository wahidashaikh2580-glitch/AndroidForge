#include "RenderLevel.hpp"
#include "memory/Hooks.hpp"
#include <slimpy/memory/Signatures.hpp>
#include <array>
#include <atomic>
#include <mutex>

namespace slimpy::core::renderlevel {
namespace {

using RenderLevelFn = void (*)(void*, void*, void*);
RenderLevelFn original = nullptr;
slimpy::hooks::Handle handle = nullptr;
std::mutex registration;
std::array<Listener, 4> pre{};
std::array<Listener, 4> post{};
std::atomic_size_t preCount{0};
std::atomic_size_t postCount{0};

void detour(void* self, void* context, void* view) {
    const auto preTotal = preCount.load(std::memory_order_acquire);
    for (std::size_t i = 0; i < preTotal; ++i) pre[i](self, context, view);
    if (original) original(self, context, view);
    const auto postTotal = postCount.load(std::memory_order_acquire);
    for (std::size_t i = 0; i < postTotal; ++i) post[i](self, context, view);
}

bool install() {
    if (handle) return true;
    const auto target = slimpy::memory::resolve(slimpy::memory::SignatureId::RenderLevel);
    if (!target) return false;
    handle = slimpy::hooks::install(reinterpret_cast<void*>(target), reinterpret_cast<void*>(detour), reinterpret_cast<void**>(&original));
    return handle != nullptr;
}

bool add(std::array<Listener, 4>& list, std::atomic_size_t& count, Listener listener) {
    if (!listener) return false;
    std::lock_guard lock(registration);
    const auto n = count.load(std::memory_order_relaxed);
    if (n >= list.size() || !install()) return false;
    list[n] = listener;
    count.store(n + 1, std::memory_order_release);
    return true;
}

}

bool addPre(Listener listener) { return add(pre, preCount, listener); }
bool addPost(Listener listener) { return add(post, postCount, listener); }

void uninstall() {
    std::lock_guard lock(registration);
    if (handle) slimpy::hooks::remove(handle);
    handle = nullptr;
    preCount.store(0, std::memory_order_release);
    postCount.store(0, std::memory_order_release);
}

}
