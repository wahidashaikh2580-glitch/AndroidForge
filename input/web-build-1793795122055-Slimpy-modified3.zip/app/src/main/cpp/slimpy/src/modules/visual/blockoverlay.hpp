#pragma once
#include "../Module.hpp"
#include <cstdint>

// Draws an outline around the block the player is currently targeting.
// Runs as a post-renderLevel listener and returns immediately when off.
class BlockOverlayModule : public Module {
public:
    BlockOverlayModule();
    ~BlockOverlayModule() override;

    void onInit() override;
    void loadConfig(const nlohmann::json& j) override;
    void saveConfig(nlohmann::json& j) override;

    std::uint32_t lineColor = 0xFF000000u; // AARRGGBB
};
