#include "GameHooks.hpp"
#include "Fov.hpp"
#include "RenderLevel.hpp"
#include <slimpy/Version.hpp>

#include "core/memory/Hooks.hpp"
#include <slimpy/events/EventBus.hpp>
#include <slimpy/memory/Signatures.hpp>
#include <EGL/egl.h>
#include <array>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <mutex>
#include <string>

namespace slimpy::core::gamehooks {
namespace {
using namespace slimpy::events;
using slimpy::memory::SignatureId;

using VersionStringFn = std::string(*)(void*);
using NormalTickFn = void(*)(void*);
using ClientInstanceUpdateFn = void*(*)(void*, bool);
using ScreenFn = void*(*)(void*, void*, void*, void*, void*, void*, void*, void*);
using EglSwapBuffersFn = EGLBoolean(*)(EGLDisplay, EGLSurface);

VersionStringFn versionOriginal = nullptr;
NormalTickFn tickOriginal = nullptr;
ClientInstanceUpdateFn clientUpdateOriginal = nullptr;
ScreenFn containerOpenOriginal = nullptr;
ScreenFn containerCloseOriginal = nullptr;
ScreenFn chatOpenOriginal = nullptr;
ScreenFn chatCloseOriginal = nullptr;
EglSwapBuffersFn swapBuffersOriginal = nullptr;
std::atomic<void*> currentClientInstance = nullptr;
std::array<slimpy::hooks::Handle, 12> handles{};
std::size_t handleCount = 0;
std::mutex installMutex;
bool installed = false;

template <class Function>
bool hookSignature(SignatureId id, void* detour, Function** original) {
    const auto address = slimpy::memory::resolve(id);
    if (!address) return false;
    slimpy::hooks::Handle handle = slimpy::hooks::install(reinterpret_cast<void*>(address), detour, reinterpret_cast<void**>(original));
    if (!handle) return false;
    if (handleCount < handles.size()) handles[handleCount++] = handle;
    return true;
}

std::string versionDetour(void* self) {
    std::string version = versionOriginal ? versionOriginal(self) : std::string{};
    return std::string("\xC2\xA7" "b") + std::string(slimpy::Name) + " v" + std::string(slimpy::Version) + " " + "\xC2\xA7" "fby " + "\xC2\xA7" "e" + std::string(slimpy::Author) + " " + "\xC2\xA7" "f- " + "\xC2\xA7" "r" + version;
}

void tickDetour(void* actor) {
    auto* player = reinterpret_cast<slimpy::sdk::Player*>(actor);
    auto& events = bus();
    if (events.hasListeners(EventType::LocalPlayerPreTick)) {
        LocalPlayerPreTickEvent preEvent{player};
        events.publish(preEvent);
    }
    if (tickOriginal) tickOriginal(actor);
    if (events.hasListeners(EventType::LocalPlayerTick)) {
        LocalPlayerTickEvent event{player};
        events.publish(event);
    }
}

void* clientUpdateDetour(void* clientInstance, bool value) {
    if (clientInstance) currentClientInstance.store(clientInstance, std::memory_order_release);
    void* result = clientUpdateOriginal ? clientUpdateOriginal(clientInstance, value) : nullptr;
    ClientInstanceUpdateEvent event{reinterpret_cast<slimpy::sdk::ClientInstance*>(clientInstance)};
    bus().publish(event);
    return result;
}

template <ScreenKind Kind, ScreenPhase Phase, ScreenFn* Original>
void* screenDetour(void* a0, void* a1, void* a2, void* a3, void* a4, void* a5, void* a6, void* a7) {
    ScreenStateEvent event{Kind, Phase, a0};
    bus().publish(event);
    return *Original ? (*Original)(a0, a1, a2, a3, a4, a5, a6, a7) : nullptr;
}

EGLBoolean swapBuffersDetour(EGLDisplay display, EGLSurface surface) {
    if (eglGetCurrentContext() != EGL_NO_CONTEXT) {
        FrameEvent event;
        bus().publish(event);
    }
    return swapBuffersOriginal ? swapBuffersOriginal(display, surface) : EGL_FALSE;
}

bool hookEgl() {
    auto egl = slimpy::hooks::openLibrary("libEGL.so");
    if (!egl) return false;
    const auto address = slimpy::hooks::symbol(egl, "eglSwapBuffers");
    if (!address) {
        slimpy::hooks::closeLibrary(egl);
        return false;
    }
    auto handle = slimpy::hooks::install(reinterpret_cast<void*>(address), reinterpret_cast<void*>(swapBuffersDetour), reinterpret_cast<void**>(&swapBuffersOriginal));
    slimpy::hooks::closeLibrary(egl);
    if (!handle) return false;
    if (handleCount < handles.size()) handles[handleCount++] = handle;
    return true;
}
}

bool install() {
    std::lock_guard lock(installMutex);
    if (installed) return true;
    hookSignature(SignatureId::VersionString, reinterpret_cast<void*>(versionDetour), &versionOriginal);
    hookSignature(SignatureId::NormalTick, reinterpret_cast<void*>(tickDetour), &tickOriginal);
    hookSignature(SignatureId::ClientInstanceUpdate, reinterpret_cast<void*>(clientUpdateDetour), &clientUpdateOriginal);
    hookSignature(SignatureId::ContainerScreenControllerOpen,
        reinterpret_cast<void*>(screenDetour<ScreenKind::Container, ScreenPhase::Opened, &containerOpenOriginal>), &containerOpenOriginal);
    hookSignature(SignatureId::ContainerScreenControllerDtor,
        reinterpret_cast<void*>(screenDetour<ScreenKind::Container, ScreenPhase::Closed, &containerCloseOriginal>), &containerCloseOriginal);
    hookSignature(SignatureId::ChatScreenOpen,
        reinterpret_cast<void*>(screenDetour<ScreenKind::Chat, ScreenPhase::Opened, &chatOpenOriginal>), &chatOpenOriginal);
    hookSignature(SignatureId::ChatScreenDtor,
        reinterpret_cast<void*>(screenDetour<ScreenKind::Chat, ScreenPhase::Closed, &chatCloseOriginal>), &chatCloseOriginal);
    hookEgl();
    installed = tickOriginal != nullptr && clientUpdateOriginal != nullptr;
    return installed;
}

void uninstall() {
    std::lock_guard lock(installMutex);
    slimpy::core::fov::uninstall();
    slimpy::core::renderlevel::uninstall();
    for (std::size_t i = 0; i < handleCount; ++i) {
        if (handles[i]) slimpy::hooks::remove(handles[i]);
        handles[i] = nullptr;
    }
    handleCount = 0;
    installed = false;
    currentClientInstance.store(nullptr, std::memory_order_release);
}

void* clientInstance() {
    return currentClientInstance.load(std::memory_order_acquire);
}

}
