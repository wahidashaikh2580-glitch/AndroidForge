#pragma once

namespace slimpy::core::fov {

// The engine's GetFov is hooked exactly once. Filters may rewrite the world FOV
// (Zoom); observers then see the final value (Motion Blur). Register during
// module init, before rendering starts.
using Filter = float (*)(float fovDegrees);
using Observer = void (*)(float fovDegrees);

bool addFilter(Filter filter);
bool addObserver(Observer observer);
void uninstall();

}
