#pragma once

#include <cstdint>

namespace slimpy::events {

enum class EventType : std::uint32_t {
    Frame = 1,
    LocalPlayerTick,
    ClientInstanceUpdate,
    MouseInput,
    ScreenState,
    LocalPlayerPreTick,
    Count
};

enum class EventPriority : std::int32_t {
    First = 200,
    Early = 100,
    Normal = 0,
    Late = -100,
    Last = -200
};

class Cancellable {
public:
    bool cancelled() const { return mCancelled; }
    void cancel(bool value = true) { mCancelled = value; }

private:
    bool mCancelled = false;
};

}
