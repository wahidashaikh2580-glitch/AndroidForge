#pragma once

#include <slimpy/events/Events.hpp>
#include <slimpy/Export.hpp>
#include <algorithm>
#include <array>
#include <cstdint>
#include <functional>
#include <memory>
#include <mutex>
#include <shared_mutex>
#include <utility>
#include <vector>

namespace slimpy::events {

using Subscription = std::uint64_t;

// Listener lists are copy-on-write: publishing only copies a shared_ptr (no heap
// allocation), which matters because Frame / tick events fire every frame.
class EventBus {
public:
    using RawCallback = std::function<void(void*)>;

    Subscription subscribeRaw(EventType type, RawCallback callback, EventPriority priority = EventPriority::Normal) {
        const auto index = static_cast<std::size_t>(type);
        if (!callback || index >= mListeners.size()) return 0;
        std::unique_lock lock(mMutex);
        const auto id = mNextId++;
        auto next = mListeners[index] ? std::make_shared<std::vector<Entry>>(*mListeners[index]) : std::make_shared<std::vector<Entry>>();
        next->push_back({id, priority, std::move(callback)});
        std::stable_sort(next->begin(), next->end(), [](const Entry& left, const Entry& right) {
            return static_cast<std::int32_t>(left.priority) > static_cast<std::int32_t>(right.priority);
        });
        mListeners[index] = std::move(next);
        return id;
    }

    template <class Event, class Callback>
    Subscription subscribe(Callback&& callback, EventPriority priority = EventPriority::Normal) {
        return subscribeRaw(Event::type, [handler = std::forward<Callback>(callback)](void* payload) mutable {
            handler(*static_cast<Event*>(payload));
        }, priority);
    }

    void unsubscribe(Subscription id) {
        if (id == 0) return;
        std::unique_lock lock(mMutex);
        for (auto& slot : mListeners) {
            if (!slot) continue;
            auto next = std::make_shared<std::vector<Entry>>(*slot);
            next->erase(std::remove_if(next->begin(), next->end(), [id](const Entry& entry) { return entry.id == id; }), next->end());
            slot = std::move(next);
        }
    }

    bool hasListeners(EventType type) const {
        const auto index = static_cast<std::size_t>(type);
        if (index >= mListeners.size()) return false;
        std::shared_lock lock(mMutex);
        return mListeners[index] && !mListeners[index]->empty();
    }

    void publishRaw(EventType type, void* payload) {
        const auto index = static_cast<std::size_t>(type);
        if (index >= mListeners.size()) return;
        std::shared_ptr<const std::vector<Entry>> snapshot;
        {
            std::shared_lock lock(mMutex);
            snapshot = mListeners[index];
        }
        if (!snapshot) return;
        for (const auto& entry : *snapshot) entry.callback(payload);
    }

    template <class Event>
    void publish(Event& event) {
        publishRaw(Event::type, &event);
    }

    void clear() {
        std::unique_lock lock(mMutex);
        for (auto& slot : mListeners) slot.reset();
    }

private:
    struct Entry {
        Subscription id;
        EventPriority priority;
        RawCallback callback;
    };

    mutable std::shared_mutex mMutex;
    std::array<std::shared_ptr<const std::vector<Entry>>, static_cast<std::size_t>(EventType::Count)> mListeners;
    std::uint64_t mNextId = 1;
};

SLIMPY_API EventBus& bus();

}
