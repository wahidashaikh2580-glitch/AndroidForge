#pragma once

#include <slimpy/events/Event.hpp>
#include <slimpy/events/FrameEvent.hpp>
#include <slimpy/events/LocalPlayerTickEvent.hpp>
#include <slimpy/events/LocalPlayerPreTickEvent.hpp>
#include <slimpy/events/ClientInstanceUpdateEvent.hpp>
#include <slimpy/events/MouseInputEvent.hpp>
#include <slimpy/events/ScreenStateEvent.hpp>
