package com.slimpy.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var reportView: TextView
    private var rustOk = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val header = StringBuilder("Slimpy 2.0 - Phase 3 PoC\n\n")
        header.append("ABI list: ").append(Build.SUPPORTED_ABIS.joinToString()).append('\n')
        try {
            System.loadLibrary("slimpy")
            rustOk = true
            header.append("libslimpy.so: LOADED\n")
            header.append("native api version: ").append(NativeBridge.nativeApiVersion()).append('\n')
            header.append("native fib(50): ").append(NativeBridge.nativeFib(50)).append("  (expected 12586269025)\n")
        } catch (t: Throwable) {
            header.append("libslimpy.so: FAILED -> ").append(t).append('\n')
        }

        reportView = TextView(this).apply {
            text = header.toString()
            setTextColor(Color.rgb(0xCF, 0xE8, 0xEC))
            typeface = Typeface.MONOSPACE
            textSize = 12f
            setPadding(32, 32, 32, 32)
        }

        val detectBtn = Button(this).apply {
            text = "Detect Installed Minecraft"
            setOnClickListener { detectInstalled() }
        }
        val manualBtn = Button(this).apply {
            text = "Manual import (base + splits)"
            setOnClickListener { pickApks() }
        }
        val hookBtn = Button(this).apply {
            text = "Run loader self-test"
            setOnClickListener { runHookSelfTest() }
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(0x12, 0x14, 0x16))
            addView(detectBtn)
            addView(manualBtn)
            addView(hookBtn)
            addView(reportView)
        }
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun append(line: String) {
        reportView.append("\n" + line)
    }

    private fun detectInstalled() {
        append("\n--- detecting installed Minecraft ---")
        val d = MinecraftImport.detectInstalled(this)
        append(d.message)
        if (!d.installed) return
        d.sources.forEach { s -> append("  ${s.label}: ${if (s.file?.canRead() == true) "readable" else "NOT readable"} (${s.file?.path})") }
        if (d.readableSources.size != d.sources.size) {
            append("some files aren't directly readable on this ROM — tap 'Manual import' and pick the base APK + split APKs yourself (e.g. exported with a local split-APK export tool, NOT a download from another site)")
        }
        val result = MinecraftImport.importFromDetected(this, d)
        append("import ok=${result.ok}: ${result.message}")
        finishImport(result)
    }

    private fun pickApks() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        startActivityForResult(intent, REQUEST_PICK_APKS)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_PICK_APKS || resultCode != RESULT_OK) return
        val uris: List<Uri> = buildList {
            data?.clipData?.let { clip -> for (i in 0 until clip.itemCount) add(clip.getItemAt(i).uri) }
            data?.data?.let { add(it) }
        }
        if (uris.isEmpty()) { append("import: no files returned"); return }
        append("\n--- importing ${uris.size} picked file(s) ---")
        val result = MinecraftImport.importFromPickedUris(this, uris)
        append("import ok=${result.ok}: ${result.message}")
        finishImport(result)
    }

    private fun finishImport(result: McImportResult) {
        if (result.inventory.isNotEmpty()) {
            append("full native-lib inventory across supplied files (${result.inventory.size} entries):")
            result.inventory.distinct().sorted().forEach { append("  $it") }
        }
        if (!result.ok) return
        if (!rustOk) { append("cannot dlopen: libslimpy.so was not loaded"); return }
        val libPath = result.mainLibPath?.absolutePath ?: run { append("no mainLibPath"); return }

        val libDir = result.libDir
        if (libDir != null && rustOk) {
            append("\n--- dependency report (real ELF DT_NEEDED walk) ---")
            append(NativeBridge.nativeDependencyReport(libDir.absolutePath, "libminecraftpe.so"))
        }

        val rc = NativeBridge.nativeImportMinecraft(libPath)
        if (rc == 0) {
            append("nativeImportMinecraft: SUCCESS (dlopen of $libPath)")
        } else {
            append("nativeImportMinecraft: FAILED rc=$rc")
            append("dlopen error: ${NativeBridge.nativeLastError()}")
            append("(a missing-symbol/library error here usually means a sibling .so the engine depends on wasn't staged alongside it, or full hosting — not a bare dlopen — is required)")
        }
    }

    private fun runHookSelfTest() {
        if (!rustOk) { append("cannot run self-test: libslimpy.so was not loaded"); return }
        append("\n--- loader self-test ---")
        append(NativeBridge.nativeHookSelfTest())
    }

    companion object {
        private const val REQUEST_PICK_APKS = 1001
    }
}
