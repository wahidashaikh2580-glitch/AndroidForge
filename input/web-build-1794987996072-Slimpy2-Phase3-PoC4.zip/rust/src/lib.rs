//! Slimpy 2.0 - Phase 2 proof of concept. No dependencies, no game integration.
//! Exports three JNI functions so the Kotlin host can prove the Rust -> APK path end to end.
use std::os::raw::c_void;

const SLIMPY_ABI_VERSION: i32 = 1;

#[no_mangle]
pub extern "system" fn Java_com_slimpy_app_NativeBridge_nativeApiVersion(
    _env: *mut c_void,
    _class: *mut c_void,
) -> i32 {
    SLIMPY_ABI_VERSION
}

#[no_mangle]
pub extern "system" fn Java_com_slimpy_app_NativeBridge_nativePointerBits(
    _env: *mut c_void,
    _class: *mut c_void,
) -> i32 {
    usize::BITS as i32
}

#[no_mangle]
pub extern "system" fn Java_com_slimpy_app_NativeBridge_nativeFib(
    _env: *mut c_void,
    _class: *mut c_void,
    n: i32,
) -> i64 {
    fib(n)
}

fn fib(n: i32) -> i64 {
    let n = n.clamp(0, 90);
    let (mut a, mut b) = (0i64, 1i64);
    for _ in 0..n {
        let t = a + b;
        a = b;
        b = t;
    }
    a
}

#[cfg(test)]
mod tests {
    use super::fib;
    #[test]
    fn fib_values() {
        assert_eq!(fib(0), 0);
        assert_eq!(fib(10), 55);
        assert_eq!(fib(50), 12_586_269_025);
        assert_eq!(fib(1000), fib(90));
    }
}

// =================================================================================================
// PHASE 3 — independent native loader: import a dlopen'd module, resolve one real RTTI/vtable
// target inside it, and prove inline-patch mechanics against that target. No game-specific feature
// hooks are installed; this only proves the loader's addressing and memory-patch machinery work
// against a live, resolved address — either inside the imported Minecraft library, or, if that
// library can't be resolved (see nativeImportMinecraft), against Slimpy's own exported JNI function
// as an honest fallback so the result never silently claims more than what was actually verified.
// =================================================================================================

use jni::objects::{JClass, JString};
use jni::sys::{jint as jni_jint, jstring};
use jni::JNIEnv;
use std::ffi::{CStr, CString};
use std::fs;
use std::sync::{Mutex, OnceLock};

static MC_HANDLE: OnceLock<Mutex<Option<usize>>> = OnceLock::new();
static LAST_ERROR: OnceLock<Mutex<String>> = OnceLock::new();

fn mc_handle_slot() -> &'static Mutex<Option<usize>> {
    MC_HANDLE.get_or_init(|| Mutex::new(None))
}
fn last_error_slot() -> &'static Mutex<String> {
    LAST_ERROR.get_or_init(|| Mutex::new(String::new()))
}
fn set_last_error(msg: String) {
    *last_error_slot().lock().unwrap() = msg;
}

#[derive(Clone)]
struct Region {
    start: usize,
    end: usize,
    perms: String,
    path: String,
}

/// Parses this process's own /proc/self/maps. No external crate needed: the format is a stable
/// kernel ABI, and we only need start/end/perms/pathname.
fn read_maps() -> Vec<Region> {
    let data = fs::read_to_string("/proc/self/maps").unwrap_or_default();
    let mut out = Vec::new();
    for line in data.lines() {
        let mut parts = line.splitn(6, ' ');
        let range = parts.next().unwrap_or("");
        let perms = parts.next().unwrap_or("").to_string();
        parts.next(); // offset
        parts.next(); // dev
        parts.next(); // inode
        let path = parts.next().unwrap_or("").trim().to_string();
        if let Some((a, b)) = range.split_once('-') {
            if let (Ok(start), Ok(end)) = (usize::from_str_radix(a, 16), usize::from_str_radix(b, 16)) {
                out.push(Region { start, end, perms, path });
            }
        }
    }
    out
}

fn module_regions(basename: &str) -> Vec<Region> {
    read_maps()
        .into_iter()
        .filter(|r| r.path.rsplit('/').next() == Some(basename))
        .collect()
}

/// Brute-force byte search restricted to readable mappings. Correct but O(n); fine for a one-shot
/// resolve, not for anything called per-frame.
unsafe fn scan_for_bytes(region: &Region, needle: &[u8]) -> Vec<usize> {
    if !region.perms.starts_with('r') || needle.is_empty() {
        return Vec::new();
    }
    let len = region.end.saturating_sub(region.start);
    if len < needle.len() {
        return Vec::new();
    }
    let slice = std::slice::from_raw_parts(region.start as *const u8, len);
    let mut hits = Vec::new();
    let mut i = 0usize;
    while i + needle.len() <= slice.len() {
        if &slice[i..i + needle.len()] == needle {
            hits.push(region.start + i);
        }
        i += 1;
    }
    hits
}

/// 8-byte-aligned pointer-value search restricted to readable mappings.
unsafe fn scan_for_pointer(region: &Region, target: usize) -> Vec<usize> {
    if !region.perms.starts_with('r') {
        return Vec::new();
    }
    let start = (region.start + 7) & !7usize;
    let end = region.end & !7usize;
    let mut hits = Vec::new();
    let mut p = start;
    while p + 8 <= end {
        if std::ptr::read_unaligned(p as *const usize) == target {
            hits.push(p);
        }
        p += 8;
    }
    hits
}

/// Resolves a C++ virtual-function slot by Itanium-ABI RTTI layout, against this process's OWN
/// already-relocated memory (we dlopen the target ourselves, so pointers are live — no static ELF
/// relocation math needed, unlike tooling that inspects the file on disk):
///   type_info struct:  { vptr, name_ptr, ... }        name_ptr -> "<len><MangledClassName>\0"
///   vtable layout:      { offset_to_top, typeinfo_ptr, vfunc[0], vfunc[1], ... }
/// Steps: find the bare type-name string -> find a word pointing at it (= typeinfo's name field,
/// so typeinfo starts one word earlier) -> find a word pointing at that typeinfo (= the vtable's
/// typeinfo slot) -> the function slots start one word after that. Every resolved function pointer
/// must land inside an executable region of the SAME module or the result is rejected (fail closed).
fn resolve_vtable_slot(module_basename: &str, mangled_type_name: &str, slot: usize) -> Result<usize, String> {
    let regions = module_regions(module_basename);
    if regions.is_empty() {
        return Err(format!("module '{module_basename}' is not mapped in this process"));
    }
    let mut needle = mangled_type_name.as_bytes().to_vec();
    needle.push(0);

    let mut name_addrs = Vec::new();
    for r in &regions {
        name_addrs.extend(unsafe { scan_for_bytes(r, &needle) });
    }
    if name_addrs.is_empty() {
        return Err(format!("RTTI name string '{mangled_type_name}' not found in {module_basename}"));
    }

    for name_addr in name_addrs {
        for r in &regions {
            for name_ptr_loc in unsafe { scan_for_pointer(r, name_addr) } {
                let typeinfo_addr = match name_ptr_loc.checked_sub(8) {
                    Some(v) => v,
                    None => continue,
                };
                for r2 in &regions {
                    for ti_ptr_loc in unsafe { scan_for_pointer(r2, typeinfo_addr) } {
                        let address_point = ti_ptr_loc + 8;
                        let slot_loc = address_point + slot * 8;
                        if regions.iter().all(|m| slot_loc + 8 > m.end || slot_loc < m.start) {
                            continue;
                        }
                        let func = unsafe { std::ptr::read_unaligned(slot_loc as *const usize) };
                        let in_exec_region = regions
                            .iter()
                            .any(|rr| rr.perms.contains('x') && func >= rr.start && func < rr.end);
                        if in_exec_region {
                            return Ok(func);
                        }
                    }
                }
            }
        }
    }
    Err(format!(
        "RTTI name for '{mangled_type_name}' found but no candidate vtable slot {slot} resolved to executable code in {module_basename}"
    ))
}

#[cfg(target_arch = "aarch64")]
unsafe fn clear_instruction_cache(addr: usize, len: usize) {
    const LINE: usize = 64; // conservative; real line size queried via ctr_el0 is unnecessary for 4 bytes
    let end = addr + len;
    let mut a = addr & !(LINE - 1);
    while a < end {
        std::arch::asm!("dc cvau, {0}", in(reg) a);
        a += LINE;
    }
    std::arch::asm!("dsb ish");
    let mut a = addr & !(LINE - 1);
    while a < end {
        std::arch::asm!("ic ivau, {0}", in(reg) a);
        a += LINE;
    }
    std::arch::asm!("dsb ish");
    std::arch::asm!("isb");
}

#[cfg(not(target_arch = "aarch64"))]
unsafe fn clear_instruction_cache(_addr: usize, _len: usize) {}

/// Proves real inline-patch mechanics against `addr`: make the page RWX, overwrite the first
/// instruction with an AArch64 NOP, flush the instruction cache, read back to confirm the write
/// landed, then immediately restore the original bytes and flush again. Nothing ever executes the
/// patched instruction (the target is never invoked during this test), so this is safe to run
/// against live code without side effects — but it is only a mechanism self-test, not an installed,
/// persistent feature hook.
unsafe fn hook_self_test(addr: usize) -> Result<(), String> {
    let page_size = 4096usize;
    let page = addr & !(page_size - 1);
    let region_len = page_size * 2;
    if libc::mprotect(page as *mut libc::c_void, region_len, libc::PROT_READ | libc::PROT_WRITE | libc::PROT_EXEC) != 0 {
        return Err(format!("mprotect(RWX) failed, errno {}", std::io::Error::last_os_error()));
    }
    let ptr = addr as *mut u32;
    let original = std::ptr::read_unaligned(ptr);
    const AARCH64_NOP: u32 = 0xD503_201F;
    std::ptr::write_unaligned(ptr, AARCH64_NOP);
    clear_instruction_cache(addr, 4);
    let after_write = std::ptr::read_unaligned(ptr);
    std::ptr::write_unaligned(ptr, original);
    clear_instruction_cache(addr, 4);
    let after_restore = std::ptr::read_unaligned(ptr);
    if after_write != AARCH64_NOP {
        return Err("write did not take effect (read-back mismatch)".to_string());
    }
    if after_restore != original {
        return Err(format!(
            "CRITICAL: restore failed — original=0x{original:08x} now=0x{after_restore:08x}"
        ));
    }
    Ok(())
}

/// Attempts to dlopen the given absolute path (the extracted libminecraftpe.so) into THIS process.
/// Returns 0 on success. On failure, the dlopen error (commonly a missing sibling dependency such
/// as libc++_shared.so or libfmod.so when only one file was extracted) is recorded for
/// nativeLastError() rather than hidden.
#[no_mangle]
pub extern "system" fn Java_com_slimpy_app_NativeBridge_nativeImportMinecraft(
    mut env: JNIEnv,
    _class: JClass,
    path: JString,
) -> jni_jint {
    let path_str: String = match env.get_string(&path) {
        Ok(s) => s.into(),
        Err(e) => {
            set_last_error(format!("invalid path string: {e}"));
            return -1;
        }
    };
    let cpath = match CString::new(path_str) {
        Ok(c) => c,
        Err(e) => {
            set_last_error(format!("path contains NUL: {e}"));
            return -2;
        }
    };
    unsafe {
        libc::dlerror(); // clear any stale error
        let handle = libc::dlopen(cpath.as_ptr(), libc::RTLD_NOW | libc::RTLD_GLOBAL);
        if handle.is_null() {
            let err = libc::dlerror();
            let msg = if err.is_null() {
                "dlopen failed, no dlerror() message available".to_string()
            } else {
                CStr::from_ptr(err).to_string_lossy().into_owned()
            };
            set_last_error(msg);
            return -3;
        }
        *mc_handle_slot().lock().unwrap() = Some(handle as usize);
    }
    set_last_error(String::new());
    0
}

#[no_mangle]
pub extern "system" fn Java_com_slimpy_app_NativeBridge_nativeLastError<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
) -> jstring {
    let msg = last_error_slot().lock().unwrap().clone();
    match env.new_string(msg) {
        Ok(s) => s.into_raw(),
        Err(_) => std::ptr::null_mut(),
    }
}

/// Runs the Phase 3 loader self-test and returns a short, human-readable, line-based report.
/// Order of attempts (each line states exactly what was tried and the real outcome):
///   1. Is libminecraftpe.so loaded in this process? (only true after a prior successful
///      nativeImportMinecraft call)
///   2. If so, resolve LivePlayerRenderer's vtable slot 17 inside it via RTTI.
///   3. Run the patch/flush/verify/restore self-test against whichever address step 2 resolved.
///   4. If Minecraft's library isn't loaded or the slot can't be resolved, fall back to Slimpy's
///      OWN exported nativeFib JNI function as the self-test target, and say so explicitly — never
///      silently claim the Minecraft-specific result when it wasn't actually obtained.
#[no_mangle]
pub extern "system" fn Java_com_slimpy_app_NativeBridge_nativeHookSelfTest<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
) -> jstring {
    let mut lines: Vec<String> = Vec::new();
    let mc_loaded = module_regions("libminecraftpe.so").len() > 0;
    lines.push(format!("libminecraftpe.so mapped in process: {mc_loaded}"));

    let mut target: Option<(usize, &'static str)> = None;
    if mc_loaded {
        match resolve_vtable_slot("libminecraftpe.so", "18LivePlayerRenderer", 17) {
            Ok(addr) => {
                lines.push(format!("resolved LivePlayerRenderer vtable slot 17 @ 0x{addr:x}"));
                target = Some((addr, "libminecraftpe.so LivePlayerRenderer::slot17 (RTTI-resolved)"));
            }
            Err(e) => lines.push(format!("vtable resolution failed: {e}")),
        }
    }

    let (addr, label) = target.unwrap_or_else(|| {
        let f = Java_com_slimpy_app_NativeBridge_nativeFib as usize;
        lines.push("falling back to Slimpy's own nativeFib export as the self-test target".to_string());
        (f, "libslimpy.so nativeFib (fallback target, NOT Minecraft)")
    });

    match unsafe { hook_self_test(addr) } {
        Ok(()) => lines.push(format!("PATCH/RESTORE SELF-TEST: PASSED against {label} @ 0x{addr:x}")),
        Err(e) => lines.push(format!("PATCH/RESTORE SELF-TEST: FAILED against {label} @ 0x{addr:x} — {e}")),
    }

    let report = lines.join("\n");
    match env.new_string(report) {
        Ok(s) => s.into_raw(),
        Err(_) => std::ptr::null_mut(),
    }
}

// =================================================================================================
// PHASE 3b — real dependency inspection. No readelf/llvm-readelf on-device; this parses the ELF64
// dynamic section by hand (program headers -> PT_DYNAMIC -> DT_NEEDED/DT_STRTAB) and walks the
// DT_NEEDED graph recursively against whatever was actually staged, so the report reflects the
// real file on disk rather than an assumption.
// =================================================================================================

use std::collections::{HashSet, VecDeque};
use std::path::{Path, PathBuf};

fn read_u16(b: &[u8], o: usize) -> u16 { u16::from_le_bytes([b[o], b[o + 1]]) }
fn read_u32(b: &[u8], o: usize) -> u32 { u32::from_le_bytes([b[o], b[o + 1], b[o + 2], b[o + 3]]) }
fn read_u64(b: &[u8], o: usize) -> u64 { u64::from_le_bytes(b[o..o + 8].try_into().unwrap()) }

/// Elf64_Phdr is 56 bytes: p_type(4) p_flags(4) p_offset(8) p_vaddr(8) p_paddr(8) p_filesz(8) p_memsz(8) p_align(8)
fn vaddr_to_file_offset(data: &[u8], phoff: usize, phentsize: usize, phnum: usize, vaddr: u64) -> Option<usize> {
    for i in 0..phnum {
        let off = phoff + i * phentsize;
        if off + 56 > data.len() { break; }
        if read_u32(data, off) != 1 { continue; } // PT_LOAD
        let p_offset = read_u64(data, off + 8);
        let p_vaddr = read_u64(data, off + 16);
        let p_filesz = read_u64(data, off + 32);
        if vaddr >= p_vaddr && vaddr < p_vaddr + p_filesz {
            return Some((p_offset + (vaddr - p_vaddr)) as usize);
        }
    }
    None
}

/// Returns the DT_NEEDED soname list of an ELF64 little-endian shared object by reading the file
/// directly (not by dlopen/live-process inspection — this works even for a library we never load).
fn elf_needed(path: &Path) -> Result<Vec<String>, String> {
    let data = std::fs::read(path).map_err(|e| format!("read failed: {e}"))?;
    if data.len() < 64 || &data[0..4] != b"\x7fELF" { return Err("not an ELF file".into()); }
    if data[4] != 2 { return Err("not ELFCLASS64 (32-bit ELF? expected arm64)".into()); }
    if data[5] != 1 { return Err("not little-endian".into()); }
    let e_phoff = read_u64(&data, 32) as usize;
    let e_phentsize = read_u16(&data, 54) as usize;
    let e_phnum = read_u16(&data, 56) as usize;

    let mut dyn_off = None;
    let mut dyn_size = 0usize;
    for i in 0..e_phnum {
        let off = e_phoff + i * e_phentsize;
        if off + 56 > data.len() { break; }
        if read_u32(&data, off) == 2 {
            dyn_off = Some(read_u64(&data, off + 8) as usize); // PT_DYNAMIC p_offset
            dyn_size = read_u64(&data, off + 32) as usize; // p_filesz
        }
    }
    let doff = dyn_off.ok_or("no PT_DYNAMIC segment")?;

    let mut needed_strtab_offsets = Vec::new();
    let mut strtab_vaddr = None;
    let mut i = 0usize;
    while i + 16 <= dyn_size && doff + i + 16 <= data.len() {
        let off = doff + i;
        let tag = read_u64(&data, off) as i64;
        let val = read_u64(&data, off + 8);
        match tag {
            0 => break,          // DT_NULL
            1 => needed_strtab_offsets.push(val), // DT_NEEDED
            5 => strtab_vaddr = Some(val),          // DT_STRTAB
            _ => {}
        }
        i += 16;
    }
    let strtab_vaddr = strtab_vaddr.ok_or("no DT_STRTAB (stripped/non-standard dynamic section?)")?;
    let strtab_file_off = vaddr_to_file_offset(&data, e_phoff, e_phentsize, e_phnum, strtab_vaddr)
        .ok_or("could not map DT_STRTAB vaddr to a file offset via program headers")?;

    let mut names = Vec::new();
    for rel in needed_strtab_offsets {
        let start = strtab_file_off + rel as usize;
        if start >= data.len() { continue; }
        let end = data[start..].iter().position(|&b| b == 0).map(|p| start + p).unwrap_or(data.len());
        names.push(String::from_utf8_lossy(&data[start..end]).into_owned());
    }
    Ok(names)
}

/// Reads DT_SONAME (tag 14) the same way elf_needed reads DT_NEEDED — lets the report confirm a
/// staged file's declared soname actually matches its filename, rather than assuming it does.
fn elf_soname(path: &Path) -> Option<String> {
    let data = std::fs::read(path).ok()?;
    if data.len() < 64 || &data[0..4] != b"\x7fELF" || data[4] != 2 || data[5] != 1 {
        return None;
    }
    let e_phoff = read_u64(&data, 32) as usize;
    let e_phentsize = read_u16(&data, 54) as usize;
    let e_phnum = read_u16(&data, 56) as usize;
    let mut dyn_off = None;
    let mut dyn_size = 0usize;
    for i in 0..e_phnum {
        let off = e_phoff + i * e_phentsize;
        if off + 56 > data.len() { break; }
        if read_u32(&data, off) == 2 {
            dyn_off = Some(read_u64(&data, off + 8) as usize);
            dyn_size = read_u64(&data, off + 32) as usize;
        }
    }
    let doff = dyn_off?;
    let mut soname_rel = None;
    let mut strtab_vaddr = None;
    let mut i = 0usize;
    while i + 16 <= dyn_size && doff + i + 16 <= data.len() {
        let off = doff + i;
        let tag = read_u64(&data, off) as i64;
        let val = read_u64(&data, off + 8);
        match tag {
            0 => break,
            14 => soname_rel = Some(val), // DT_SONAME
            5 => strtab_vaddr = Some(val),
            _ => {}
        }
        i += 16;
    }
    let strtab_off = vaddr_to_file_offset(&data, e_phoff, e_phentsize, e_phnum, strtab_vaddr?)?;
    let start = strtab_off + soname_rel? as usize;
    if start >= data.len() { return None; }
    let end = data[start..].iter().position(|&b| b == 0).map(|p| start + p).unwrap_or(data.len());
    Some(String::from_utf8_lossy(&data[start..end]).into_owned())
}

/// Libraries that live in the OS image and are never shipped inside an app — absence of these
/// from the staged directory is expected and NOT a problem.
const ANDROID_SYSTEM_LIBS: &[&str] = &[
    "libc.so", "libm.so", "libdl.so", "liblog.so", "libandroid.so", "libz.so",
    "libEGL.so", "libGLESv1_CM.so", "libGLESv2.so", "libGLESv3.so", "libvulkan.so",
    "libOpenSLES.so", "libjnigraphics.so", "libmediandk.so", "libneuralnetworks.so",
    "libnativewindow.so", "libc++.so",
];

/// BFS over the real DT_NEEDED graph starting at `root_name` inside `lib_dir`, reporting each
/// dependency as staged / expected-system / MISSING. This is the actual fact the earlier dlopen
/// failure needs, rather than a guess about which library is missing.
fn dependency_report(lib_dir: &Path, root_name: &str) -> Vec<String> {
    let mut lines = Vec::new();
    let mut seen: HashSet<String> = HashSet::new();
    let mut queue: VecDeque<PathBuf> = VecDeque::new();
    seen.insert(root_name.to_string());
    queue.push_back(lib_dir.join(root_name));

    while let Some(p) = queue.pop_front() {
        let name = p.file_name().map(|n| n.to_string_lossy().into_owned()).unwrap_or_default();
        if !p.is_file() {
            lines.push(format!("{name}: NOT PRESENT in staged dir (cannot inspect)"));
            continue;
        }
        match elf_needed(&p) {
            Ok(deps) => {
                lines.push(format!("{name}: {} direct DT_NEEDED entries", deps.len()));
                for d in deps {
                    let staged = lib_dir.join(&d).is_file();
                    let is_system = ANDROID_SYSTEM_LIBS.contains(&d.as_str());
                    let status = if staged {
                        let soname = elf_soname(&lib_dir.join(&d));
                        let meta = std::fs::metadata(lib_dir.join(&d)).ok();
                        format!(
                            "staged, {} bytes, DT_SONAME={}",
                            meta.map(|m| m.len()).unwrap_or(0),
                            soname.unwrap_or_else(|| "<none/unreadable>".to_string())
                        )
                    } else if is_system {
                        "expected to be provided by the OS (not bundled)".to_string()
                    } else {
                        "MISSING from staged dir and not a known OS library".to_string()
                    };
                    lines.push(format!("  needs {d}: {status}"));
                    if staged && seen.insert(d.clone()) {
                        queue.push_back(lib_dir.join(&d));
                    }
                }
            }
            Err(e) => lines.push(format!("{name}: ELF parse failed: {e}")),
        }
    }
    lines
}

#[no_mangle]
pub extern "system" fn Java_com_slimpy_app_NativeBridge_nativeDependencyReport<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    lib_dir: JString<'local>,
    main_lib_name: JString<'local>,
) -> jstring {
    let lib_dir_s: String = match env.get_string(&lib_dir) {
        Ok(s) => s.into(),
        Err(_) => return std::ptr::null_mut(),
    };
    let main_name: String = match env.get_string(&main_lib_name) {
        Ok(s) => s.into(),
        Err(_) => return std::ptr::null_mut(),
    };
    let report = dependency_report(Path::new(&lib_dir_s), &main_name).join("\n");
    match env.new_string(report) {
        Ok(s) => s.into_raw(),
        Err(_) => std::ptr::null_mut(),
    }
}
