package com.slimpy.app

/** JNI boundary to libslimpy.so (Rust). */
object NativeBridge {
    // Phase 2 (proven on device).
    @JvmStatic external fun nativeApiVersion(): Int
    @JvmStatic external fun nativePointerBits(): Int
    @JvmStatic external fun nativeFib(n: Int): Long

    // Phase 3: independent native loader.
    /** dlopen()s the extracted libminecraftpe.so from an absolute path. 0 = success. */
    @JvmStatic external fun nativeImportMinecraft(path: String): Int
    /** Human-readable dlopen()/dlerror() detail for the last nativeImportMinecraft call. */
    @JvmStatic external fun nativeLastError(): String
    /** Resolves one real vtable target (Minecraft if loaded, else a Slimpy fallback) and runs the
     *  patch/flush/verify/restore self-test against it. Returns a multi-line report. */
    @JvmStatic external fun nativeHookSelfTest(): String
    /** Parses libDir/mainLibName's ELF dynamic section and walks DT_NEEDED recursively against
     *  what's actually staged in libDir, reporting staged / OS-provided / MISSING per entry. */
    @JvmStatic external fun nativeDependencyReport(libDir: String, mainLibName: String): String
}
