package com.slimpy.app

import android.content.Context
import dalvik.system.DexClassLoader
import java.io.File
import java.lang.reflect.InvocationTargetException

/**
 * Loads Minecraft's native library through a DexClassLoader whose librarySearchPath is Slimpy's
 * staged lib directory. This is the real fix for "file exists in the staged dir but dlopen still
 * reports it missing": a raw JNI dlopen(absolute_path) only ever sees the CALLING native code's
 * already-fixed linker namespace, which has no reason to search our staging directory. A
 * classloader's librarySearchPath, by contrast, IS registered with the linker namespace tied to
 * that classloader — and that namespace is what resolves the bare-soname DT_NEEDED entries of
 * anything loaded by code defined in it. This is the documented, non-root, non-bypass mechanism.
 */
object NativeLoader {
    data class LoadResult(val ok: Boolean, val message: String)

    fun loadMinecraft(context: Context, libDir: File, mainLibAbsolutePath: String): LoadResult {
        val dexFile = File(context.cacheDir, "slimpy_loader.dex")
        try {
            context.assets.open("slimpy_loader.dex").use { input ->
                dexFile.outputStream().use { output -> input.copyTo(output) }
            }
        } catch (t: Throwable) {
            return LoadResult(false, "could not read bundled loader shim asset: $t")
        }
        val optimizedDir = File(context.codeCacheDir, "slimpy_dex_opt").apply { mkdirs() }
        return try {
            val loader = DexClassLoader(dexFile.absolutePath, optimizedDir.absolutePath, libDir.absolutePath, context.classLoader)
            val shim = Class.forName("com.slimpy.loader.NativeLoaderShim", true, loader)
            val method = shim.getMethod("loadAbsolute", String::class.java)
            method.invoke(null, mainLibAbsolutePath)
            LoadResult(true, "loaded via DexClassLoader(librarySearchPath=${libDir.path})")
        } catch (t: InvocationTargetException) {
            LoadResult(false, "native load failed: ${t.targetException}")
        } catch (t: Throwable) {
            LoadResult(false, "loader setup failed: $t")
        } finally {
            dexFile.delete()
        }
    }
}
