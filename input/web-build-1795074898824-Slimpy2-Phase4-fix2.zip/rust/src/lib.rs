//! Slimpy 2.0 — Rust core
//! Handles: UI state, 11 client modules, persistent settings, hook machinery (Phase 3 loader).
//! JNI surface consumed by the Kotlin host (MainActivity + SlimpyView).

#![allow(non_snake_case)]

use std::ffi::CStr;
use std::fs;
use std::sync::{Mutex, OnceLock};

use jni::objects::{JClass, JString};
use jni::sys::{jboolean, jfloat, jint, jstring, JNI_FALSE, JNI_TRUE};
use jni::JNIEnv;
use libc::c_void;

// ─── ABI version ──────────────────────────────────────────────────────────────
const SLIMPY_ABI_VERSION: i32 = 2;

#[no_mangle]
pub extern "system" fn Java_com_slimpy_app_NativeBridge_nativeApiVersion(
    _env: *mut c_void,
    _class: *mut c_void,
) -> i32 {
    SLIMPY_ABI_VERSION
}

// ─── Module IDs (must match SlimpyModule.kt and UI order) ────────────────────
pub const MOD_MOTION_BLUR:        usize = 0;
pub const MOD_BLOCK_OVERLAY:      usize = 1;
pub const MOD_FPS_COUNTER:        usize = 2;
pub const MOD_CPS_COUNTER:        usize = 3;
pub const MOD_VIEW_MODEL:         usize = 4;
pub const MOD_THIRD_PERSON_TAG:   usize = 5;
pub const MOD_FULLBRIGHT:         usize = 6;
pub const MOD_TAB_PLAYER_LIST:    usize = 7;
pub const MOD_SWING_ANIMATION:    usize = 8;
pub const MOD_ZOOM:               usize = 9;
pub const MOD_AUTO_SPRINT:        usize = 10;
pub const MODULE_COUNT:           usize = 11;

pub const MODULE_NAMES: [&str; MODULE_COUNT] = [
    "Motion Blur",
    "Block Overlay",
    "FPS Counter",
    "CPS Counter",
    "View Model",
    "3rd Person Nametag",
    "Fullbright",
    "Tab Player List",
    "Swing Animation",
    "Zoom",
    "AutoSprint",
];

// ─── Per-module state ─────────────────────────────────────────────────────────
#[derive(Clone)]
pub struct ModuleState {
    pub enabled: bool,
    // float param — semantics differ per module (strength, scale, fov delta, etc.)
    pub value:   f32,
}

impl ModuleState {
    const fn default_for(id: usize) -> Self {
        let value = match id {
            MOD_MOTION_BLUR    => 0.5,  // blend strength  0..1
            MOD_BLOCK_OVERLAY  => 0.4,  // alpha           0..1
            MOD_FPS_COUNTER    => 0.0,  // position preset (0=TL,1=TR,2=BL,3=BR)
            MOD_CPS_COUNTER    => 0.0,  // same
            MOD_VIEW_MODEL     => 1.0,  // scale           0.5..2.0
            MOD_THIRD_PERSON_TAG => 0.0,
            MOD_FULLBRIGHT     => 1.0,  // gamma multiplier
            MOD_TAB_PLAYER_LIST => 0.0,
            MOD_SWING_ANIMATION => 1.0, // speed multiplier
            MOD_ZOOM           => 0.3,  // fov reduction factor
            MOD_AUTO_SPRINT    => 0.0,
            _                  => 0.0,
        };
        ModuleState { enabled: false, value }
    }
}

// ─── Global state ─────────────────────────────────────────────────────────────
struct SlimpyState {
    modules:    [ModuleState; MODULE_COUNT],
    mc_handle:  Option<usize>,
    last_error: String,
    fps:        f32,
    cps_l:      u32,
    cps_r:      u32,
}

impl SlimpyState {
    fn new() -> Self {
        SlimpyState {
            modules: core::array::from_fn(ModuleState::default_for),
            mc_handle: None,
            last_error: String::new(),
            fps: 0.0,
            cps_l: 0,
            cps_r: 0,
        }
    }
}

static STATE: OnceLock<Mutex<SlimpyState>> = OnceLock::new();
fn state() -> &'static Mutex<SlimpyState> {
    STATE.get_or_init(|| Mutex::new(SlimpyState::new()))
}

// ─── JNI: module toggle / query ───────────────────────────────────────────────

/// Toggle a module on/off. Returns new enabled state.
#[no_mangle]
pub extern "system" fn Java_com_slimpy_app_NativeBridge_nativeModuleToggle(
    _env: JNIEnv,
    _class: JClass,
    id: jint,
) -> jboolean {
    let id = id as usize;
    if id >= MODULE_COUNT { return JNI_FALSE; }
    let mut s = state().lock().unwrap();
    s.modules[id].enabled = !s.modules[id].enabled;
    if s.modules[id].enabled { JNI_TRUE } else { JNI_FALSE }
}

/// Returns 1 if module is enabled, 0 otherwise.
#[no_mangle]
pub extern "system" fn Java_com_slimpy_app_NativeBridge_nativeModuleEnabled(
    _env: JNIEnv,
    _class: JClass,
    id: jint,
) -> jboolean {
    let id = id as usize;
    if id >= MODULE_COUNT { return JNI_FALSE; }
    let s = state().lock().unwrap();
    if s.modules[id].enabled { JNI_TRUE } else { JNI_FALSE }
}

/// Set the float value for a module.
#[no_mangle]
pub extern "system" fn Java_com_slimpy_app_NativeBridge_nativeModuleSetValue(
    _env: JNIEnv,
    _class: JClass,
    id: jint,
    value: jfloat,
) {
    let id = id as usize;
    if id >= MODULE_COUNT { return; }
    let mut s = state().lock().unwrap();
    s.modules[id].value = value;
}

/// Get the float value for a module.
#[no_mangle]
pub extern "system" fn Java_com_slimpy_app_NativeBridge_nativeModuleGetValue(
    _env: JNIEnv,
    _class: JClass,
    id: jint,
) -> jfloat {
    let id = id as usize;
    if id >= MODULE_COUNT { return 0.0; }
    let s = state().lock().unwrap();
    s.modules[id].value
}

/// Returns module name as jstring.
#[no_mangle]
pub extern "system" fn Java_com_slimpy_app_NativeBridge_nativeModuleName<'a>(
    mut env: JNIEnv<'a>,
    _class: JClass<'a>,
    id: jint,
) -> jstring {
    let id = id as usize;
    let name = if id < MODULE_COUNT { MODULE_NAMES[id] } else { "unknown" };
    env.new_string(name).map(|s| s.into_raw()).unwrap_or(std::ptr::null_mut())
}

/// Returns MODULE_COUNT.
#[no_mangle]
pub extern "system" fn Java_com_slimpy_app_NativeBridge_nativeModuleCount(
    _env: JNIEnv,
    _class: JClass,
) -> jint {
    MODULE_COUNT as jint
}

// ─── JNI: live metrics (FPS / CPS) ───────────────────────────────────────────

#[no_mangle]
pub extern "system" fn Java_com_slimpy_app_NativeBridge_nativeSetFps(
    _env: JNIEnv, _class: JClass, fps: jfloat,
) { state().lock().unwrap().fps = fps; }

#[no_mangle]
pub extern "system" fn Java_com_slimpy_app_NativeBridge_nativeGetFps(
    _env: JNIEnv, _class: JClass,
) -> jfloat { state().lock().unwrap().fps }

#[no_mangle]
pub extern "system" fn Java_com_slimpy_app_NativeBridge_nativeSetCps(
    _env: JNIEnv, _class: JClass, left: jint, right: jint,
) {
    let mut s = state().lock().unwrap();
    s.cps_l = left as u32;
    s.cps_r = right as u32;
}

// ─── JNI: persist settings to/from file ──────────────────────────────────────

/// Serialises all module states to a flat binary blob:
///   [u8 enabled; f32 value] × MODULE_COUNT  (little-endian, no padding)
#[no_mangle]
pub extern "system" fn Java_com_slimpy_app_NativeBridge_nativeSaveSettings<'a>(
    mut env: JNIEnv<'a>,
    _class: JClass<'a>,
    path: JString<'a>,
) -> jboolean {
    let path_str: String = match env.get_string(&path) {
        Ok(s) => s.into(),
        Err(_) => return JNI_FALSE,
    };
    let s = state().lock().unwrap();
    let mut blob = Vec::with_capacity(MODULE_COUNT * 5);
    for m in &s.modules {
        blob.push(if m.enabled { 1u8 } else { 0u8 });
        blob.extend_from_slice(&m.value.to_le_bytes());
    }
    match fs::write(&path_str, &blob) {
        Ok(_)  => JNI_TRUE,
        Err(_) => JNI_FALSE,
    }
}

/// Deserialises module states from the blob written by nativeSaveSettings.
#[no_mangle]
pub extern "system" fn Java_com_slimpy_app_NativeBridge_nativeLoadSettings<'a>(
    mut env: JNIEnv<'a>,
    _class: JClass<'a>,
    path: JString<'a>,
) -> jboolean {
    let path_str: String = match env.get_string(&path) {
        Ok(s) => s.into(),
        Err(_) => return JNI_FALSE,
    };
    let blob = match fs::read(&path_str) {
        Ok(b)  => b,
        Err(_) => return JNI_FALSE,
    };
    if blob.len() < MODULE_COUNT * 5 { return JNI_FALSE; }
    let mut s = state().lock().unwrap();
    for i in 0..MODULE_COUNT {
        let base = i * 5;
        s.modules[i].enabled = blob[base] != 0;
        s.modules[i].value = f32::from_le_bytes([
            blob[base + 1], blob[base + 2], blob[base + 3], blob[base + 4],
        ]);
    }
    JNI_TRUE
}

// ─── Phase 3: loader machinery (unchanged from PoC5, kept verbatim) ──────────

static MC_HANDLE:   OnceLock<Mutex<Option<usize>>> = OnceLock::new();
static LAST_ERROR:  OnceLock<Mutex<String>>        = OnceLock::new();

fn mc_handle_slot()  -> &'static Mutex<Option<usize>> { MC_HANDLE.get_or_init(|| Mutex::new(None)) }
fn last_error_slot() -> &'static Mutex<String>        { LAST_ERROR.get_or_init(|| Mutex::new(String::new())) }
fn set_last_error(msg: String) { *last_error_slot().lock().unwrap() = msg; }

#[derive(Clone)]
struct Region { start: usize, end: usize, perms: String, path: String }

fn read_maps() -> Vec<Region> {
    let data = fs::read_to_string("/proc/self/maps").unwrap_or_default();
    let mut out = Vec::new();
    for line in data.lines() {
        let mut parts = line.splitn(6, ' ');
        let range = parts.next().unwrap_or("");
        let perms = parts.next().unwrap_or("").to_string();
        parts.next(); parts.next(); parts.next();
        let path = parts.next().unwrap_or("").trim().to_string();
        if let Some((a, b)) = range.split_once('-') {
            if let (Ok(s), Ok(e)) = (usize::from_str_radix(a, 16), usize::from_str_radix(b, 16)) {
                out.push(Region { start: s, end: e, perms, path });
            }
        }
    }
    out
}

fn module_regions(basename: &str) -> Vec<Region> {
    read_maps().into_iter().filter(|r| r.path.rsplit('/').next() == Some(basename)).collect()
}

unsafe fn scan_for_bytes(region: &Region, needle: &[u8]) -> Vec<usize> {
    if !region.perms.starts_with('r') || needle.is_empty() { return Vec::new(); }
    let len = region.end.saturating_sub(region.start);
    if len < needle.len() { return Vec::new(); }
    let slice = std::slice::from_raw_parts(region.start as *const u8, len);
    let mut hits = Vec::new();
    let mut i = 0usize;
    while i + needle.len() <= slice.len() {
        if &slice[i..i + needle.len()] == needle { hits.push(region.start + i); }
        i += 1;
    }
    hits
}

unsafe fn scan_for_pointer(region: &Region, target: usize) -> Vec<usize> {
    if !region.perms.starts_with('r') { return Vec::new(); }
    let start = (region.start + 7) & !7usize;
    let end   = region.end & !7usize;
    let mut hits = Vec::new();
    let mut p = start;
    while p + 8 <= end {
        if std::ptr::read_unaligned(p as *const usize) == target { hits.push(p); }
        p += 8;
    }
    hits
}

fn resolve_vtable_slot(module_basename: &str, mangled_type_name: &str, slot: usize) -> Result<usize, String> {
    let regions = module_regions(module_basename);
    if regions.is_empty() { return Err(format!("module '{module_basename}' not mapped")); }
    let mut needle = mangled_type_name.as_bytes().to_vec(); needle.push(0);
    let mut name_addrs = Vec::new();
    for r in &regions { name_addrs.extend(unsafe { scan_for_bytes(r, &needle) }); }
    if name_addrs.is_empty() { return Err(format!("RTTI '{mangled_type_name}' not found")); }
    for name_addr in name_addrs {
        for r in &regions {
            for name_ptr_loc in unsafe { scan_for_pointer(r, name_addr) } {
                let typeinfo_addr = match name_ptr_loc.checked_sub(8) { Some(v) => v, None => continue };
                for r2 in &regions {
                    for ti_ptr_loc in unsafe { scan_for_pointer(r2, typeinfo_addr) } {
                        let address_point = ti_ptr_loc + 8;
                        let slot_loc = address_point + slot * 8;
                        if regions.iter().all(|m| slot_loc + 8 > m.end || slot_loc < m.start) { continue; }
                        let func = unsafe { std::ptr::read_unaligned(slot_loc as *const usize) };
                        let in_exec = regions.iter().any(|rr| rr.perms.contains('x') && func >= rr.start && func < rr.end);
                        if in_exec { return Ok(func); }
                    }
                }
            }
        }
    }
    Err(format!("vtable slot {slot} not resolved for '{mangled_type_name}' in {module_basename}"))
}

#[cfg(target_arch = "aarch64")]
unsafe fn clear_instruction_cache(addr: usize, len: usize) {
    const LINE: usize = 64;
    let end = addr + len;
    let mut a = addr & !(LINE - 1);
    while a < end { std::arch::asm!("dc cvau, {0}", in(reg) a); a += LINE; }
    std::arch::asm!("dsb ish");
    let mut a = addr & !(LINE - 1);
    while a < end { std::arch::asm!("ic ivau, {0}", in(reg) a); a += LINE; }
    std::arch::asm!("dsb ish");
    std::arch::asm!("isb");
}
#[cfg(not(target_arch = "aarch64"))]
unsafe fn clear_instruction_cache(_addr: usize, _len: usize) {}

unsafe fn hook_self_test(addr: usize) -> Result<(), String> {
    let page_size = 4096usize;
    let page = addr & !(page_size - 1);
    if libc::mprotect(page as *mut libc::c_void, page_size * 2,
        libc::PROT_READ | libc::PROT_WRITE | libc::PROT_EXEC) != 0 {
        return Err(format!("mprotect failed: {}", std::io::Error::last_os_error()));
    }
    let ptr = addr as *mut u32;
    let orig = std::ptr::read_unaligned(ptr);
    const NOP: u32 = 0xD503_201F;
    std::ptr::write_unaligned(ptr, NOP);
    clear_instruction_cache(addr, 4);
    let after = std::ptr::read_unaligned(ptr);
    std::ptr::write_unaligned(ptr, orig);
    clear_instruction_cache(addr, 4);
    if after != NOP { return Err("write did not take effect".to_string()); }
    if std::ptr::read_unaligned(ptr) != orig { return Err("restore failed".to_string()); }
    Ok(())
}

#[no_mangle]
pub extern "system" fn Java_com_slimpy_app_NativeBridge_nativeImportMinecraft<'a>(
    mut env: JNIEnv<'a>, _class: JClass<'a>, path: JString<'a>,
) -> jint {
    use std::ffi::CString;
    let path_str: String = match env.get_string(&path) { Ok(s) => s.into(), Err(e) => { set_last_error(format!("{e}")); return -1; } };
    let cpath = match CString::new(path_str) { Ok(c) => c, Err(e) => { set_last_error(format!("{e}")); return -2; } };
    unsafe {
        libc::dlerror();
        let handle = libc::dlopen(cpath.as_ptr(), libc::RTLD_NOW | libc::RTLD_GLOBAL);
        if handle.is_null() {
            let err = libc::dlerror();
            let msg = if err.is_null() { "dlopen failed".to_string() } else { CStr::from_ptr(err).to_string_lossy().into_owned() };
            set_last_error(msg); return -3;
        }
        *mc_handle_slot().lock().unwrap() = Some(handle as usize);
    }
    set_last_error(String::new());
    0
}

#[no_mangle]
pub extern "system" fn Java_com_slimpy_app_NativeBridge_nativeLastError<'a>(
    mut env: JNIEnv<'a>, _class: JClass<'a>,
) -> jstring {
    let msg = last_error_slot().lock().unwrap().clone();
    env.new_string(msg).map(|s| s.into_raw()).unwrap_or(std::ptr::null_mut())
}

#[no_mangle]
pub extern "system" fn Java_com_slimpy_app_NativeBridge_nativeHookSelfTest<'a>(
    mut env: JNIEnv<'a>, _class: JClass<'a>,
) -> jstring {
    let mut lines: Vec<String> = Vec::new();
    let mc_loaded = !module_regions("libminecraftpe.so").is_empty();
    lines.push(format!("libminecraftpe.so mapped: {mc_loaded}"));
    let mut target: Option<(usize, &'static str)> = None;
    if mc_loaded {
        match resolve_vtable_slot("libminecraftpe.so", "18LivePlayerRenderer", 17) {
            Ok(addr) => { lines.push(format!("vtable slot 17 @ 0x{addr:x}")); target = Some((addr, "LivePlayerRenderer::slot17")); }
            Err(e)   => lines.push(format!("vtable resolution failed: {e}")),
        }
    }
    let (addr, label) = target.unwrap_or_else(|| {
        let f = Java_com_slimpy_app_NativeBridge_nativeApiVersion as usize;
        lines.push("fallback: using nativeApiVersion export as self-test target".to_string());
        (f, "libslimpy nativeApiVersion (fallback)")
    });
    match unsafe { hook_self_test(addr) } {
        Ok(())  => lines.push(format!("PATCH/RESTORE: PASSED @ 0x{addr:x} ({label})")),
        Err(e)  => lines.push(format!("PATCH/RESTORE: FAILED @ 0x{addr:x} ({label}) — {e}")),
    }
    let report = lines.join("\n");
    env.new_string(report).map(|s| s.into_raw()).unwrap_or(std::ptr::null_mut())
}

// ─── ELF dependency report (unchanged from PoC5) ─────────────────────────────

use std::collections::{HashSet, VecDeque};
use std::path::{Path, PathBuf};

fn read_u16(b: &[u8], o: usize) -> u16 { u16::from_le_bytes([b[o], b[o+1]]) }
fn read_u32(b: &[u8], o: usize) -> u32 { u32::from_le_bytes([b[o], b[o+1], b[o+2], b[o+3]]) }
fn read_u64(b: &[u8], o: usize) -> u64 { u64::from_le_bytes(b[o..o+8].try_into().unwrap()) }

fn vaddr_to_file_offset(data: &[u8], phoff: usize, phentsize: usize, phnum: usize, vaddr: u64) -> Option<usize> {
    for i in 0..phnum {
        let off = phoff + i * phentsize;
        if off + 56 > data.len() { break; }
        if read_u32(data, off) != 1 { continue; }
        let p_offset = read_u64(data, off + 8);
        let p_vaddr  = read_u64(data, off + 16);
        let p_filesz = read_u64(data, off + 32);
        if vaddr >= p_vaddr && vaddr < p_vaddr + p_filesz {
            return Some((p_offset + (vaddr - p_vaddr)) as usize);
        }
    }
    None
}

fn elf_needed(path: &Path) -> Result<Vec<String>, String> {
    let data = fs::read(path).map_err(|e| format!("read failed: {e}"))?;
    if data.len() < 64 || &data[0..4] != b"\x7fELF" { return Err("not ELF".into()); }
    if data[4] != 2 { return Err("not ELFCLASS64".into()); }
    if data[5] != 1 { return Err("not LE".into()); }
    let e_phoff     = read_u64(&data, 32) as usize;
    let e_phentsize = read_u16(&data, 54) as usize;
    let e_phnum     = read_u16(&data, 56) as usize;
    let mut dyn_off = None; let mut dyn_size = 0usize;
    for i in 0..e_phnum {
        let off = e_phoff + i * e_phentsize;
        if off + 56 > data.len() { break; }
        if read_u32(&data, off) == 2 { dyn_off = Some(read_u64(&data, off + 8) as usize); dyn_size = read_u64(&data, off + 32) as usize; }
    }
    let doff = dyn_off.ok_or("no PT_DYNAMIC")?;
    let mut needed = Vec::new(); let mut strtab_vaddr = None;
    let mut i = 0usize;
    while i + 16 <= dyn_size && doff + i + 16 <= data.len() {
        let off = doff + i;
        let tag = read_u64(&data, off) as i64;
        let val = read_u64(&data, off + 8);
        match tag { 0 => break, 1 => needed.push(val), 5 => strtab_vaddr = Some(val), _ => {} }
        i += 16;
    }
    let strtab_vaddr = strtab_vaddr.ok_or("no DT_STRTAB")?;
    let strtab_off   = vaddr_to_file_offset(&data, e_phoff, e_phentsize, e_phnum, strtab_vaddr).ok_or("strtab vaddr unmappable")?;
    let mut names = Vec::new();
    for rel in needed {
        let start = strtab_off + rel as usize;
        if start >= data.len() { continue; }
        let end = data[start..].iter().position(|&b| b == 0).map(|p| start + p).unwrap_or(data.len());
        names.push(String::from_utf8_lossy(&data[start..end]).into_owned());
    }
    Ok(names)
}

const ANDROID_SYSTEM_LIBS: &[&str] = &[
    "libc.so","libm.so","libdl.so","liblog.so","libandroid.so","libz.so",
    "libEGL.so","libGLESv1_CM.so","libGLESv2.so","libGLESv3.so","libvulkan.so",
    "libOpenSLES.so","libjnigraphics.so","libmediandk.so","libneuralnetworks.so",
    "libnativewindow.so","libc++.so",
];

fn dependency_report(lib_dir: &Path, root_name: &str) -> Vec<String> {
    let mut lines = Vec::new();
    let mut seen: HashSet<String> = HashSet::new();
    let mut queue: VecDeque<PathBuf> = VecDeque::new();
    seen.insert(root_name.to_string());
    queue.push_back(lib_dir.join(root_name));
    while let Some(p) = queue.pop_front() {
        let name = p.file_name().map(|n| n.to_string_lossy().into_owned()).unwrap_or_default();
        if !p.is_file() { lines.push(format!("{name}: NOT PRESENT")); continue; }
        match elf_needed(&p) {
            Ok(deps) => {
                lines.push(format!("{name}: {} deps", deps.len()));
                for d in deps {
                    let staged   = lib_dir.join(&d).is_file();
                    let is_sys   = ANDROID_SYSTEM_LIBS.contains(&d.as_str());
                    let status   = if staged { "staged".to_string() } else if is_sys { "OS-provided".to_string() } else { "MISSING".to_string() };
                    lines.push(format!("  needs {d}: {status}"));
                    if staged && seen.insert(d.clone()) { queue.push_back(lib_dir.join(&d)); }
                }
            }
            Err(e) => lines.push(format!("{name}: ELF parse failed: {e}")),
        }
    }
    lines
}

#[no_mangle]
pub extern "system" fn Java_com_slimpy_app_NativeBridge_nativeDependencyReport<'a>(
    mut env: JNIEnv<'a>, _class: JClass<'a>, lib_dir: JString<'a>, main_lib_name: JString<'a>,
) -> jstring {
    let lib_dir_s: String  = match env.get_string(&lib_dir)       { Ok(s) => s.into(), Err(_) => return std::ptr::null_mut() };
    let main_name: String  = match env.get_string(&main_lib_name) { Ok(s) => s.into(), Err(_) => return std::ptr::null_mut() };
    let report = dependency_report(Path::new(&lib_dir_s), &main_name).join("\n");
    env.new_string(report).map(|s| s.into_raw()).unwrap_or(std::ptr::null_mut())
}
