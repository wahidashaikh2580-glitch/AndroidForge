package com.slimpy.app

/** JNI boundary to libslimpy.so (Rust 2.0). */
object NativeBridge {
    // ── Core ──────────────────────────────────────────────────────────────────
    @JvmStatic external fun nativeApiVersion(): Int

    // ── Module control ────────────────────────────────────────────────────────
    @JvmStatic external fun nativeModuleCount(): Int
    @JvmStatic external fun nativeModuleName(id: Int): String
    @JvmStatic external fun nativeModuleToggle(id: Int): Boolean
    @JvmStatic external fun nativeModuleEnabled(id: Int): Boolean
    @JvmStatic external fun nativeModuleSetValue(id: Int, value: Float)
    @JvmStatic external fun nativeModuleGetValue(id: Int): Float

    // ── Live metrics ──────────────────────────────────────────────────────────
    @JvmStatic external fun nativeSetFps(fps: Float)
    @JvmStatic external fun nativeGetFps(): Float
    @JvmStatic external fun nativeSetCps(left: Int, right: Int)

    // ── Persistence ───────────────────────────────────────────────────────────
    @JvmStatic external fun nativeSaveSettings(path: String): Boolean
    @JvmStatic external fun nativeLoadSettings(path: String): Boolean

    // ── Phase 3 loader ────────────────────────────────────────────────────────
    @JvmStatic external fun nativeImportMinecraft(path: String): Int
    @JvmStatic external fun nativeLastError(): String
    @JvmStatic external fun nativeHookSelfTest(): String
    @JvmStatic external fun nativeDependencyReport(libDir: String, mainLibName: String): String
}
