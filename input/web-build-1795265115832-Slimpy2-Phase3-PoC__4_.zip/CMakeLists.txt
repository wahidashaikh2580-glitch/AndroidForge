# Inert marker, NOT referenced by Gradle (no externalNativeBuild). Its only purpose is to make
# AndroidForge's project detector report native code so it provisions the Android NDK.
# Slimpy's real native library is built from rust/ by the :app:buildRustArm64 Gradle task.
cmake_minimum_required(VERSION 3.22)
project(slimpy_ndk_marker NONE)
