# Phase 2 - Rust proof of concept on unmodified AndroidForge

**Status: authored, NOT yet built.** The authoring sandbox had no Rust, NDK, Gradle or network, so nothing
below has been executed. Treat every line as a hypothesis until the AndroidForge log confirms it.

## Run it
1. Zip the *contents* of this folder (the `settings.gradle.kts` must be at the zip root, or one folder deep).
2. AndroidForge web UI -> upload zip -> variant `debug` (or `auto`) -> **set `enable_ndk` = true** -> Build.
3. Download `AndroidForge-APKs` **and `AndroidForge-logs`**. Send me the logs even if it succeeds.

## What to look for in the log (lines start with `[slimpy-poc]`)
* `system cargo/rustup: ...` - is Rust preinstalled in the image?
* `android ndk: ...` - NDK path found?
* `network static.rust-lang.org: HTTP 200` - can the container reach the Rust host?
* `rustup-init sha256 ok`, then `rustc: rustc 1.85.0`, then cargo output.
* `libslimpy.so: OK (ELF64 little-endian ET_DYN EM_AARCH64)`.
* `native entries = [lib/arm64-v8a/libslimpy.so]` and `APK verification: OK`.

## On the phone
Install the APK. The screen must show `libslimpy.so: LOADED`, `native fib(50): 12586269025`, and the build
report. Anything else is a failure to report, not to fix by guessing.

## Acceptance criteria
PASS only if all of: AndroidForge workflow green without any repo modification; APK contains only
`lib/arm64-v8a/libslimpy.so`; app launches and the Rust calls return the expected values on a real arm64 device.

## Known uncertainties
* Gradle wrapper jar is not included (cannot be generated offline here). AndroidForge's README says it regenerates a missing wrapper; unverified for this project.
* AGP 8.5.2 / Gradle 8.7 / JDK 17 / compileSdk 34 chosen to match the image's platforms 23-34; unverified against `toolchain-rules.yaml`.
* The rustup-init checksum is fetched from the same host: detects corruption only. Pin a literal hash once recorded.
* Toolchain download adds minutes to a cold build, and uses the network every cold run unless AndroidForge caches `build/`.

## If it fails (smallest viable alternatives, no architecture change)
1. No network to static.rust-lang.org: commit a pinned offline Rust toolchain tarball inside the source ZIP (large) or a prebuilt `libslimpy.so` plus sources for audit.
2. rustup blocked but cargo present: use system cargo with `RUSTUP_TOOLCHAIN` unset and the installed target.
3. NDK missing: report; do not fall back silently.
