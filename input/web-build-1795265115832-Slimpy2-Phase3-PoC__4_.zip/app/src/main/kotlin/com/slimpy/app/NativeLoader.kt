package com.slimpy.app

import android.content.Context
import dalvik.system.DexClassLoader
import java.io.File
import java.lang.reflect.InvocationTargetException
import java.security.MessageDigest

/**
 * Loads Minecraft's native library through a DexClassLoader whose librarySearchPath is Slimpy's
 * staged lib directory (see this file's earlier revision for why a raw JNI dlopen can't do this).
 *
 * Android 14+ additionally refuses to dynamically load a dex file that is writable
 * ("SecurityException: Writable dex file ... is not allowed"), to stop a loaded dex being
 * swapped out after it was trusted. The fix here follows the documented pattern: write the dex
 * to a fresh, content-addressed path, call File.setReadOnly() (which on Android clears the write
 * bit for owner/group/other), verify canWrite() is now false, and only THEN hand it to
 * DexClassLoader. Naming the file by the content hash of the asset — rather than a fixed name —
 * means a future, different shim is a different file, never a write to one that may already be
 * loaded; stale versions are swept on the next load.
 */
object NativeLoader {
    data class LoadResult(val ok: Boolean, val message: String)

    /**
     * Evidence-driven fix for the libPlayFabMultiplayer.so SIGSEGV: that crash happened inside a
     * bundled third-party SDK's load-time constructor, which needs real app state (Context,
     * asset manager, native engine handles) that normally gets established by Minecraft's OWN
     * Application/Activity Java code BEFORE its engine touches such SDKs. Calling System.load on
     * libminecraftpe.so ourselves, with none of that run first, skips that entirely.
     *
     * This instead loads Mojang's own classes.dex (from the staged base.apk, which DexClassLoader
     * can read directly) with librarySearchPath = Slimpy's staged lib dir, instantiates Mojang's
     * declared Application class, and calls its attachBaseContext()/onCreate() — i.e. runs
     * MOJANG'S OWN initialization code, in the order Mojang wrote it, instead of our guessing it.
     * Only reaches as far as that class instantiation and those two calls: this does not attempt
     * to host Mojang's Activity, Window, Surface, or resources — if the APK declares no custom
     * Application class, that is reported as the actual finding, not worked around with a guess.
     */
    fun loadMinecraftViaApplication(context: Context, libDir: File, baseApkFile: File, applicationClassName: String?): LoadResult {
        if (applicationClassName.isNullOrEmpty()) {
            return LoadResult(false, "APK declares no custom Application class (android:name unset in its manifest) — engine init likely happens at Activity level instead; hosting Mojang's real Activity (resources/window/surface) is the next, larger step and was not attempted here")
        }
        if (!baseApkFile.isFile) return LoadResult(false, "staged base.apk is missing at ${baseApkFile.path}")
        if (baseApkFile.canWrite()) return LoadResult(false, "refusing to load: ${baseApkFile.path} is writable (expected read-only)")

        val optimizedDir = File(context.codeCacheDir, "slimpy_dex_opt").apply { mkdirs() }
        return try {
            val loader = DexClassLoader(baseApkFile.absolutePath, optimizedDir.absolutePath, libDir.absolutePath, context.classLoader)
            val appClass = Class.forName(applicationClassName, false, loader)
            val appInstance = appClass.getDeclaredConstructor().newInstance()

            // Application.attachBaseContext(Context) is protected, declared on ContextWrapper.
            val attachMethod = findDeclaredMethod(appClass, "attachBaseContext", Context::class.java)
                ?: return LoadResult(false, "could not find attachBaseContext(Context) on $applicationClassName or its superclasses")
            attachMethod.isAccessible = true
            attachMethod.invoke(appInstance, context.applicationContext)

            val onCreateMethod = findDeclaredMethod(appClass, "onCreate")
                ?: return LoadResult(false, "could not find onCreate() on $applicationClassName or its superclasses")
            onCreateMethod.isAccessible = true
            onCreateMethod.invoke(appInstance)

            LoadResult(true, "ran $applicationClassName.attachBaseContext()+onCreate() via DexClassLoader(dexPath=base.apk, librarySearchPath=${libDir.path})")
        } catch (t: InvocationTargetException) {
            LoadResult(false, "$applicationClassName init threw: ${t.targetException}")
        } catch (t: Throwable) {
            LoadResult(false, "loader setup failed: $t")
        }
    }

    private fun findDeclaredMethod(startClass: Class<*>, name: String, vararg paramTypes: Class<*>): java.lang.reflect.Method? {
        var c: Class<*>? = startClass
        while (c != null) {
            try {
                return c.getDeclaredMethod(name, *paramTypes)
            } catch (_: NoSuchMethodException) {
                c = c.superclass
            }
        }
        return null
    }

    /** Superseded by loadMinecraftViaApplication above for the actual import flow — kept only
     *  because it's what proved the SIGSEGV is a real native crash, not a Java-level failure. */
    fun loadMinecraft(context: Context, libDir: File, mainLibAbsolutePath: String): LoadResult {
        val dexBytes = try {
            context.assets.open("slimpy_loader.dex").use { it.readBytes() }
        } catch (t: Throwable) {
            return LoadResult(false, "could not read bundled loader shim asset: $t")
        }
        val hash = MessageDigest.getInstance("SHA-256").digest(dexBytes).joinToString("") { "%02x".format(it) }.take(16)
        val dexDir = File(context.codeCacheDir, "slimpy_loader_dex").apply { mkdirs() }
        val dexFile = File(dexDir, "shim_$hash.dex")

        // Never reuse a stale version from a previous build; one content hash == one immutable file.
        dexDir.listFiles()?.forEach { f -> if (f.name != dexFile.name) f.delete() }

        if (!dexFile.isFile) {
            val tmp = File(dexDir, "shim_$hash.dex.tmp")
            tmp.delete()
            try {
                tmp.outputStream().use { it.write(dexBytes) }
            } catch (t: Throwable) {
                return LoadResult(false, "could not write dex: $t")
            }
            if (!tmp.setReadOnly()) return LoadResult(false, "setReadOnly() on $tmp returned false")
            if (tmp.canWrite()) return LoadResult(false, "verification failed: $tmp still writable after setReadOnly()")
            if (!tmp.renameTo(dexFile)) {
                tmp.delete()
                return LoadResult(false, "could not finalize $dexFile (rename failed)")
            }
        }
        if (dexFile.canWrite()) return LoadResult(false, "refusing to load: $dexFile is writable")

        val optimizedDir = File(context.codeCacheDir, "slimpy_dex_opt").apply { mkdirs() }
        return try {
            val loader = DexClassLoader(dexFile.absolutePath, optimizedDir.absolutePath, libDir.absolutePath, context.classLoader)
            val shim = Class.forName("com.slimpy.loader.NativeLoaderShim", true, loader)
            val method = shim.getMethod("loadAbsolute", String::class.java)
            method.invoke(null, mainLibAbsolutePath)
            LoadResult(true, "loaded via DexClassLoader(librarySearchPath=${libDir.path}), shim=${dexFile.name} (read-only=${!dexFile.canWrite()})")
        } catch (t: InvocationTargetException) {
            LoadResult(false, "native load failed: ${t.targetException}")
        } catch (t: Throwable) {
            LoadResult(false, "loader setup failed: $t")
        }
    }
}
