package com.slimpy.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var reportView: TextView
    private var rustOk = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Net for any uncaught Java exception on any thread we didn't already wrap explicitly;
        // logs a breadcrumb before handing off to the previous (system default) handler, so
        // normal crash behavior is unchanged — this only adds a record of it.
        val prevHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            CrashLog.stage(this, "UNCAUGHT on thread '${t.name}': $e")
            prevHandler?.uncaughtException(t, e)
        }

        val header = StringBuilder("Slimpy 2.0 - Phase 3 PoC\n\n")

        // If the previous run left a stage log that never reached a clean completion marker,
        // that's exactly the evidence needed to diagnose a crash that happened with the app
        // closed and nothing watching — show it now, automatically, no action required.
        val prevSession = CrashLog.readPreviousSession(this)
        if (prevSession != null) {
            header.append("=== previous session diagnostic log ===\n").append(prevSession)
            if (!prevSession.contains("flow: completed")) {
                header.append("\n(previous session did not reach a clean completion marker — capturing this app's own logcat tail)\n")
                header.append(CrashLog.captureOwnLogcatTail()).append('\n')
            }
            header.append("=== end previous session log ===\n\n")
            CrashLog.rotate(this)
        }
        CrashLog.stage(this, "app start")

        header.append("ABI list: ").append(Build.SUPPORTED_ABIS.joinToString()).append('\n')
        try {
            System.loadLibrary("slimpy")
            rustOk = true
            header.append("libslimpy.so: LOADED\n")
            header.append("native api version: ").append(NativeBridge.nativeApiVersion()).append('\n')
            header.append("native fib(50): ").append(NativeBridge.nativeFib(50)).append("  (expected 12586269025)\n")
            val crashLogPath = CrashLog.logFile(this).absolutePath
            val rc = NativeBridge.nativeInstallCrashHandler(crashLogPath)
            header.append("native crash handler installed: ${if (rc == 0) "yes" else "FAILED rc=$rc"}\n")
        } catch (t: Throwable) {
            header.append("libslimpy.so: FAILED -> ").append(t).append('\n')
        }

        reportView = TextView(this).apply {
            text = header.toString()
            setTextColor(Color.rgb(0xCF, 0xE8, 0xEC))
            typeface = Typeface.MONOSPACE
            textSize = 12f
            setPadding(32, 32, 32, 32)
        }

        val detectBtn = Button(this).apply {
            text = "Detect Installed Minecraft"
            setOnClickListener { detectInstalled() }
        }
        val manualBtn = Button(this).apply {
            text = "Manual import (base + splits)"
            setOnClickListener { pickApks() }
        }
        val hookBtn = Button(this).apply {
            text = "Run loader self-test"
            setOnClickListener { runHookSelfTest() }
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(0x12, 0x14, 0x16))
            addView(detectBtn)
            addView(manualBtn)
            addView(hookBtn)
            addView(reportView)
        }
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun append(line: String) {
        // Called from background import/load threads as well as the UI thread; TextView must
        // only be touched on the UI thread. runOnUiThread runs inline if already there.
        runOnUiThread { reportView.append("\n" + line) }
    }

    private fun detectInstalled() {
        append("\n--- detecting installed Minecraft ---")
        // Copying a 150-300MB base+split set, running the dependency walk, and classloading a
        // huge native library are all real, multi-second blocking work — doing that on the main
        // thread (the previous bug) blocks UI input dispatch long enough to trigger an ANR / get
        // backgrounded. Run it off the main thread; append() is already UI-thread-safe.
        Thread {
            try {
                CrashLog.stage(this, "detect: start")
                val d = MinecraftImport.detectInstalled(this)
                CrashLog.stage(this, "detect: got info installed=${d.installed}")
                append(d.message)
                if (!d.installed) return@Thread
                d.sources.forEach { s -> append("  ${s.label}: ${if (s.file?.canRead() == true) "readable" else "NOT readable"} (${s.file?.path})") }
                if (d.readableSources.size != d.sources.size) {
                    append("some files aren't directly readable on this ROM — tap 'Manual import' and pick the base APK + split APKs yourself (e.g. exported with a local split-APK export tool, NOT a download from another site)")
                }
                CrashLog.stage(this, "import: start")
                val result = MinecraftImport.importFromDetected(this, d)
                CrashLog.stage(this, "import: done ok=${result.ok}")
                append("import ok=${result.ok}: ${result.message}")
                finishImport(result)
            } catch (t: Throwable) {
                CrashLog.stage(this, "detect/import threw: $t")
                android.util.Log.e("Slimpy", "detect/import crashed", t)
                append("UNCAUGHT ${t.javaClass.name}: ${t.message}")
                t.stackTrace.take(6).forEach { append("  at $it") }
            }
        }.start()
    }

    private fun pickApks() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        startActivityForResult(intent, REQUEST_PICK_APKS)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_PICK_APKS || resultCode != RESULT_OK) return
        val uris: List<Uri> = buildList {
            data?.clipData?.let { clip -> for (i in 0 until clip.itemCount) add(clip.getItemAt(i).uri) }
            data?.data?.let { add(it) }
        }
        if (uris.isEmpty()) { append("import: no files returned"); return }
        append("\n--- importing ${uris.size} picked file(s) ---")
        Thread {
            try {
                val result = MinecraftImport.importFromPickedUris(this, uris)
                append("import ok=${result.ok}: ${result.message}")
                finishImport(result)
            } catch (t: Throwable) {
                android.util.Log.e("Slimpy", "manual import crashed", t)
                append("UNCAUGHT ${t.javaClass.name}: ${t.message}")
                t.stackTrace.take(6).forEach { append("  at $it") }
            }
        }.start()
    }

    private fun finishImport(result: McImportResult) {
        if (result.inventory.isNotEmpty()) {
            append("full native-lib inventory across supplied files (${result.inventory.size} entries):")
            result.inventory.distinct().sorted().forEach { append("  $it") }
        }
        if (!result.ok) return
        if (!rustOk) { append("cannot dlopen: libslimpy.so was not loaded"); return }
        val libPath = result.mainLibPath?.absolutePath ?: run { append("no mainLibPath"); return }

        val libDir = result.libDir
        if (libDir != null && rustOk) {
            CrashLog.stage(this, "deps: start")
            append("\n--- dependency report (real ELF DT_NEEDED walk) ---")
            append(NativeBridge.nativeDependencyReport(libDir.absolutePath, "libminecraftpe.so"))
            CrashLog.stage(this, "deps: done")
        }
        if (libDir == null) { append("no libDir to load from"); return }

        val baseApk = result.baseApkFile
        if (baseApk == null) { append("no staged base.apk to host — cannot run Mojang's own Application init"); return }

        append("\n--- running Mojang's Application.attachBaseContext()+onCreate() via DexClassLoader ---")
        append("applicationClassName from manifest: ${result.applicationClassName ?: "<none>"}")
        CrashLog.stage(this, "native-load: about to host ${result.applicationClassName} (base.apk route, not raw System.load)")
        val load = NativeLoader.loadMinecraftViaApplication(this, libDir, baseApk, result.applicationClassName)
        CrashLog.stage(this, "native-load: returned ok=${load.ok}")
        if (load.ok) {
            append("MINECRAFT APPLICATION INIT: SUCCESS — ${load.message}")
            CrashLog.stage(this, "flow: completed")
        } else {
            append("MINECRAFT APPLICATION INIT: FAILED — ${load.message}")
        }
    }

    private fun runHookSelfTest() {
        if (!rustOk) { append("cannot run self-test: libslimpy.so was not loaded"); return }
        append("\n--- loader self-test ---")
        Thread {
            try {
                append(NativeBridge.nativeHookSelfTest())
            } catch (t: Throwable) {
                android.util.Log.e("Slimpy", "hook self-test crashed", t)
                append("UNCAUGHT ${t.javaClass.name}: ${t.message}")
            }
        }.start()
    }

    companion object {
        private const val REQUEST_PICK_APKS = 1001
    }
}
