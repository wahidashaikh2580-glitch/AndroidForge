package com.slimpy.app

import android.content.Context
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * A plain text stage log in app-private storage. Each stage() call appends one line and syncs
 * the fd, so it survives a crash (including a native one the Rust signal handler also writes to
 * the same file) that happens immediately after. Read back and shown automatically on the NEXT
 * launch — this is how a crash gets diagnosed without a PC: nothing needs to be running at the
 * moment it happens, since the file is already on disk.
 */
object CrashLog {
    private val timeFmt = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)

    fun logFile(context: Context): File = File(context.filesDir, "slimpy_diag.log")

    @Synchronized
    fun stage(context: Context, stage: String) {
        try {
            FileOutputStream(logFile(context), true).use { fos ->
                fos.write("${timeFmt.format(Date())} $stage\n".toByteArray())
                fos.fd.sync()
            }
        } catch (_: Throwable) {
            // logging must never itself be the thing that crashes the app
        }
    }

    fun readPreviousSession(context: Context): String? {
        val f = logFile(context)
        return if (f.isFile && f.length() > 0) try { f.readText() } catch (_: Throwable) { null } else null
    }

    /** Called once the previous session's log has been shown, so it isn't re-shown on every
     *  future launch — a fresh file starts for the current session. */
    fun rotate(context: Context) {
        val f = logFile(context)
        if (f.isFile) try { f.delete() } catch (_: Throwable) {}
    }

    /**
     * Reads this app's OWN logcat output. The restriction requiring the signature-level
     * READ_LOGS permission applies to reading OTHER apps' log entries — an app reading its own
     * UID's output has been allowed without any permission since Android 4.1. Some OEM builds
     * restrict this further; failure is reported plainly rather than hidden.
     */
    fun captureOwnLogcatTail(
        matchHints: List<String> = listOf("slimpy", "fatal", "signal", "androidruntime", "debug", "tombstone", "crash"),
    ): String = try {
        val proc = ProcessBuilder("logcat", "-d", "-t", "800").redirectErrorStream(true).start()
        val all = proc.inputStream.bufferedReader().readText()
        proc.waitFor()
        val filtered = all.lineSequence().filter { line -> matchHints.any { line.contains(it, ignoreCase = true) } }.toList()
        if (filtered.isEmpty()) {
            "(logcat read OK, ${all.lineSequence().count()} line(s), none matched crash-related keywords)"
        } else {
            filtered.takeLast(100).joinToString("\n")
        }
    } catch (t: Throwable) {
        "could not read logcat from within the app: $t (if this keeps failing, your OEM restricts it further and a PC with adb would be the fallback)"
    }
}
