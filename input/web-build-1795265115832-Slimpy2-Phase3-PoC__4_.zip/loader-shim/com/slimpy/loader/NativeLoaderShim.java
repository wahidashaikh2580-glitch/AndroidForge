package com.slimpy.loader;

/**
 * Loaded by its OWN DexClassLoader (librarySearchPath = Slimpy's staged lib dir), never by the
 * app's normal classloader. The point is solely that code defined by that classloader, calling
 * System.load/loadLibrary, binds to that classloader's linker namespace — so the library it loads
 * (and that library's own bare-soname DT_NEEDED dependencies) can be resolved from the staged
 * directory instead of only the app's own nativeLibraryDir.
 */
public final class NativeLoaderShim {
    private NativeLoaderShim() {}

    public static void loadAbsolute(String path) {
        System.load(path);
    }

    public static void loadByName(String name) {
        System.loadLibrary(name);
    }
}
