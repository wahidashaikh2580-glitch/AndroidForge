package org.levimc.launcher.ui.activities;

import static org.levimc.launcher.core.minecraft.MinecraftProcessRestarterKt.ACTION_MAIN_ACTIVITY_FIRST_DRAWN;
import static org.levimc.launcher.core.minecraft.MinecraftProcessRestarterKt.EXTRA_CLOSE_RESTART_ACTIVITY_ON_FIRST_DRAW;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.EditText;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.levimc.launcher.R;
import org.levimc.launcher.core.auth.MsftAccountStore;
import org.levimc.launcher.core.minecraft.LaunchTrace;
import org.levimc.launcher.core.minecraft.MinecraftLauncher;
import org.levimc.launcher.core.versions.GameVersion;
import org.levimc.launcher.core.versions.VersionManager;
import org.levimc.launcher.databinding.ActivityMainBinding;
import org.levimc.launcher.settings.FeatureSettings;
import org.levimc.launcher.ui.dialogs.CustomAlertDialog;
import org.levimc.launcher.ui.views.MainViewModel;
import org.levimc.launcher.ui.views.MainViewModelFactory;
import org.levimc.launcher.util.ApkImportManager;
import org.levimc.launcher.util.StorageAccess;

import java.util.ArrayList;
import java.util.List;

/** Compact launcher screen: pick a version, import an APK, sign in, launch. */
public class MainActivity extends BaseActivity {
    private ActivityMainBinding binding;
    private MinecraftLauncher minecraftLauncher;
    private ApkImportManager apkImportManager;
    private MainViewModel viewModel;
    private VersionManager versionManager;
    private ActivityResultLauncher<Intent> apkImportResultLauncher;
    private ActivityResultLauncher<Intent> accountLoginLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        closeLauncherRestartAfterFirstDraw();

        apkImportResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (apkImportManager != null) apkImportManager.handleActivityResult(result.getResultCode(), result.getData());
                });
        accountLoginLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(), result -> refreshAccountChip());

        binding.launchButton.setEnabled(false);
        binding.launchButton.setOnClickListener(v -> launchGame());
        binding.selectVersionButton.setOnClickListener(v -> showVersionPopup());
        binding.importApkButton.setOnClickListener(v -> {
            if (apkImportManager != null) apkImportResultLauncher.launch(StorageAccess.downloadsPicker(false));
        });
        binding.accountButton.setOnClickListener(v ->
                accountLoginLauncher.launch(new Intent(this, AccountsActivity.class)));

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                finishAffinity();
            }
        });

        minecraftLauncher = new MinecraftLauncher(this);
        viewModel = new ViewModelProvider(this, new MainViewModelFactory(getApplication())).get(MainViewModel.class);
        apkImportManager = new ApkImportManager(this, viewModel);
        initializeVersionManager();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleMinecraftUriLaunch();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshAccountChip();
        if (versionManager != null) {
            updateVersionText();
            binding.launchButton.setEnabled(true);
        }
    }

    private void closeLauncherRestartAfterFirstDraw() {
        Intent intent = getIntent();
        if (intent == null || !intent.getBooleanExtra(EXTRA_CLOSE_RESTART_ACTIVITY_ON_FIRST_DRAW, false)) return;
        intent.removeExtra(EXTRA_CLOSE_RESTART_ACTIVITY_ON_FIRST_DRAW);
        setIntent(intent);
        final View root = binding.getRoot();
        root.getViewTreeObserver().addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener() {
            @Override
            public boolean onPreDraw() {
                if (root.getViewTreeObserver().isAlive()) root.getViewTreeObserver().removeOnPreDrawListener(this);
                root.post(() -> {
                    hideSystemUI();
                    sendBroadcast(new Intent(ACTION_MAIN_ACTIVITY_FIRST_DRAWN).setPackage(getPackageName()));
                });
                return true;
            }
        });
    }

    private void initializeVersionManager() {
        versionManager = VersionManager.getIfInitialized();
        if (versionManager != null) {
            onVersionManagerReady();
            return;
        }
        VersionManager.initializeAsync(this, manager -> runOnUiThread(() -> {
            if (isFinishing() || isDestroyed()) return;
            versionManager = manager;
            onVersionManagerReady();
        }));
    }

    private void onVersionManagerReady() {
        if (binding == null) return;
        binding.launchButton.setEnabled(true);
        updateVersionText();
        GameVersion selected = versionManager.getSelectedVersion();
        if (selected != null) {
            viewModel.setCurrentVersion(selected);
            if (selected.needsRepair) VersionManager.attemptRepairLibs(this, selected);
        }
        handleMinecraftUriLaunch();
    }

    private void refreshAccountChip() {
        if (binding == null) return;
        String label = getString(R.string.sign_in);
        for (MsftAccountStore.MsftAccount account : MsftAccountStore.list(this)) {
            if (account.active && !TextUtils.isEmpty(account.minecraftUsername)) {
                label = account.minecraftUsername;
                break;
            }
        }
        binding.accountButton.setText(label);
    }

    private void updateVersionText() {
        if (binding == null) return;
        GameVersion selected = versionManager != null ? versionManager.getSelectedVersion() : null;
        String name = displayName(selected);
        binding.textMinecraftVersion.setText(TextUtils.isEmpty(name) ? getString(R.string.not_found_version) : name);
    }

    private void handleMinecraftUriLaunch() {
        Intent intent = getIntent();
        if (intent == null || versionManager == null) return;
        if (intent.getBooleanExtra("LAUNCH_WITH_URI", false)) {
            intent.removeExtra("LAUNCH_WITH_URI");
            setIntent(intent);
            binding.getRoot().post(this::launchGame);
        }
    }

    // ---- launching ----------------------------------------------------------------------

    private void launchGame() {
        if (versionManager == null) {
            Toast.makeText(this, R.string.loading, Toast.LENGTH_SHORT).show();
            return;
        }
        binding.launchButton.setEnabled(false);
        LaunchTrace trace = LaunchTrace.create(null);
        trace.milestone("Launch requested");
        GameVersion version = versionManager.getSelectedVersion();
        if (version == null) {
            binding.launchButton.setEnabled(true);
            new CustomAlertDialog(this)
                    .setTitleText(getString(R.string.dialog_title_no_version))
                    .setMessage(getString(R.string.dialog_message_no_version))
                    .setPositiveButton(getString(R.string.dialog_positive_ok), null)
                    .show();
            return;
        }
        if (FeatureSettings.getInstance().isLauncherManagedMcLoginEnabled() && !hasActiveAccount()) {
            binding.launchButton.setEnabled(true);
            new CustomAlertDialog(this)
                    .setTitleText(getString(R.string.dialog_title_login_required))
                    .setMessage(getString(R.string.dialog_message_login_required))
                    .setPositiveButton(getString(R.string.go_to_accounts),
                            v -> accountLoginLauncher.launch(new Intent(this, AccountsActivity.class)))
                    .setNegativeButton(getString(R.string.disable_launcher_login_and_continue), null)
                    .show();
            return;
        }
        try {
            Intent launchIntent = createMinecraftLaunchIntent();
            launchIntent.putExtra(LaunchTrace.EXTRA_SESSION_ID, trace.getSessionId());
            launchIntent.putExtra(LaunchTrace.EXTRA_STARTED_ELAPSED_MS,
                    android.os.SystemClock.elapsedRealtime() - trace.elapsedMs());
            minecraftLauncher.launch(launchIntent, version, new MinecraftLauncher.LaunchCallback() {
                @Override
                public void onLaunchStarted() {
                    trace.milestone("Loading screen requested");
                }

                @Override
                public void onLaunchFailed(Exception e) {
                    trace.error("Launch failed before loading screen", e.getMessage());
                    runOnUiThread(() -> {
                        if (binding != null) binding.launchButton.setEnabled(true);
                    });
                }
            });
        } catch (Exception e) {
            binding.launchButton.setEnabled(true);
            new CustomAlertDialog(this)
                    .setTitleText(getString(R.string.dialog_title_launch_failed))
                    .setMessage(getString(R.string.dialog_message_launch_failed, e.getMessage()))
                    .setPositiveButton(getString(R.string.dialog_positive_ok), null)
                    .show();
        }
    }

    private boolean hasActiveAccount() {
        for (MsftAccountStore.MsftAccount account : MsftAccountStore.list(this)) {
            if (account.active && !TextUtils.isEmpty(account.minecraftUsername)) return true;
        }
        return false;
    }

    private Intent createMinecraftLaunchIntent() {
        Intent launchIntent = new Intent();
        Intent source = getIntent();
        if (source == null) return launchIntent;
        String minecraftUri = source.getStringExtra("MINECRAFT_URI");
        Uri data = source.getData();
        if (data != null && "minecraft".equalsIgnoreCase(data.getScheme())) {
            launchIntent.setAction(Intent.ACTION_VIEW);
            launchIntent.setData(data);
        } else if (!TextUtils.isEmpty(minecraftUri)) {
            Uri restored = Uri.parse(minecraftUri);
            if ("minecraft".equalsIgnoreCase(restored.getScheme())) {
                launchIntent.setAction(Intent.ACTION_VIEW);
                launchIntent.setData(restored);
            }
        }
        if (!TextUtils.isEmpty(minecraftUri)) launchIntent.putExtra("MINECRAFT_URI", minecraftUri);
        if (source.hasExtra("MINECRAFT_URI_ACTION")) {
            launchIntent.putExtra("MINECRAFT_URI_ACTION", source.getStringExtra("MINECRAFT_URI_ACTION"));
        }
        return launchIntent;
    }

    // ---- version picker -----------------------------------------------------------------

    private void showVersionPopup() {
        if (versionManager == null) return;
        List<GameVersion> all = new ArrayList<>();
        List<GameVersion> installed = versionManager.getInstalledVersions();
        List<GameVersion> custom = versionManager.getCustomVersions();
        if (installed != null) all.addAll(installed);
        if (custom != null) all.addAll(custom);

        View popupView = LayoutInflater.from(this).inflate(R.layout.popup_instance_selector, null);
        PopupWindow popup = new PopupWindow(popupView, ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, true);
        popup.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        popup.setElevation(16f);
        popup.setOutsideTouchable(true);

        RecyclerView recycler = popupView.findViewById(R.id.recycler_instances);
        recycler.setLayoutManager(new LinearLayoutManager(this));
        VersionAdapter adapter = new VersionAdapter(all, versionManager.getSelectedVersion());
        recycler.setAdapter(adapter);
        EditText search = popupView.findViewById(R.id.search_input);
        search.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { adapter.filter(s.toString()); }
            @Override public void afterTextChanged(android.text.Editable s) {}
        });
        adapter.listener = version -> {
            versionManager.selectVersion(version);
            viewModel.setCurrentVersion(version);
            updateVersionText();
            popup.dismiss();
        };
        popup.showAsDropDown(binding.selectVersionButton, 0, 4);
    }

    private static String displayName(GameVersion v) {
        if (v == null) return "";
        String name = v.displayName == null ? "" : v.displayName.trim();
        if (!TextUtils.isEmpty(v.versionCode)) {
            String suffix = " (" + v.versionCode + ")";
            if (name.endsWith(suffix)) name = name.substring(0, name.length() - suffix.length()).trim();
        }
        if (!TextUtils.isEmpty(name)) return name;
        if (!TextUtils.isEmpty(v.directoryName)) return v.directoryName;
        return TextUtils.isEmpty(v.versionCode) ? "" : v.versionCode;
    }

    private static class VersionAdapter extends RecyclerView.Adapter<VersionAdapter.VH> {
        interface Listener { void onClick(GameVersion version); }

        private final List<GameVersion> all;
        private List<GameVersion> shown;
        private final GameVersion selected;
        Listener listener;

        VersionAdapter(List<GameVersion> versions, GameVersion selected) {
            this.all = versions;
            this.shown = new ArrayList<>(versions);
            this.selected = selected;
        }

        void filter(String query) {
            String q = query == null ? "" : query.toLowerCase();
            shown = new ArrayList<>();
            for (GameVersion v : all) {
                if (q.isEmpty() || displayName(v).toLowerCase().contains(q)
                        || (v.versionCode != null && v.versionCode.toLowerCase().contains(q))) shown.add(v);
            }
            notifyDataSetChanged();
        }

        @NonNull @Override
        public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new VH(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_instance_popup, parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull VH holder, int position) {
            GameVersion v = shown.get(position);
            boolean isSelected = selected != null && selected.directoryName != null
                    && selected.directoryName.equals(v.directoryName);
            holder.name.setText(displayName(v));
            holder.version.setText(v.versionCode == null ? "" : v.versionCode);
            holder.version.setVisibility(TextUtils.isEmpty(v.versionCode) ? View.GONE : View.VISIBLE);
            holder.itemView.setActivated(isSelected);
            holder.check.setVisibility(isSelected ? View.VISIBLE : View.GONE);
            holder.tag.setVisibility(View.GONE);
            holder.itemView.setOnClickListener(x -> { if (listener != null) listener.onClick(v); });
        }

        @Override public int getItemCount() { return shown.size(); }

        static class VH extends RecyclerView.ViewHolder {
            final TextView name, version, tag;
            final android.widget.ImageView check;
            VH(View v) {
                super(v);
                name = v.findViewById(R.id.instance_name);
                version = v.findViewById(R.id.instance_version);
                tag = v.findViewById(R.id.instance_tag);
                check = v.findViewById(R.id.instance_check);
            }
        }
    }
}
