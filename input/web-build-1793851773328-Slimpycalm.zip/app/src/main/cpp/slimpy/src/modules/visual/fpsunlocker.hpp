#pragma once

#include "../Module.hpp"
#include <EGL/egl.h>
#include <atomic>
#include <cstdint>
#include <time.h>

class FPSUnlockerModule : public Module {
public:
    FPSUnlockerModule();
    void onInit() override;
    void onEnable() override;
    void onDisable() override;
    void onFrame() override;
    void onMenuRegistered() override;
    bool showInLegacyMenu(std::string_view key) const override { return key != "targetFPS"; }

    void loadConfig(const nlohmann::json& j) override;
    void saveConfig(nlohmann::json& j) override;

private:
    // Preset index -> frame cap. Index 0 is "Unlimited" (VSync off, no cap).
    static constexpr int kPresets[] = {0, 30, 60, 90, 120, 144, 165};
    static constexpr int kPresetCount = static_cast<int>(sizeof(kPresets) / sizeof(kPresets[0]));
    std::atomic<int> m_preset{0};
    static int presetForFps(int fps);

    struct timespec m_lastFrameTime = {};
    bool m_hasLastFrame = false;
    EGLDisplay m_appliedDisplay = EGL_NO_DISPLAY;
    EGLSurface m_appliedSurface = EGL_NO_SURFACE;
};
