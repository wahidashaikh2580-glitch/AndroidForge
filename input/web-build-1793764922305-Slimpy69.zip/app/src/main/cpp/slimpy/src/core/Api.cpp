#include <slimpy/Api.hpp>
#include <slimpy/events/EventBus.hpp>
#include <slimpy/memory/Signatures.hpp>
#include "GameHooks.hpp"

namespace {
std::uintptr_t resolveSignature(std::uint16_t id) {
    if (id >= static_cast<std::uint16_t>(slimpy::memory::SignatureId::Count)) return 0;
    return slimpy::memory::resolve(static_cast<slimpy::memory::SignatureId>(id));
}

slimpy::sdk::ClientInstance* clientInstance() {
    return reinterpret_cast<slimpy::sdk::ClientInstance*>(slimpy::core::gamehooks::clientInstance());
}

std::uint64_t subscribe(slimpy::events::EventType type, slimpy::events::EventPriority priority, slimpy::api::EventCallback callback, void* userData) {
    if (!callback) return 0;
    return slimpy::events::bus().subscribeRaw(type, [type, callback, userData](void* payload) { callback(type, payload, userData); }, priority);
}

void unsubscribe(std::uint64_t subscription) {
    slimpy::events::bus().unsubscribe(subscription);
}

const slimpy::api::ApiV1 api{
    slimpy::api::AbiVersion,
    sizeof(slimpy::api::ApiV1),
    resolveSignature,
    clientInstance,
    subscribe,
    unsubscribe
};
}

extern "C" SLIMPY_API const slimpy::api::ApiV1* Slimpy_GetApi(std::uint32_t version) {
    return version == slimpy::api::AbiVersion ? &api : nullptr;
}
