#include "core/Runtime.hpp"
#include <pl/Mod.hpp>

class SlimpyMod {
public:
    static SlimpyMod& instance() {
        static SlimpyMod mod;
        return mod;
    }

    bool load(pl::mod::ModContext& context) { return slimpy::core::Runtime::get().load(context); }
    bool enable(pl::mod::ModContext& context) { return slimpy::core::Runtime::get().enable(context); }
    bool disable(pl::mod::ModContext& context) { return slimpy::core::Runtime::get().disable(context); }
    bool unload(pl::mod::ModContext& context) { return slimpy::core::Runtime::get().unload(context); }
};

PL_REGISTER_MOD(SlimpyMod, SlimpyMod::instance())
