#pragma once
#include "../Module.hpp"
#include "hudtext.hpp"
#include <chrono>

// Counts rendered frames and refreshes the displayed value on a fixed interval.
class FpsCounterModule : public Module {
public:
    FpsCounterModule();
    void onEnable() override;
    void onFrame() override;
    void loadConfig(const nlohmann::json& j) override;
    void saveConfig(nlohmann::json& j) override;

private:
    slimpy::hud::Style m_style;
    std::chrono::steady_clock::time_point m_windowStart{};
    int m_frames = 0;
    std::string m_text = "FPS: --";
    bool m_label = true;
};
