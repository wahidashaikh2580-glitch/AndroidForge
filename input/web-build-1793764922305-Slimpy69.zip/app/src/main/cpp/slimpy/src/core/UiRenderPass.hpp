#pragma once

namespace slimpy::core::uirender {

using Callback = void (*)(void*, void*);
bool subscribe(Callback callback);

}
