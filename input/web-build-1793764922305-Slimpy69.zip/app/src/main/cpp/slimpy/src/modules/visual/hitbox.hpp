#pragma once

#include "../Module.hpp"
#include <slimpy/sdk/Types.hpp>
#include <cstdint>

// Simple hitbox overlay: one colour, players and/or other entities, optionally yourself.
class HitboxModule : public Module {
public:
    HitboxModule();
    ~HitboxModule() override;

    void onInit() override;
    void onEnable() override;
    void onDisable() override;
    void loadConfig(const nlohmann::json& j) override;
    void saveConfig(nlohmann::json& j) override;

    bool showEntities = true;
    bool showPlayers = true;
    bool showSelf = false;
    uint32_t hitboxColor = 0xFFFFFFFF; // AARRGGBB

private:
    bool m_patched;
    void* m_patchTarget;
    void applyPatch();
};
