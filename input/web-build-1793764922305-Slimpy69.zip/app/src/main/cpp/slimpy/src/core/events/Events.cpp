#include <slimpy/events/EventBus.hpp>

namespace slimpy::events {

EventBus& bus() {
    static EventBus instance;
    return instance;
}

}
