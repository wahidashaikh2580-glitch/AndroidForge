#pragma once
#include "../Module.hpp"
#include <cstdint>

// Draws an outline around the block the player is currently targeting.
// Zero per-frame work while disabled: the render hook is installed on first
// enable and returns immediately when the module is off.
class BlockOverlayModule : public Module {
public:
    BlockOverlayModule();
    ~BlockOverlayModule() override;

    void onInit() override;
    void onEnable() override;
    void loadConfig(const nlohmann::json& j) override;
    void saveConfig(nlohmann::json& j) override;

    std::uint32_t lineColor = 0xFF000000u; // AARRGGBB

private:
    bool m_patched = false;
    void* m_patchTarget = nullptr;
};
