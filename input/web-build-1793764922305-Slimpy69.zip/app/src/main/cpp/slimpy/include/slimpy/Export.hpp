#pragma once

#if defined(__GNUC__) || defined(__clang__)
#define SLIMPY_API __attribute__((visibility("default")))
#else
#define SLIMPY_API
#endif
