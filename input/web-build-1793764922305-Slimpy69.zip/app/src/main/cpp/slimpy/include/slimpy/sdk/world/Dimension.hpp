#pragma once

#include <slimpy/sdk/Memory.hpp>
#include <slimpy/sdk/Offsets.hpp>
#include <slimpy/sdk/world/BlockSource.hpp>
#include <slimpy/sdk/world/Weather.hpp>

namespace slimpy::sdk {

class Dimension {
public:
    BlockSource* blockSource() { return field<BlockSource*>(this, offsets::Dimension::mBlockSource); }
    Weather* weather() { return field<Weather*>(this, offsets::Dimension::mWeather); }
};

}
