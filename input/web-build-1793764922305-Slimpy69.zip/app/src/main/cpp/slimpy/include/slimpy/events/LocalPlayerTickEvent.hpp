#pragma once

#include <slimpy/events/Event.hpp>

namespace slimpy::sdk { class Player; }

namespace slimpy::events {

struct LocalPlayerTickEvent {
    static constexpr EventType type = EventType::LocalPlayerTick;
    sdk::Player* player;
};

}
