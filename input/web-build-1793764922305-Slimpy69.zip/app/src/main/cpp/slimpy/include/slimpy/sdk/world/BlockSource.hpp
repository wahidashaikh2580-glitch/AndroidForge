#pragma once

#include <slimpy/sdk/Memory.hpp>
#include <slimpy/sdk/Offsets.hpp>

namespace slimpy::sdk {

class BlockSource {
public:
    int dimensionId() {
        return virtualCall<int>(this, offsets::VTable::BlockSource_getDimensionId);
    }
};

}
