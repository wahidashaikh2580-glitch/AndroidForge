#pragma once

#include <cstdint>
#include <string_view>

namespace slimpy {

inline constexpr std::string_view Name = "Slimpy";
inline constexpr std::string_view Author = "Slimpy";
inline constexpr std::string_view Description = "Lightweight performance tools for Minecraft Bedrock.";
inline constexpr std::string_view Version = "0.1.0";
inline constexpr std::uint32_t SdkVersion = 1;
inline constexpr std::string_view RuntimeLibrary = "libSlimpy.so";

}
