package com.slimpy.app

import android.content.Context
import dalvik.system.DexClassLoader
import java.io.File
import java.lang.reflect.InvocationTargetException
import java.security.MessageDigest

/**
 * Loads Minecraft's native library through a DexClassLoader whose librarySearchPath is Slimpy's
 * staged lib directory (see this file's earlier revision for why a raw JNI dlopen can't do this).
 *
 * Android 14+ additionally refuses to dynamically load a dex file that is writable
 * ("SecurityException: Writable dex file ... is not allowed"), to stop a loaded dex being
 * swapped out after it was trusted. The fix here follows the documented pattern: write the dex
 * to a fresh, content-addressed path, call File.setReadOnly() (which on Android clears the write
 * bit for owner/group/other), verify canWrite() is now false, and only THEN hand it to
 * DexClassLoader. Naming the file by the content hash of the asset — rather than a fixed name —
 * means a future, different shim is a different file, never a write to one that may already be
 * loaded; stale versions are swept on the next load.
 */
object NativeLoader {
    data class LoadResult(val ok: Boolean, val message: String)

    fun loadMinecraft(context: Context, libDir: File, mainLibAbsolutePath: String): LoadResult {
        val dexBytes = try {
            context.assets.open("slimpy_loader.dex").use { it.readBytes() }
        } catch (t: Throwable) {
            return LoadResult(false, "could not read bundled loader shim asset: $t")
        }
        val hash = MessageDigest.getInstance("SHA-256").digest(dexBytes).joinToString("") { "%02x".format(it) }.take(16)
        val dexDir = File(context.codeCacheDir, "slimpy_loader_dex").apply { mkdirs() }
        val dexFile = File(dexDir, "shim_$hash.dex")

        // Never reuse a stale version from a previous build; one content hash == one immutable file.
        dexDir.listFiles()?.forEach { f -> if (f.name != dexFile.name) f.delete() }

        if (!dexFile.isFile) {
            val tmp = File(dexDir, "shim_$hash.dex.tmp")
            tmp.delete()
            try {
                tmp.outputStream().use { it.write(dexBytes) }
            } catch (t: Throwable) {
                return LoadResult(false, "could not write dex: $t")
            }
            if (!tmp.setReadOnly()) return LoadResult(false, "setReadOnly() on $tmp returned false")
            if (tmp.canWrite()) return LoadResult(false, "verification failed: $tmp still writable after setReadOnly()")
            if (!tmp.renameTo(dexFile)) {
                tmp.delete()
                return LoadResult(false, "could not finalize $dexFile (rename failed)")
            }
        }
        if (dexFile.canWrite()) return LoadResult(false, "refusing to load: $dexFile is writable")

        val optimizedDir = File(context.codeCacheDir, "slimpy_dex_opt").apply { mkdirs() }
        return try {
            val loader = DexClassLoader(dexFile.absolutePath, optimizedDir.absolutePath, libDir.absolutePath, context.classLoader)
            val shim = Class.forName("com.slimpy.loader.NativeLoaderShim", true, loader)
            val method = shim.getMethod("loadAbsolute", String::class.java)
            method.invoke(null, mainLibAbsolutePath)
            LoadResult(true, "loaded via DexClassLoader(librarySearchPath=${libDir.path}), shim=${dexFile.name} (read-only=${!dexFile.canWrite()})")
        } catch (t: InvocationTargetException) {
            LoadResult(false, "native load failed: ${t.targetException}")
        } catch (t: Throwable) {
            LoadResult(false, "loader setup failed: $t")
        }
    }
}
