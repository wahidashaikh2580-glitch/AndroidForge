package com.slimpy.app

import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import java.io.File
import java.util.zip.ZipFile

data class McImportResult(
    val ok: Boolean,
    val message: String,
    val packageName: String? = null,
    val versionName: String? = null,
    val versionCode: Long? = null,
    val libDir: File? = null,
    val mainLibPath: File? = null,
    val inventory: List<String> = emptyList(),
)

/** One package (base.apk, or a split) the installed Minecraft is made of. */
data class McApkSource(val label: String, val file: File? = null, val uri: Uri? = null)

object MinecraftImport {
    private const val PACKAGE = "com.mojang.minecraftpe"
    private const val ARCH = "arm64-v8a"

    // ---------------------------------------------------------------------------------------
    // 1) Detect the Play-Store install and point at its real base/split files on disk.
    //    Android's stock SELinux policy grants `appdomain` read on `apk_data_file`, so a normal
    //    (non-privileged) app can usually open another app's installed APK by its exact path —
    //    this is how third-party "APK extractor" apps work without root. Some OEM builds tighten
    //    this further; detectInstalled() reports the real per-file read result rather than
    //    assuming either way.
    // ---------------------------------------------------------------------------------------
    data class DetectResult(
        val installed: Boolean,
        val versionName: String? = null,
        val versionCode: Long? = null,
        val sources: List<McApkSource> = emptyList(),
        val readableSources: List<McApkSource> = emptyList(),
        val nativeLibraryDir: File? = null,
        val message: String,
    )

    fun detectInstalled(context: Context): DetectResult {
        val pm = context.packageManager
        val info = try {
            pm.getPackageInfo(PACKAGE, PackageManager.GET_ACTIVITIES)
        } catch (e: PackageManager.NameNotFoundException) {
            return DetectResult(false, message = "$PACKAGE is not installed on this device (or is hidden from this app by package visibility)")
        }
        @Suppress("DEPRECATION")
        val versionCode = if (android.os.Build.VERSION.SDK_INT >= 28) info.longVersionCode else info.versionCode.toLong()
        val appInfo = info.applicationInfo
            ?: return DetectResult(true, info.versionName, versionCode, message = "installed, but ApplicationInfo was null (unexpected)")

        val sources = buildList {
            add(McApkSource("base.apk", File(appInfo.sourceDir)))
            appInfo.splitSourceDirs?.forEachIndexed { i, path -> add(McApkSource("split[$i]: ${File(path).name}", File(path))) }
        }
        val readable = sources.filter { it.file?.canRead() == true }
        // nativeLibraryDir is the directory the OS itself already assembled from ALL installed
        // splits for this package (including any that aren't plain "config" splits, e.g. ABI-
        // specific feature libraries) — a more authoritative source for native libs than
        // re-deriving the set from the split APK zips ourselves.
        val nativeLibDir = appInfo.nativeLibraryDir?.let { File(it) }?.takeIf { it.isDirectory }
        val msg = buildString {
            append("detected $PACKAGE $versionCode (${sources.size} file(s)), ${readable.size} directly readable")
            if (nativeLibDir != null) append("; OS native lib dir: ${nativeLibDir.path} (${if (nativeLibDir.canRead()) "readable, ${nativeLibDir.list()?.size ?: 0} file(s)" else "NOT readable"})")
            else append("; OS native lib dir: not reported")
        }
        return DetectResult(true, info.versionName, versionCode, sources, readable, nativeLibDir, msg)
    }

    /** Imports using whichever of the detected base+split files could actually be opened, THEN
     *  overlays every file from the OS's own merged native-library directory on top — that
     *  directory is the ground truth for exactly which .so files this install actually has. */
    fun importFromDetected(context: Context, detected: DetectResult): McImportResult {
        if (detected.readableSources.isEmpty()) return McImportResult(false, "nothing readable to import — use manual split import")
        val streams = detected.readableSources.mapNotNull { it.file }.map { it.name to it.inputStream() }
        val result = importFromStreams(context, streams, detected.versionCode ?: 0L)
        if (!result.ok || result.libDir == null) return result

        val nld = detected.nativeLibraryDir
        if (nld != null && nld.canRead()) {
            var merged = 0
            nld.listFiles { f -> f.isFile && f.name.endsWith(".so") }?.forEach { f ->
                try { f.copyTo(File(result.libDir, f.name), overwrite = true); merged++ } catch (_: Throwable) {}
            }
            val mainLib = result.mainLibPath ?: File(result.libDir, "libminecraftpe.so").takeIf { it.isFile }
            return result.copy(
                message = result.message + "; merged $merged file(s) from OS native lib dir (${result.libDir.list()?.size ?: 0} total staged)",
                mainLibPath = mainLib,
            )
        }
        return result
    }

    /** Manual fallback: the user picks the base APK plus every split APK via the system file
     *  picker (multi-select). This covers devices/ROMs where direct path reads are blocked, and
     *  is explicitly NOT a request to download Minecraft from anywhere — only to re-point Slimpy
     *  at files the user already has (e.g. exported from their own install with a local APK/split
     *  export tool, or a debug build they placed in Downloads). */
    fun importFromPickedUris(context: Context, uris: List<Uri>): McImportResult {
        if (uris.isEmpty()) return McImportResult(false, "no files selected")
        val streams = uris.map { uri ->
            val name = queryDisplayName(context, uri) ?: uri.lastPathSegment ?: "apk"
            name to (context.contentResolver.openInputStream(uri) ?: return McImportResult(false, "could not open $uri"))
        }
        return importFromStreams(context, streams, versionCodeHint = 0L)
    }

    private fun queryDisplayName(context: Context, uri: Uri): String? =
        context.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }

    /** Common path: validates package identity from whichever file is the base APK, then merges
     *  lib/arm64-v8a/ across ALL supplied files (base + every split) into one staged directory,
     *  since Play's App Bundle splits commonly carry native libs in a separate config split from
     *  the base APK. */
    private fun importFromStreams(context: Context, named: List<Pair<String, java.io.InputStream>>, versionCodeHint: Long): McImportResult {
        val stagingDir = File(context.cacheDir, "slimpy_mc_import_staged").apply { mkdirs() }
        val stagedFiles = mutableListOf<File>()
        try {
            for ((name, input) in named) {
                val f = File(stagingDir, name.replace(Regex("[^A-Za-z0-9._-]"), "_"))
                try {
                    input.use { ins -> f.outputStream().use { out -> ins.copyTo(out) } }
                } catch (t: Throwable) {
                    return McImportResult(false, "copying $name failed: $t")
                }
                stagedFiles.add(f)
            }

            val pm = context.packageManager
            var pkg: String? = null
            var versionName: String? = null
            var versionCode = versionCodeHint
            for (f in stagedFiles) {
                val info = pm.getPackageArchiveInfo(f.path, 0) ?: continue
                if (info.packageName.isNotEmpty()) {
                    pkg = info.packageName
                    versionName = info.versionName
                    @Suppress("DEPRECATION")
                    versionCode = if (android.os.Build.VERSION.SDK_INT >= 28) info.longVersionCode else info.versionCode.toLong()
                    break // the base APK carries the manifest; splits usually don't re-declare it
                }
            }
            if (pkg == null) return McImportResult(false, "none of the ${stagedFiles.size} supplied file(s) parse as part of an Android package (none carries a manifest)")
            if (!pkg.startsWith("com.mojang.minecraft")) return McImportResult(false, "package is '$pkg', expected 'com.mojang.minecraft*'")

            val destRoot = File(context.filesDir, "mc_import/$versionCode")
            val destLibDir = File(destRoot, "lib/$ARCH")
            destLibDir.mkdirs()
            var mainLib: File? = null
            var extractedAny = false
            val prefix = "lib/$ARCH/"
            val libEntryRegex = Regex("^lib/([^/]+)/([^/]+\\.so)$")
            val inventory = mutableListOf<String>()
            for (f in stagedFiles) {
                try {
                    ZipFile(f).use { zip ->
                        for (entry in zip.entries()) {
                            if (entry.isDirectory) continue
                            // full inventory across every ABI, for diagnosis of what this APK set actually ships
                            libEntryRegex.matchEntire(entry.name)?.let { m ->
                                inventory.add("${m.groupValues[1]}/${m.groupValues[2]} (in ${f.name})")
                            }
                            if (!entry.name.startsWith(prefix)) continue
                            val fileName = entry.name.substring(prefix.length)
                            if (fileName.isEmpty() || fileName.contains('/')) continue
                            val outFile = File(destLibDir, fileName)
                            zip.getInputStream(entry).use { ins -> outFile.outputStream().use { out -> ins.copyTo(out) } }
                            extractedAny = true
                            if (fileName == "libminecraftpe.so") mainLib = outFile
                        }
                    }
                } catch (t: Throwable) {
                    // one bad/irrelevant split shouldn't abort the whole merge; keep going.
                }
            }
            if (!extractedAny) return McImportResult(false, "no lib/$ARCH/ in any of the ${stagedFiles.size} supplied file(s) — arm32-only build, or the native-lib split wasn't included", inventory = inventory)
            if (mainLib == null) return McImportResult(false, "lib/$ARCH/ was found (${destLibDir.list()?.size ?: 0} file(s)) but libminecraftpe.so was not among them", pkg, versionName, versionCode, destLibDir, inventory = inventory)
            return McImportResult(true, "imported $pkg $versionName ($versionCode) from ${stagedFiles.size} file(s), ${destLibDir.list()?.size} native libraries staged", pkg, versionName, versionCode, destLibDir, mainLib, inventory)
        } finally {
            stagedFiles.forEach { it.delete() }
            stagingDir.delete()
        }
    }
}
