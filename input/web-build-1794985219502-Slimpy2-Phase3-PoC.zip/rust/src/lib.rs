//! Slimpy 2.0 - Phase 2 proof of concept. No dependencies, no game integration.
//! Exports three JNI functions so the Kotlin host can prove the Rust -> APK path end to end.
use std::os::raw::c_void;

const SLIMPY_ABI_VERSION: i32 = 1;

#[no_mangle]
pub extern "system" fn Java_com_slimpy_app_NativeBridge_nativeApiVersion(
    _env: *mut c_void,
    _class: *mut c_void,
) -> i32 {
    SLIMPY_ABI_VERSION
}

#[no_mangle]
pub extern "system" fn Java_com_slimpy_app_NativeBridge_nativePointerBits(
    _env: *mut c_void,
    _class: *mut c_void,
) -> i32 {
    usize::BITS as i32
}

#[no_mangle]
pub extern "system" fn Java_com_slimpy_app_NativeBridge_nativeFib(
    _env: *mut c_void,
    _class: *mut c_void,
    n: i32,
) -> i64 {
    fib(n)
}

fn fib(n: i32) -> i64 {
    let n = n.clamp(0, 90);
    let (mut a, mut b) = (0i64, 1i64);
    for _ in 0..n {
        let t = a + b;
        a = b;
        b = t;
    }
    a
}

#[cfg(test)]
mod tests {
    use super::fib;
    #[test]
    fn fib_values() {
        assert_eq!(fib(0), 0);
        assert_eq!(fib(10), 55);
        assert_eq!(fib(50), 12_586_269_025);
        assert_eq!(fib(1000), fib(90));
    }
}

// =================================================================================================
// PHASE 3 — independent native loader: import a dlopen'd module, resolve one real RTTI/vtable
// target inside it, and prove inline-patch mechanics against that target. No game-specific feature
// hooks are installed; this only proves the loader's addressing and memory-patch machinery work
// against a live, resolved address — either inside the imported Minecraft library, or, if that
// library can't be resolved (see nativeImportMinecraft), against Slimpy's own exported JNI function
// as an honest fallback so the result never silently claims more than what was actually verified.
// =================================================================================================

use jni::objects::{JClass, JString};
use jni::sys::{jint as jni_jint, jstring};
use jni::JNIEnv;
use std::ffi::{CStr, CString};
use std::fs;
use std::sync::{Mutex, OnceLock};

static MC_HANDLE: OnceLock<Mutex<Option<usize>>> = OnceLock::new();
static LAST_ERROR: OnceLock<Mutex<String>> = OnceLock::new();

fn mc_handle_slot() -> &'static Mutex<Option<usize>> {
    MC_HANDLE.get_or_init(|| Mutex::new(None))
}
fn last_error_slot() -> &'static Mutex<String> {
    LAST_ERROR.get_or_init(|| Mutex::new(String::new()))
}
fn set_last_error(msg: String) {
    *last_error_slot().lock().unwrap() = msg;
}

#[derive(Clone)]
struct Region {
    start: usize,
    end: usize,
    perms: String,
    path: String,
}

/// Parses this process's own /proc/self/maps. No external crate needed: the format is a stable
/// kernel ABI, and we only need start/end/perms/pathname.
fn read_maps() -> Vec<Region> {
    let data = fs::read_to_string("/proc/self/maps").unwrap_or_default();
    let mut out = Vec::new();
    for line in data.lines() {
        let mut parts = line.splitn(6, ' ');
        let range = parts.next().unwrap_or("");
        let perms = parts.next().unwrap_or("").to_string();
        parts.next(); // offset
        parts.next(); // dev
        parts.next(); // inode
        let path = parts.next().unwrap_or("").trim().to_string();
        if let Some((a, b)) = range.split_once('-') {
            if let (Ok(start), Ok(end)) = (usize::from_str_radix(a, 16), usize::from_str_radix(b, 16)) {
                out.push(Region { start, end, perms, path });
            }
        }
    }
    out
}

fn module_regions(basename: &str) -> Vec<Region> {
    read_maps()
        .into_iter()
        .filter(|r| r.path.rsplit('/').next() == Some(basename))
        .collect()
}

/// Brute-force byte search restricted to readable mappings. Correct but O(n); fine for a one-shot
/// resolve, not for anything called per-frame.
unsafe fn scan_for_bytes(region: &Region, needle: &[u8]) -> Vec<usize> {
    if !region.perms.starts_with('r') || needle.is_empty() {
        return Vec::new();
    }
    let len = region.end.saturating_sub(region.start);
    if len < needle.len() {
        return Vec::new();
    }
    let slice = std::slice::from_raw_parts(region.start as *const u8, len);
    let mut hits = Vec::new();
    let mut i = 0usize;
    while i + needle.len() <= slice.len() {
        if &slice[i..i + needle.len()] == needle {
            hits.push(region.start + i);
        }
        i += 1;
    }
    hits
}

/// 8-byte-aligned pointer-value search restricted to readable mappings.
unsafe fn scan_for_pointer(region: &Region, target: usize) -> Vec<usize> {
    if !region.perms.starts_with('r') {
        return Vec::new();
    }
    let start = (region.start + 7) & !7usize;
    let end = region.end & !7usize;
    let mut hits = Vec::new();
    let mut p = start;
    while p + 8 <= end {
        if std::ptr::read_unaligned(p as *const usize) == target {
            hits.push(p);
        }
        p += 8;
    }
    hits
}

/// Resolves a C++ virtual-function slot by Itanium-ABI RTTI layout, against this process's OWN
/// already-relocated memory (we dlopen the target ourselves, so pointers are live — no static ELF
/// relocation math needed, unlike tooling that inspects the file on disk):
///   type_info struct:  { vptr, name_ptr, ... }        name_ptr -> "<len><MangledClassName>\0"
///   vtable layout:      { offset_to_top, typeinfo_ptr, vfunc[0], vfunc[1], ... }
/// Steps: find the bare type-name string -> find a word pointing at it (= typeinfo's name field,
/// so typeinfo starts one word earlier) -> find a word pointing at that typeinfo (= the vtable's
/// typeinfo slot) -> the function slots start one word after that. Every resolved function pointer
/// must land inside an executable region of the SAME module or the result is rejected (fail closed).
fn resolve_vtable_slot(module_basename: &str, mangled_type_name: &str, slot: usize) -> Result<usize, String> {
    let regions = module_regions(module_basename);
    if regions.is_empty() {
        return Err(format!("module '{module_basename}' is not mapped in this process"));
    }
    let mut needle = mangled_type_name.as_bytes().to_vec();
    needle.push(0);

    let mut name_addrs = Vec::new();
    for r in &regions {
        name_addrs.extend(unsafe { scan_for_bytes(r, &needle) });
    }
    if name_addrs.is_empty() {
        return Err(format!("RTTI name string '{mangled_type_name}' not found in {module_basename}"));
    }

    for name_addr in name_addrs {
        for r in &regions {
            for name_ptr_loc in unsafe { scan_for_pointer(r, name_addr) } {
                let typeinfo_addr = match name_ptr_loc.checked_sub(8) {
                    Some(v) => v,
                    None => continue,
                };
                for r2 in &regions {
                    for ti_ptr_loc in unsafe { scan_for_pointer(r2, typeinfo_addr) } {
                        let address_point = ti_ptr_loc + 8;
                        let slot_loc = address_point + slot * 8;
                        if regions.iter().all(|m| slot_loc + 8 > m.end || slot_loc < m.start) {
                            continue;
                        }
                        let func = unsafe { std::ptr::read_unaligned(slot_loc as *const usize) };
                        let in_exec_region = regions
                            .iter()
                            .any(|rr| rr.perms.contains('x') && func >= rr.start && func < rr.end);
                        if in_exec_region {
                            return Ok(func);
                        }
                    }
                }
            }
        }
    }
    Err(format!(
        "RTTI name for '{mangled_type_name}' found but no candidate vtable slot {slot} resolved to executable code in {module_basename}"
    ))
}

#[cfg(target_arch = "aarch64")]
unsafe fn clear_instruction_cache(addr: usize, len: usize) {
    const LINE: usize = 64; // conservative; real line size queried via ctr_el0 is unnecessary for 4 bytes
    let end = addr + len;
    let mut a = addr & !(LINE - 1);
    while a < end {
        std::arch::asm!("dc cvau, {0}", in(reg) a);
        a += LINE;
    }
    std::arch::asm!("dsb ish");
    let mut a = addr & !(LINE - 1);
    while a < end {
        std::arch::asm!("ic ivau, {0}", in(reg) a);
        a += LINE;
    }
    std::arch::asm!("dsb ish");
    std::arch::asm!("isb");
}

#[cfg(not(target_arch = "aarch64"))]
unsafe fn clear_instruction_cache(_addr: usize, _len: usize) {}

/// Proves real inline-patch mechanics against `addr`: make the page RWX, overwrite the first
/// instruction with an AArch64 NOP, flush the instruction cache, read back to confirm the write
/// landed, then immediately restore the original bytes and flush again. Nothing ever executes the
/// patched instruction (the target is never invoked during this test), so this is safe to run
/// against live code without side effects — but it is only a mechanism self-test, not an installed,
/// persistent feature hook.
unsafe fn hook_self_test(addr: usize) -> Result<(), String> {
    let page_size = 4096usize;
    let page = addr & !(page_size - 1);
    let region_len = page_size * 2;
    if libc::mprotect(page as *mut libc::c_void, region_len, libc::PROT_READ | libc::PROT_WRITE | libc::PROT_EXEC) != 0 {
        return Err(format!("mprotect(RWX) failed, errno {}", std::io::Error::last_os_error()));
    }
    let ptr = addr as *mut u32;
    let original = std::ptr::read_unaligned(ptr);
    const AARCH64_NOP: u32 = 0xD503_201F;
    std::ptr::write_unaligned(ptr, AARCH64_NOP);
    clear_instruction_cache(addr, 4);
    let after_write = std::ptr::read_unaligned(ptr);
    std::ptr::write_unaligned(ptr, original);
    clear_instruction_cache(addr, 4);
    let after_restore = std::ptr::read_unaligned(ptr);
    if after_write != AARCH64_NOP {
        return Err("write did not take effect (read-back mismatch)".to_string());
    }
    if after_restore != original {
        return Err(format!(
            "CRITICAL: restore failed — original=0x{original:08x} now=0x{after_restore:08x}"
        ));
    }
    Ok(())
}

/// Attempts to dlopen the given absolute path (the extracted libminecraftpe.so) into THIS process.
/// Returns 0 on success. On failure, the dlopen error (commonly a missing sibling dependency such
/// as libc++_shared.so or libfmod.so when only one file was extracted) is recorded for
/// nativeLastError() rather than hidden.
#[no_mangle]
pub extern "system" fn Java_com_slimpy_app_NativeBridge_nativeImportMinecraft(
    mut env: JNIEnv,
    _class: JClass,
    path: JString,
) -> jni_jint {
    let path_str: String = match env.get_string(&path) {
        Ok(s) => s.into(),
        Err(e) => {
            set_last_error(format!("invalid path string: {e}"));
            return -1;
        }
    };
    let cpath = match CString::new(path_str) {
        Ok(c) => c,
        Err(e) => {
            set_last_error(format!("path contains NUL: {e}"));
            return -2;
        }
    };
    unsafe {
        libc::dlerror(); // clear any stale error
        let handle = libc::dlopen(cpath.as_ptr(), libc::RTLD_NOW | libc::RTLD_GLOBAL);
        if handle.is_null() {
            let err = libc::dlerror();
            let msg = if err.is_null() {
                "dlopen failed, no dlerror() message available".to_string()
            } else {
                CStr::from_ptr(err).to_string_lossy().into_owned()
            };
            set_last_error(msg);
            return -3;
        }
        *mc_handle_slot().lock().unwrap() = Some(handle as usize);
    }
    set_last_error(String::new());
    0
}

#[no_mangle]
pub extern "system" fn Java_com_slimpy_app_NativeBridge_nativeLastError<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
) -> jstring {
    let msg = last_error_slot().lock().unwrap().clone();
    match env.new_string(msg) {
        Ok(s) => s.into_raw(),
        Err(_) => std::ptr::null_mut(),
    }
}

/// Runs the Phase 3 loader self-test and returns a short, human-readable, line-based report.
/// Order of attempts (each line states exactly what was tried and the real outcome):
///   1. Is libminecraftpe.so loaded in this process? (only true after a prior successful
///      nativeImportMinecraft call)
///   2. If so, resolve LivePlayerRenderer's vtable slot 17 inside it via RTTI.
///   3. Run the patch/flush/verify/restore self-test against whichever address step 2 resolved.
///   4. If Minecraft's library isn't loaded or the slot can't be resolved, fall back to Slimpy's
///      OWN exported nativeFib JNI function as the self-test target, and say so explicitly — never
///      silently claim the Minecraft-specific result when it wasn't actually obtained.
#[no_mangle]
pub extern "system" fn Java_com_slimpy_app_NativeBridge_nativeHookSelfTest<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
) -> jstring {
    let mut lines: Vec<String> = Vec::new();
    let mc_loaded = module_regions("libminecraftpe.so").len() > 0;
    lines.push(format!("libminecraftpe.so mapped in process: {mc_loaded}"));

    let mut target: Option<(usize, &'static str)> = None;
    if mc_loaded {
        match resolve_vtable_slot("libminecraftpe.so", "18LivePlayerRenderer", 17) {
            Ok(addr) => {
                lines.push(format!("resolved LivePlayerRenderer vtable slot 17 @ 0x{addr:x}"));
                target = Some((addr, "libminecraftpe.so LivePlayerRenderer::slot17 (RTTI-resolved)"));
            }
            Err(e) => lines.push(format!("vtable resolution failed: {e}")),
        }
    }

    let (addr, label) = target.unwrap_or_else(|| {
        let f = Java_com_slimpy_app_NativeBridge_nativeFib as usize;
        lines.push("falling back to Slimpy's own nativeFib export as the self-test target".to_string());
        (f, "libslimpy.so nativeFib (fallback target, NOT Minecraft)")
    });

    match unsafe { hook_self_test(addr) } {
        Ok(()) => lines.push(format!("PATCH/RESTORE SELF-TEST: PASSED against {label} @ 0x{addr:x}")),
        Err(e) => lines.push(format!("PATCH/RESTORE SELF-TEST: FAILED against {label} @ 0x{addr:x} — {e}")),
    }

    let report = lines.join("\n");
    match env.new_string(report) {
        Ok(s) => s.into_raw(),
        Err(_) => std::ptr::null_mut(),
    }
}
