package com.slimpy.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var reportView: TextView
    private var rustOk = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val header = StringBuilder("Slimpy 2.0 - Phase 3 PoC\n\n")
        header.append("ABI list: ").append(Build.SUPPORTED_ABIS.joinToString()).append('\n')
        try {
            System.loadLibrary("slimpy")
            rustOk = true
            header.append("libslimpy.so: LOADED\n")
            header.append("native api version: ").append(NativeBridge.nativeApiVersion()).append('\n')
            header.append("native fib(50): ").append(NativeBridge.nativeFib(50)).append("  (expected 12586269025)\n")
        } catch (t: Throwable) {
            header.append("libslimpy.so: FAILED -> ").append(t).append('\n')
        }

        reportView = TextView(this).apply {
            text = header.toString()
            setTextColor(Color.rgb(0xCF, 0xE8, 0xEC))
            typeface = Typeface.MONOSPACE
            textSize = 12f
            setPadding(32, 32, 32, 32)
        }

        val importBtn = Button(this).apply {
            text = "Import Minecraft APK"
            setOnClickListener { pickApk() }
        }
        val hookBtn = Button(this).apply {
            text = "Run loader self-test"
            setOnClickListener { runHookSelfTest() }
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(0x12, 0x14, 0x16))
            addView(importBtn)
            addView(hookBtn)
            addView(reportView)
        }
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun append(line: String) {
        reportView.append("\n" + line)
    }

    private fun pickApk() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*" // APKs are rarely offered a dedicated MIME type by document providers
        }
        startActivityForResult(intent, REQUEST_PICK_APK)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_PICK_APK || resultCode != RESULT_OK) return
        val uri: Uri = data?.data ?: run { append("import: no file returned"); return }
        append("\n--- importing ${uri} ---")
        val result = MinecraftImport.import(this, uri)
        append("import ok=${result.ok}: ${result.message}")
        if (!result.ok) return
        if (!rustOk) { append("cannot dlopen: libslimpy.so was not loaded"); return }

        val libPath = result.mainLibPath?.absolutePath ?: run { append("no mainLibPath"); return }
        val rc = NativeBridge.nativeImportMinecraft(libPath)
        if (rc == 0) {
            append("nativeImportMinecraft: SUCCESS (dlopen of $libPath)")
        } else {
            append("nativeImportMinecraft: FAILED rc=$rc")
            append("dlopen error: ${NativeBridge.nativeLastError()}")
            append("(a missing-symbol/library error here usually means a sibling .so the engine depends on wasn't in lib/arm64-v8a/ of this APK, or needs to be resolved via the full launcher-hosting path rather than a bare dlopen)")
        }
    }

    private fun runHookSelfTest() {
        if (!rustOk) { append("cannot run self-test: libslimpy.so was not loaded"); return }
        append("\n--- loader self-test ---")
        append(NativeBridge.nativeHookSelfTest())
    }

    companion object {
        private const val REQUEST_PICK_APK = 1001
    }
}
