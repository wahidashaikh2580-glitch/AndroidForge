package com.slimpy.app

import android.content.Context
import android.content.pm.PackageManager
import java.io.File
import java.util.zip.ZipFile

/** Result of validating + extracting a user-supplied Minecraft Bedrock APK. */
data class McImportResult(
    val ok: Boolean,
    val message: String,
    val packageName: String? = null,
    val versionName: String? = null,
    val versionCode: Long? = null,
    val libDir: File? = null,
    val mainLibPath: File? = null,
)

/**
 * Imports a legitimately user-provided Minecraft Bedrock APK: validates it, then copies the WHOLE
 * arm64-v8a native-library directory (not just libminecraftpe.so) into app-private storage, since
 * the engine's sibling dependencies (libc++_shared.so, libfmod.so, etc., whatever the APK ships)
 * must sit next to it for the dynamic linker to resolve DT_NEEDED entries. Nothing proprietary is
 * bundled with Slimpy's own source/distribution — this only ever touches the user's own copy, on
 * their own device, at runtime.
 */
object MinecraftImport {
    private const val EXPECTED_PACKAGE_PREFIX = "com.mojang.minecraft"
    private const val ARCH = "arm64-v8a"

    fun import(context: Context, apkUri: android.net.Uri): McImportResult {
        val pm = context.packageManager
        val stagedApk = File(context.cacheDir, "slimpy_mc_import_staged.apk")
        try {
            context.contentResolver.openInputStream(apkUri)?.use { input ->
                stagedApk.outputStream().use { output -> input.copyTo(output) }
            } ?: return McImportResult(false, "could not open the picked file")
        } catch (t: Throwable) {
            return McImportResult(false, "copy failed: $t")
        }

        val info = pm.getPackageArchiveInfo(stagedApk.path, PackageManager.GET_ACTIVITIES)
            ?: run {
                stagedApk.delete()
                return McImportResult(false, "not a parseable Android package")
            }
        val pkg = info.packageName
        if (!pkg.startsWith(EXPECTED_PACKAGE_PREFIX)) {
            stagedApk.delete()
            return McImportResult(false, "package is '$pkg', expected '$EXPECTED_PACKAGE_PREFIX*' — this is not a Minecraft Bedrock APK")
        }
        val versionName = info.versionName
        @Suppress("DEPRECATION")
        val versionCode = if (android.os.Build.VERSION.SDK_INT >= 28) info.longVersionCode else info.versionCode.toLong()

        val destRoot = File(context.filesDir, "mc_import/$versionCode")
        val destLibDir = File(destRoot, "lib/$ARCH")
        destLibDir.mkdirs()

        var extractedAny = false
        var mainLib: File? = null
        try {
            ZipFile(stagedApk).use { zip ->
                val prefix = "lib/$ARCH/"
                for (entry in zip.entries()) {
                    if (entry.isDirectory || !entry.name.startsWith(prefix)) continue
                    val fileName = entry.name.substring(prefix.length)
                    if (fileName.isEmpty() || fileName.contains('/')) continue // no nested dirs expected here
                    val outFile = File(destLibDir, fileName)
                    zip.getInputStream(entry).use { input ->
                        outFile.outputStream().use { output -> input.copyTo(output) }
                    }
                    extractedAny = true
                    if (fileName == "libminecraftpe.so") mainLib = outFile
                }
            }
        } catch (t: Throwable) {
            stagedApk.delete()
            return McImportResult(false, "extraction failed: $t")
        }
        stagedApk.delete()

        if (!extractedAny) {
            return McImportResult(false, "APK has no lib/$ARCH/ — it may be arm32-only or a bundle split without native libs; Slimpy is arm64-v8a only")
        }
        if (mainLib == null) {
            return McImportResult(
                false,
                "lib/$ARCH/ was extracted (${destLibDir.list()?.size ?: 0} files) but libminecraftpe.so was not among them",
                pkg, versionName, versionCode, destLibDir,
            )
        }
        return McImportResult(true, "imported $pkg $versionName ($versionCode), ${destLibDir.list()?.size} native libraries staged", pkg, versionName, versionCode, destLibDir, mainLib)
    }
}
