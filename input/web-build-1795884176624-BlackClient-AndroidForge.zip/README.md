# Black Client

Minimal Android Minecraft Bedrock client/launcher project with an arm64 native mod.

## AndroidForge build settings

This archive is laid out as a normal Gradle project: `settings.gradle`, `gradlew`, `gradle/`, `app/`, `minecraft/`, and `pojav_controls/` are at the ZIP root.

1. Upload this ZIP to AndroidForge.
2. Choose **Android** and select the **debug** build variant.
3. Download the `AndroidForge-APKs` artifact after the workflow succeeds.

The project is configured for this toolchain:

| Component | Version / setting |
|---|---|
| Android Gradle Plugin | 8.13.2 |
| Gradle wrapper | 8.13 |
| Kotlin Gradle plugin | 2.3.0 |
| JDK | 17 |
| Compile SDK | 36 |
| Target SDK | 35 |
| Minimum SDK | 28 |
| Android NDK | 28.2.13676358 (r28c) |
| CMake | 3.22.1 |
| Android Build Tools | 35.0.0 |
| ABI | `arm64-v8a` only |

The root Gradle script checks for Android Build Tools 35.0.0 and installs it with `sdkmanager` when the SDK is available but the package is missing. AndroidForge's current build image includes Build Tools through 34.0.0, so this check fills that gap before the Android modules are configured. AndroidForge also installs the project's missing compile SDK, NDK, and CMake components through its workflow.

### Build requirements

- Internet access is required for Gradle/Maven dependencies and CMake `FetchContent` downloads.
- The CMake build fetches the `preloader-android` and `libHttpClient` source trees from their upstream `main` branches because those Git submodule contents are not included in this source ZIP. These branch references are not commit-pinned, so a future upstream change can affect reproducibility.
- `nlohmann_json` 3.11.3, GLM 1.0.1, and EnTT 3.16.0 are fetched by CMake.
- The Rust source is included, but Gradle does not run Cargo. The prebuilt arm64 Rust static archive (`libblackclient_core.a`) and JNI library (`libblackclient_jni.so`) are included and used by the Android build. Rebuilding Rust code requires replacing those artifacts with matching arm64 Android builds.
- `app/google-services.json` is a placeholder configuration. It allows the Google Services Gradle plugin to configure, but it is not connected to a real Firebase project; cloud analytics or Crashlytics uploads are not configured for this build.
- Only `arm64-v8a` is packaged because the included native libraries are arm64. Other ABIs are intentionally not enabled.

### Output

The app APK is generated at `app/build/outputs/apk/debug/app-debug.apk`. AndroidForge collects it into its `AndroidForge-APKs` artifact.

## App identity and compatibility

The application ID and Java/Kotlin package remain `org.levimc.launcher`. The preloader, JNI bridge, and bundled native libraries look up classes and symbols using that package name, so changing it without rebuilding those dependencies would break native loading. This also means it may conflict with an installed Levi Launcher package; uninstall that app before installing this build.

The included native `.so` files are arm64 Android libraries. Their ELF load segments were checked in this archive and are aligned to 16 KiB boundaries. The Slimpy CMake target also passes the 16 KiB linker alignment option.

## Features

The current native module set contains 13 modules: Motion Blur, Block Overlay, Hitbox, View Model, Swing Animations, Zoom, AutoSprint, Fullbright, Tab List, Third-Person Nametag, FPS Counter, CPS Counter, and Unlock FPS.

The launcher UI uses a compact dark theme. Native module settings are stored in the mod configuration directory. FPS/CPS text formatting and configuration helpers are implemented in Rust and linked into `libSlimpy.so`.

## Important status notes

- This archive has been prepared for AndroidForge, but an AndroidForge build has **not** been run from this environment. A successful APK build and on-device launch are not verified.
- Native hook signatures target the Minecraft Bedrock version declared by the source (`1.26.60.x`) and still need validation against the exact game build on a device.
- The block overlay's block-position offset is inferred from the native struct layout and includes a runtime hit-point check; it has not been device-verified.
- The launcher retains upstream Levi code and the original application ID because several closed/prebuilt native components depend on it.
- The project has a previously reported in-game Microsoft sign-in issue that still needs device logcat validation.

## Source and licenses

The launcher source and native mod dependencies retain their upstream license notices in this archive. See `LICENSE`, `NOTICE`, and the bundled component notices before redistributing a build.
