#pragma once
// Shared helpers for Slimpy's text HUD modules (FPS / CPS).
#include "../ModuleRegistry.hpp"
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <string>
#include <vector>

extern "C" {
float blackclient_text_width(const char* text, float size);
int blackclient_parse_color(const char* s, std::uint32_t* out);
int blackclient_format_color(std::uint32_t c, char* out, std::size_t outLen);
int blackclient_fps_text(int label, int fps, char* out, std::size_t outLen);
int blackclient_cps_text(int showLeft, int showRight, int left, int right, char* out, std::size_t outLen);
}

namespace slimpy::hud {

// Rough text width; avoids a font-metrics call per frame.
inline float textWidth(const std::string& text, float size) {
    return blackclient_text_width(text.c_str(), size);
}

// "#AARRGGBB" or "#RRGGBB" -> 0xAARRGGBB. Leaves `out` untouched on bad input.
inline void parseColor(const std::string& s, std::uint32_t& out) {
    blackclient_parse_color(s.c_str(), &out);
}

inline std::string formatColor(std::uint32_t c) {
    char buf[16] = {};
    if (blackclient_format_color(c, buf, sizeof(buf)) != 0) return {};
    return buf;
}

struct Style {
    float posX = 20.0f;
    float posY = 20.0f;
    float size = 32.0f;
    bool background = false;
    float backgroundOpacity = 0.5f;
    std::uint32_t textColor = 0xFFFFFFFFu;

    void load(const nlohmann::json& j) {
        posX = j.value("hudPosX", posX);
        posY = j.value("hudPosY", posY);
        size = j.value("m_size", size);
        if (size < 8.0f) size = 8.0f;
        if (size > 100.0f) size = 100.0f;
        background = j.value("m_background", background);
        backgroundOpacity = j.value("m_backgroundOpacity", backgroundOpacity);
        if (j.contains("m_textColor") && j["m_textColor"].is_string())
            parseColor(j["m_textColor"].get<std::string>(), textColor);
    }
    void save(nlohmann::json& j) const {
        j["isHudModule"] = true;
        j["hudPosX"] = posX;
        j["hudPosY"] = posY;
        j["m_size"] = size;
        j["m_background"] = background;
        j["m_backgroundOpacity"] = backgroundOpacity;
        j["m_textColor"] = formatColor(textColor);
    }
};

inline void submit(const std::string& moduleId, const Style& style, const std::string& text) {
    PLModMenu_DrawCommand cmds[2] = {};
    int n = 0;
    const float w = textWidth(text, style.size) + 12.0f;
    const float h = style.size + 8.0f;
    if (style.background) {
        auto& bg = cmds[n++];
        bg.type = PL_DRAW_RECT_FILLED;
        bg.x = style.posX; bg.y = style.posY; bg.w = w; bg.h = h;
        bg.color = (static_cast<std::uint32_t>(style.backgroundOpacity * 255.0f) << 24);
    }
    auto& t = cmds[n++];
    t.type = PL_DRAW_TEXT;
    t.x = style.posX; t.y = style.posY; t.w = w; t.h = h;
    t.color = style.textColor;
    t.size = style.size;
    t.text = text.c_str();
    submitDrawCommands(moduleId, std::vector<PLModMenu_DrawCommand>(cmds, cmds + n));
}

}
