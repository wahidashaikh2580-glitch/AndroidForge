#include "fpscounter.hpp"

namespace {
constexpr auto kRefresh = std::chrono::milliseconds(500);
}

FpsCounterModule::FpsCounterModule()
    : Module("FPS Counter", "Shows the current frame rate.") {
    m_style.posY = 20.0f;
}

void FpsCounterModule::onEnable() {
    m_windowStart = std::chrono::steady_clock::now();
    m_frames = 0;
    m_text = m_label ? "FPS: --" : "--";
}

void FpsCounterModule::onFrame() {
    ++m_frames;
    const auto now = std::chrono::steady_clock::now();
    const auto elapsed = now - m_windowStart;
    if (elapsed >= kRefresh) {
        const double seconds = std::chrono::duration<double>(elapsed).count();
        const int fps = static_cast<int>(m_frames / seconds + 0.5);
        char text[32] = {};
        if (blackclient_fps_text(m_label ? 1 : 0, fps, text, sizeof(text)) == 0) {
            m_text = text;
        }
        m_frames = 0;
        m_windowStart = now;
    }
    slimpy::hud::submit(moduleId, m_style, m_text);
}

void FpsCounterModule::loadConfig(const nlohmann::json& j) {
    Module::loadConfig(j);
    m_style.load(j);
    m_label = j.value("m_showLabel", m_label);
}

void FpsCounterModule::saveConfig(nlohmann::json& j) {
    Module::saveConfig(j);
    m_style.save(j);
    j["m_showLabel"] = m_label;
}
