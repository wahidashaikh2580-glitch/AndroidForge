package com.slimpy.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.graphics.PixelFormat
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var reportView: TextView
    private var rustOk = false
    private var overlayView: View? = null
    private val minecraftPackage = "com.mojang.minecraftpe"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Net for any uncaught Java exception on any thread we didn't already wrap explicitly;
        // logs a breadcrumb before handing off to the previous (system default) handler, so
        // normal crash behavior is unchanged — this only adds a record of it.
        val prevHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            CrashLog.stage(this, "UNCAUGHT on thread '${t.name}': $e")
            prevHandler?.uncaughtException(t, e)
        }

        val header = StringBuilder("Slimpy 2.0 - Phase 3 PoC\n\n")

        // If the previous run left a stage log that never reached a clean completion marker,
        // that's exactly the evidence needed to diagnose a crash that happened with the app
        // closed and nothing watching — show it now, automatically, no action required.
        val prevSession = CrashLog.readPreviousSession(this)
        if (prevSession != null) {
            header.append("=== previous session diagnostic log ===\n").append(prevSession)
            if (!prevSession.contains("flow: completed")) {
                header.append("\n(previous session did not reach a clean completion marker — capturing this app's own logcat tail)\n")
                header.append(CrashLog.captureOwnLogcatTail()).append('\n')
            }
            header.append("=== end previous session log ===\n\n")
            CrashLog.rotate(this)
        }
        CrashLog.stage(this, "app start")

        header.append("ABI list: ").append(Build.SUPPORTED_ABIS.joinToString()).append('\n')
        try {
            System.loadLibrary("slimpy")
            rustOk = true
            header.append("libslimpy.so: LOADED\n")
            header.append("native api version: ").append(NativeBridge.nativeApiVersion()).append('\n')
            header.append("native fib(50): ").append(NativeBridge.nativeFib(50)).append("  (expected 12586269025)\n")
            val crashLogPath = CrashLog.logFile(this).absolutePath
            val rc = NativeBridge.nativeInstallCrashHandler(crashLogPath)
            header.append("native crash handler installed: ${if (rc == 0) "yes" else "FAILED rc=$rc"}\n")
        } catch (t: Throwable) {
            header.append("libslimpy.so: FAILED -> ").append(t).append('\n')
        }

        reportView = TextView(this).apply {
            text = header.toString()
            setTextColor(Color.rgb(0xCF, 0xE8, 0xEC))
            typeface = Typeface.MONOSPACE
            textSize = 12f
            setPadding(32, 32, 32, 32)
        }

        val detectBtn = Button(this).apply {
            text = "Detect Installed Minecraft"
            setOnClickListener { detectInstalled() }
        }
        val manualBtn = Button(this).apply {
            text = "Manual import (base + splits)"
            setOnClickListener { pickApks() }
        }
        val hookBtn = Button(this).apply {
            text = "Run loader self-test"
            setOnClickListener { runHookSelfTest() }
        }
        val launchBtn = Button(this).apply {
            text = "Launch Minecraft (normal, untouched)"
            setOnClickListener { launchMinecraftNormally() }
        }
        val overlayBtn = Button(this).apply {
            text = "Toggle Slimpy overlay POC"
            setOnClickListener { toggleOverlay() }
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(0x12, 0x14, 0x16))
            addView(launchBtn)
            addView(overlayBtn)
            addView(detectBtn)
            addView(manualBtn)
            addView(hookBtn)
            addView(reportView)
        }
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun append(line: String) {
        // Called from background import/load threads as well as the UI thread; TextView must
        // only be touched on the UI thread. runOnUiThread runs inline if already there.
        runOnUiThread { reportView.append("\n" + line) }
    }

    /** Launches the real, installed Minecraft exactly as the OS launcher would — no modification,
     *  no reflection, no touching its process. This is the "independent runtime integration"
     *  Slimpy can legitimately provide for a PairIP-protected build. */
    private fun launchMinecraftNormally() {
        val intent = packageManager.getLaunchIntentForPackage(minecraftPackage)
        if (intent == null) {
            append("no launch intent found for $minecraftPackage — is it installed?")
            return
        }
        CrashLog.stage(this, "launching Minecraft normally via getLaunchIntentForPackage")
        startActivity(intent)
        append("launched Minecraft normally as its own separate, untouched process")
    }

    /** Proof that Slimpy can show its own UI on top of ANY foreground app, Minecraft included,
     *  without touching Minecraft's process — the real integration point left available for the
     *  modules an external overlay can actually support (CPS counter, a HUD, etc.). Standard
     *  SYSTEM_ALERT_WINDOW mechanism; requires a one-time user grant in system settings. */
    private fun toggleOverlay() {
        if (overlayView != null) {
            (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(overlayView)
            overlayView = null
            append("overlay removed")
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            append("overlay permission not granted yet — opening system settings; grant 'display over other apps' for Slimpy, then tap this button again")
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val tv = TextView(this).apply {
            text = "Slimpy overlay active"
            setBackgroundColor(Color.argb(210, 0x0a, 0x7e, 0x8c))
            setTextColor(Color.WHITE)
            setPadding(28, 14, 28, 14)
        }
        @Suppress("DEPRECATION")
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT,
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 40; y = 220 }
        wm.addView(tv, params)
        overlayView = tv
        append("overlay shown — switch to Minecraft now; it stays visible on top with zero changes to Minecraft's process")
    }

    private fun detectInstalled() {
        append("\n--- detecting installed Minecraft ---")
        // Copying a 150-300MB base+split set, running the dependency walk, and classloading a
        // huge native library are all real, multi-second blocking work — doing that on the main
        // thread (the previous bug) blocks UI input dispatch long enough to trigger an ANR / get
        // backgrounded. Run it off the main thread; append() is already UI-thread-safe.
        Thread {
            try {
                CrashLog.stage(this, "detect: start")
                val d = MinecraftImport.detectInstalled(this)
                CrashLog.stage(this, "detect: got info installed=${d.installed}")
                append(d.message)
                if (!d.installed) return@Thread
                d.sources.forEach { s -> append("  ${s.label}: ${if (s.file?.canRead() == true) "readable" else "NOT readable"} (${s.file?.path})") }
                if (d.readableSources.size != d.sources.size) {
                    append("some files aren't directly readable on this ROM — tap 'Manual import' and pick the base APK + split APKs yourself (e.g. exported with a local split-APK export tool, NOT a download from another site)")
                }
                CrashLog.stage(this, "import: start")
                val result = MinecraftImport.importFromDetected(this, d)
                CrashLog.stage(this, "import: done ok=${result.ok}")
                append("import ok=${result.ok}: ${result.message}")
                finishImport(result)
            } catch (t: Throwable) {
                CrashLog.stage(this, "detect/import threw: $t")
                android.util.Log.e("Slimpy", "detect/import crashed", t)
                append("UNCAUGHT ${t.javaClass.name}: ${t.message}")
                t.stackTrace.take(6).forEach { append("  at $it") }
            }
        }.start()
    }

    private fun pickApks() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        startActivityForResult(intent, REQUEST_PICK_APKS)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_PICK_APKS || resultCode != RESULT_OK) return
        val uris: List<Uri> = buildList {
            data?.clipData?.let { clip -> for (i in 0 until clip.itemCount) add(clip.getItemAt(i).uri) }
            data?.data?.let { add(it) }
        }
        if (uris.isEmpty()) { append("import: no files returned"); return }
        append("\n--- importing ${uris.size} picked file(s) ---")
        Thread {
            try {
                val result = MinecraftImport.importFromPickedUris(this, uris)
                append("import ok=${result.ok}: ${result.message}")
                finishImport(result)
            } catch (t: Throwable) {
                android.util.Log.e("Slimpy", "manual import crashed", t)
                append("UNCAUGHT ${t.javaClass.name}: ${t.message}")
                t.stackTrace.take(6).forEach { append("  at $it") }
            }
        }.start()
    }

    private fun finishImport(result: McImportResult) {
        if (result.inventory.isNotEmpty()) {
            append("full native-lib inventory across supplied files (${result.inventory.size} entries):")
            result.inventory.distinct().sorted().forEach { append("  $it") }
        }
        if (!result.ok) return
        if (!rustOk) { append("cannot dlopen: libslimpy.so was not loaded"); return }
        val libPath = result.mainLibPath?.absolutePath ?: run { append("no mainLibPath"); return }

        // In-process hosting via DexClassLoader is retired: confirmed incompatible with PairIP's
        // VM-based bytecode protection (it needs the real PackageManager/Zygote-launched
        // environment, which reflection cannot recreate). Import/detect stays for information
        // only — Minecraft itself is now launched normally, as its own untouched process.
        append("import staged ${result.libDir?.list()?.size ?: 0} native lib file(s) for reference; in-process hosting is not attempted")
        CrashLog.stage(this, "flow: completed (detect/import only, no hosting)")
    }

    private fun runHookSelfTest() {
        if (!rustOk) { append("cannot run self-test: libslimpy.so was not loaded"); return }
        append("\n--- loader self-test ---")
        Thread {
            try {
                append(NativeBridge.nativeHookSelfTest())
            } catch (t: Throwable) {
                android.util.Log.e("Slimpy", "hook self-test crashed", t)
                append("UNCAUGHT ${t.javaClass.name}: ${t.message}")
            }
        }.start()
    }

    companion object {
        private const val REQUEST_PICK_APKS = 1001
    }
}
