package com.slimpy.app

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val sb = StringBuilder("Slimpy 2.0 - Phase 2 PoC\n\n")
        sb.append("ABI list: ").append(Build.SUPPORTED_ABIS.joinToString()).append('\n')
        try {
            System.loadLibrary("slimpy")
            sb.append("libslimpy.so: LOADED\n")
            sb.append("native api version: ").append(NativeBridge.nativeApiVersion()).append('\n')
            sb.append("native pointer bits: ").append(NativeBridge.nativePointerBits()).append('\n')
            sb.append("native fib(50): ").append(NativeBridge.nativeFib(50)).append("  (expected 12586269025)\n")
        } catch (t: Throwable) {
            sb.append("libslimpy.so: FAILED -> ").append(t).append('\n')
        }
        sb.append("\n--- build report (generated at build time) ---\n")
        try {
            assets.open("slimpy_build_report.txt").bufferedReader().use { sb.append(it.readText()) }
        } catch (t: Throwable) {
            sb.append("no report asset: ").append(t).append('\n')
        }
        val tv = TextView(this).apply {
            text = sb.toString()
            setTextColor(Color.rgb(0xCF, 0xE8, 0xEC))
            setBackgroundColor(Color.rgb(0x12, 0x14, 0x16))
            typeface = Typeface.MONOSPACE
            textSize = 12f
            setPadding(32, 96, 32, 32)
        }
        setContentView(ScrollView(this).apply { addView(tv) })
    }
}
