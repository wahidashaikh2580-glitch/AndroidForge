package com.slimpy.app

/** JNI boundary to libslimpy.so (Rust). Phase 2 proof of concept: three trivial calls. */
object NativeBridge {
    @JvmStatic external fun nativeApiVersion(): Int
    @JvmStatic external fun nativePointerBits(): Int
    @JvmStatic external fun nativeFib(n: Int): Long
}
