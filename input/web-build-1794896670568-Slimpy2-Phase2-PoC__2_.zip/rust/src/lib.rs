//! Slimpy 2.0 - Phase 2 proof of concept. No dependencies, no game integration.
//! Exports three JNI functions so the Kotlin host can prove the Rust -> APK path end to end.
use std::os::raw::c_void;

const SLIMPY_ABI_VERSION: i32 = 1;

#[no_mangle]
pub extern "system" fn Java_com_slimpy_app_NativeBridge_nativeApiVersion(
    _env: *mut c_void,
    _class: *mut c_void,
) -> i32 {
    SLIMPY_ABI_VERSION
}

#[no_mangle]
pub extern "system" fn Java_com_slimpy_app_NativeBridge_nativePointerBits(
    _env: *mut c_void,
    _class: *mut c_void,
) -> i32 {
    usize::BITS as i32
}

#[no_mangle]
pub extern "system" fn Java_com_slimpy_app_NativeBridge_nativeFib(
    _env: *mut c_void,
    _class: *mut c_void,
    n: i32,
) -> i64 {
    fib(n)
}

fn fib(n: i32) -> i64 {
    let n = n.clamp(0, 90);
    let (mut a, mut b) = (0i64, 1i64);
    for _ in 0..n {
        let t = a + b;
        a = b;
        b = t;
    }
    a
}

#[cfg(test)]
mod tests {
    use super::fib;
    #[test]
    fn fib_values() {
        assert_eq!(fib(0), 0);
        assert_eq!(fib(10), 55);
        assert_eq!(fib(50), 12_586_269_025);
        assert_eq!(fib(1000), fib(90));
    }
}
