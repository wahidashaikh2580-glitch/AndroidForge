# Slimpy

Minimal MCPE (Minecraft Bedrock, Android, arm64-v8a) performance client.
Modules (13): **Motion Blur, Block Overlay, Hitbox, View Model, Swing Animations, Zoom, AutoSprint, Fullbright, Tab List, Third-Person Nametag, FPS Counter, CPS Counter, Unlock FPS.**

Open this folder in Android Studio (Ladybug or newer, JDK 17, NDK 28.2.13676358).

## STATUS — stage 1 (read this first)

| Part | State |
|---|---|
| Native mod `libSlimpy.so` (`app/src/main/cpp/slimpy`) | **Written, never compiled.** 13 modules (51 -> 13 trimmed). |
| App identity | applicationId `org.levimc.launcher` (see below), label "Slimpy", icon from supplied logo. |
| Launcher Java/Kotlin (221 files) | Game launches. `libSlimpy.so` is installed as a bundled mod (`ModManager.installBundledMod`) and loaded at launch. Rest is **still Levi code**, not yet stripped. In-app logo replaced with the supplied image. |
| Build | **Never built or run.** CI-ready packaging added; first real build will likely surface errors. |

### Building from a source ZIP (AndroidForge / CI)
The ZIP root is the Gradle project root (`settings.gradle`, `gradlew`, `app/`). It is built to work without git:
- The empty `preloader` / `libHttpClient` submodules are fetched from GitHub by CMake at configure time
  (`app/src/main/cpp/CMakeLists.txt`), tracking `main` of each repo, **not pinned** — if upstream moved, pin a commit there.
- `app/google-services.json` is a **placeholder** so the Google Services plugin doesn't fail; Firebase does nothing useful with it.
  Crashlytics mapping/symbol upload is disabled. Both go away in stage 2.
- nlohmann_json 3.11.3 and glm 1.0.1 are fetched (pinned). Needs network on the build machine.
- Needs JDK 17, Gradle 8.13 (wrapper), NDK 28.2.13676358, compileSdk 36. Pick the **debug** variant; release is unsigned.
- The AndroidForge repo itself could not be read, so its exact ZIP/workflow rules are unverified.

### Deliberate deviation: package and application ID are still `org.levimc.launcher`
The preloader/bridge look up Java classes and JNI symbols by full package name, and the closed prebuilt libs
(`libgxcore.so`, `libinbuiltmods.so`) were built for the Levi package. With `com.slimpy.client`, extracted Minecraft
libraries were dropped at launch (libc++_shared.so, then libHttpClient.Android.so missing). Until those closed libs are
replaced, the app ID stays; only the label and icon are Slimpy. **Uninstall the real Levi Launcher before installing.**

## Layout
- `app/src/main/cpp/slimpy/` — native mod. One file per feature in `src/modules/{visual,hud}`.
  - `visual/motionblur`, `visual/viewmodel`, `visual/thirdpersonnametag`, `visual/fpsunlocker` (shown as "Unlock FPS"), `visual/blockoverlay`
  - `hud/fpscounter`, `hud/cpscounter`, `hud/hudtext.hpp` (shared HUD draw helper)
  - `src/config` persists settings to `config.json` in the mod's config dir (debounced, written off the render thread).
  - `src/core/memory/Signatures.cpp` — trimmed to the 46 signatures these modules use.
  - Upstream: BedrockTools by RadiantByte, MIT (`LICENSE-BedrockTools-MIT.txt`).
- Launcher: Levi Launchroid (Apache-2.0, `LICENSE`).

## How the features work
- **FPS Counter**: counts frames, refreshes the text twice per second. **CPS Counter**: observes mouse-down events (never consumes them) in a 64-entry ring buffer; no allocation on the input path.
- **Unlock FPS**: sets `eglSwapInterval(0)` and optionally sleeps to a target FPS (0 = uncapped). The display, driver or compositor can still cap frame rate; this only removes VSync.
- **Block Overlay**: hooks the level render, reads the engine hit result, draws 12 edges via the game tessellator. Zero work when disabled apart from one branch in the hook. The block position is read from `HitResult+32` and **checked against the hit point at runtime**, falling back to a ray nudge if they disagree. The offset is inferred from struct layout, not verified on a device.
- **Motion Blur / View Model / Third-Person Nametag**: unchanged upstream implementations (not yet re-audited or optimised).

## Game version
Signatures target the version declared by the upstream mod (Minecraft `1.26.60.X`). Not re-validated.

## Stage 2 (needs compile feedback)
Remove from the launcher: Firebase/Crashlytics/Play Games/billing, Microsoft login and account code, CurseForge, news/changelog,
world editor + `worldtools` native lib + `libinbuiltmods.so` (closed binary, hard-codes the Levi package), Levi inbuilt mods and overlays;
replace `MainActivity` with a small version-select/launch screen; load `libSlimpy.so` directly from `MinecraftRuntimePreparer`;
rewrite strings (1100 lines, many Levi), drop non-English locales, then re-run a leftover-branding scan.

## Stage 4 progress (launcher cleanup)
Removed: accounts / Microsoft login, news, CurseForge, world & content editor, online mod catalog, quick launch,
Firebase (analytics, crashlytics, messaging; `CrashReporter` is now local-only xCrash), update check, animated splash,
non-English locales, and 11 unreferenced classes plus all layouts nothing uses. Gradle: dropped minecraftauth,
commons-httpclient, firebase, splashscreen, games-activity, browser, play-games, glide, the google-services and
crashlytics plugins, and the placeholder `google-services.json`.
Kept on purpose: the `minecraft` module (game-side stubs, includes its own Firebase messaging code), `libgxcore.so`,
preloader, libHttpClient.
Still to do: remove `worldtools` / `libleviworld.so` and `libinbuiltmods.so` (+ Levi inbuilt mods UI), About and Instances
screens, remaining Levi strings and drawables, and replace the main screen with a small version-select + launch page.

## UI (stage 4)
Dark-only palette (`res/values/colors.xml`, mirrored in `values-night`), one blue accent. Main screen rewritten as a compact
page: logo + name, version selector + Launch, status line, mods list. About tab hidden; user-facing "Levi" text replaced in strings.
Settings, Instances and the in-game mod menu still use the old layouts, recoloured by the new palette only.

## UI lightening (stage 5)
Removed the 8 MB MiSans font (system sans-serif everywhere), made dialog/press/list animations instant (`DynamicAnim`
methods kept as no-ops), simplified the loading card, and hid five Levi in-game mods that duplicate Slimpy's native
modules or are decorative (Auto Sprint, Zoom, FPS display, CPS display, Chick Pet). Not compiled or run.

## Known issue: in-game sign-in loop
Tapping Play/Settings in Minecraft opens Microsoft sign-in, which then returns without proceeding. Cause not yet found
(first run of this project; no device log yet). Suspects: unpinned `libHttpClient`/`preloader` built from `main`; the
removed launcher account code. Enable Settings > Logcat overlay, reproduce, and capture lines mentioning xal/HttpClient/Exception.

## Microsoft sign-in (restored)
Removing the launcher's Microsoft account feature broke in-game Play / Settings / Realms / Marketplace: the game fell back to
its own browser sign-in, which cannot complete inside the launcher. The launcher-managed login is back:
sign in from the account button in the nav bar (`MsftLoginActivity`, `AccountsActivity`, `core/auth`); on launch the
credentials are exported into the game's XAL storage (`XalExporter`).
The game chooses between its own sign-in and the exported credentials by reading `launcherManagedMcLoginEnabled` from the
saved `feature_settings` JSON (`Storage.java`, `Ecdsa.java` in the minecraft module). That flag is now written on every
launch (`MinecraftRuntimePreparer`): on exactly when an account is signed in. The manual Settings switch is hidden.
Needs minecraftauth, commons-httpclient and androidx.browser.
