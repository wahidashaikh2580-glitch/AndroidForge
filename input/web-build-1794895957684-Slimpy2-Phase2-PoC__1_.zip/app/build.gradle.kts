import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.Properties
import java.util.concurrent.TimeUnit
import java.util.zip.ZipFile

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// ---------------------------------------------------------------------------------------------
// Pinned toolchain. Changing any of these is a deliberate, reviewed act.
// ---------------------------------------------------------------------------------------------
val rustToolchainVersion = "1.85.0"
val rustTarget = "aarch64-linux-android"
val androidApi = 28
val rustupHost = "https://static.rust-lang.org/rustup/dist/x86_64-unknown-linux-gnu"

val rustDir: File = rootProject.file("rust")
val rustOutDir: File = layout.buildDirectory.dir("rustJniLibs").get().asFile
val reportDir: File = layout.buildDirectory.dir("generated/slimpyAssets").get().asFile
val toolchainHome: File = rootProject.layout.buildDirectory.dir("slimpy-rust-toolchain").get().asFile
val cargoTargetDir: File = rootProject.layout.buildDirectory.dir("slimpy-cargo-target").get().asFile

android {
    namespace = "com.slimpy.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.slimpy.app"
        minSdk = 28
        targetSdk = 34
        versionCode = 1
        versionName = "2.0.0-poc"
        ndk { abiFilters += "arm64-v8a" }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    sourceSets.getByName("main") {
        jniLibs.srcDir(rustOutDir)
        assets.srcDir(reportDir)
    }
}

// ---------------------------------------------------------------------------------------------
// Helpers (plain JVM code; no Gradle plugins, no third-party build dependencies).
// ---------------------------------------------------------------------------------------------
val report = StringBuilder()

fun log(msg: String) {
    println("[slimpy-poc] $msg")
    report.append(msg).append('\n')
}

fun runCmd(
    cmd: List<String>,
    env: Map<String, String> = emptyMap(),
    dir: File = rustDir,
    timeoutMinutes: Long = 30,
): Pair<Int, String> {
    // Output goes to a file so waitFor(timeout) is the only blocking call: reading the pipe first
    // (the previous version) blocked until the child exited and made the timeout ineffective.
    val outFile = File.createTempFile("slimpy-cmd", ".log")
    try {
        val pb = ProcessBuilder(cmd).directory(dir).redirectErrorStream(true).redirectOutput(outFile)
        pb.environment().putAll(env)
        val p = pb.start()
        if (!p.waitFor(timeoutMinutes, TimeUnit.MINUTES)) {
            p.descendants().forEach { it.destroyForcibly() }
            p.destroyForcibly()
            p.waitFor(10, TimeUnit.SECONDS)
            return Pair(-2, outFile.readText() + "\n<timeout after $timeoutMinutes min: ${cmd.first()}>")
        }
        return Pair(p.exitValue(), outFile.readText())
    } catch (e: Exception) {
        return Pair(-1, "exec failed: ${e.message}")
    } finally {
        outFile.delete()
    }
}

fun which(name: String): File? =
    (System.getenv("PATH") ?: "").split(File.pathSeparator)
        .map { File(it, name) }
        .firstOrNull { it.isFile && it.canExecute() }

fun probeNetwork(url: String): String =
    try {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "HEAD"
        c.connectTimeout = 8000
        c.readTimeout = 8000
        "HTTP ${c.responseCode}"
    } catch (e: Exception) {
        "FAILED (${e.javaClass.simpleName}: ${e.message})"
    }

fun readLocalProperties(): Properties {
    val p = Properties()
    val f = rootProject.file("local.properties")
    if (f.isFile) f.inputStream().use { p.load(it) }
    return p
}

fun findNdk(): File? {
    val lp = readLocalProperties()
    val direct = listOfNotNull(
        System.getenv("ANDROID_NDK_HOME"),
        System.getenv("ANDROID_NDK_ROOT"),
        System.getenv("ANDROID_NDK_LATEST_HOME"),
        lp.getProperty("ndk.dir"),
    ).map { File(it) }
    direct.firstOrNull { File(it, "toolchains/llvm/prebuilt").isDirectory }?.let { return it }

    val sdkRoots = listOfNotNull(
        System.getenv("ANDROID_HOME"),
        System.getenv("ANDROID_SDK_ROOT"),
        lp.getProperty("sdk.dir"),
    ).map { File(it) }
    for (sdk in sdkRoots) {
        val newest = File(sdk, "ndk").listFiles()
            ?.filter { it.isDirectory && File(it, "toolchains/llvm/prebuilt").isDirectory }
            ?.maxByOrNull { it.name }
        if (newest != null) return newest
        val bundle = File(sdk, "ndk-bundle")
        if (File(bundle, "toolchains/llvm/prebuilt").isDirectory) return bundle
    }
    return null
}

fun sha256Hex(f: File): String {
    val md = MessageDigest.getInstance("SHA-256")
    f.inputStream().use { ins ->
        val buf = ByteArray(65536)
        while (true) {
            val n = ins.read(buf)
            if (n < 0) break
            md.update(buf, 0, n)
        }
    }
    return md.digest().joinToString("") { "%02x".format(it) }
}

fun download(url: String, dest: File) {
    dest.parentFile.mkdirs()
    val c = URL(url).openConnection() as HttpURLConnection
    c.connectTimeout = 15000
    c.readTimeout = 60000
    c.inputStream.use { ins -> dest.outputStream().use { ins.copyTo(it) } }
}

/** Reads an ELF header and returns a problem description, or null when it is a valid aarch64 shared object. */
fun elfProblem(f: File): String? {
    if (!f.isFile) return "missing: ${f.path}"
    val h = f.inputStream().use { it.readNBytes(64) }
    if (h.size < 64) return "too small to be an ELF file"
    if (h[0] != 0x7f.toByte() || h[1] != 'E'.code.toByte() || h[2] != 'L'.code.toByte() || h[3] != 'F'.code.toByte())
        return "bad ELF magic"
    if (h[4].toInt() != 2) return "not ELFCLASS64"
    if (h[5].toInt() != 1) return "not little-endian"
    val type = (h[16].toInt() and 0xff) or ((h[17].toInt() and 0xff) shl 8)
    val machine = (h[18].toInt() and 0xff) or ((h[19].toInt() and 0xff) shl 8)
    if (type != 3) return "e_type=$type, expected ET_DYN(3)"
    if (machine != 183) return "e_machine=$machine, expected EM_AARCH64(183)"
    return null
}

// ---------------------------------------------------------------------------------------------
// Task 1: probe + build libslimpy.so with a pinned Rust toolchain.
// ---------------------------------------------------------------------------------------------
val buildRustArm64 = tasks.register("buildRustArm64") {
    group = "slimpy"
    description = "Builds libslimpy.so (aarch64-linux-android) from rust/ with a pinned toolchain."
    inputs.files(fileTree(rustDir) { include("Cargo.toml", "Cargo.lock", "src/**") })
    outputs.dir(rustOutDir)
    outputs.dir(reportDir)

    doLast {
        report.setLength(0)
        log("== Slimpy 2.0 Phase 2 build probe ==")
        log("host: ${System.getProperty("os.name")} ${System.getProperty("os.arch")}, java ${System.getProperty("java.version")}")
        log("pinned rust toolchain: $rustToolchainVersion, target: $rustTarget, android api: $androidApi")

        // --- environment probe (facts for the report, regardless of outcome) -------------------
        val sysRustup = which("rustup") ?: File(System.getProperty("user.home"), ".cargo/bin/rustup").takeIf { it.isFile }
        val sysCargo = which("cargo")
        log("system cargo: ${sysCargo ?: "not found"}")
        log("system rustup: ${sysRustup ?: "not found"}")
        val ndk = findNdk()
        log("android ndk: ${ndk ?: "NOT FOUND"}")
        log("network static.rust-lang.org: ${probeNetwork("https://static.rust-lang.org/")}")

        fun fail(msg: String): Nothing {
            log("BLOCKER: $msg")
            reportDir.mkdirs()
            File(reportDir, "slimpy_build_report.txt").writeText(report.toString())
            throw GradleException("Slimpy Rust build failed: $msg")
        }

        if (ndk == null) {
            fail("Android NDK not found. Re-run AndroidForge with enable_ndk=true (or set ANDROID_NDK_HOME).")
        }
        val prebuilt = File(ndk, "toolchains/llvm/prebuilt").listFiles()?.firstOrNull { it.isDirectory }
            ?: fail("NDK has no toolchains/llvm/prebuilt/<host> directory")
        val ndkBin = File(prebuilt, "bin")
        val linker = File(ndkBin, "${rustTarget}${androidApi}-clang")
        val ar = File(ndkBin, "llvm-ar")
        if (!linker.isFile) fail("NDK linker not found: $linker")
        log("ndk linker: $linker")

        // --- pick or bootstrap rustup ----------------------------------------------------------
        var rustup: File? = sysRustup
        val env = HashMap<String, String>()
        if (rustup == null) {
            log("no system rustup; bootstrapping a project-local one under $toolchainHome")
            val localRustup = File(toolchainHome, "cargo/bin/rustup")
            if (!localRustup.isFile) {
                val initBin = File(toolchainHome, "rustup-init")
                val shaFile = File(toolchainHome, "rustup-init.sha256")
                try {
                    download("$rustupHost/rustup-init", initBin)
                    download("$rustupHost/rustup-init.sha256", shaFile)
                } catch (e: Exception) {
                    fail("cannot download rustup-init (${e.javaClass.simpleName}: ${e.message}). Runner has no usable network path to static.rust-lang.org.")
                }
                val expected = shaFile.readText().trim().split(Regex("\\s+")).firstOrNull().orEmpty()
                val actual = sha256Hex(initBin)
                // NOTE: the hash comes from the same host, so this detects corruption, not a hostile mirror.
                // Hardening TODO: pin a literal SHA-256 here once one has been recorded from a verified source.
                if (expected.length != 64 || expected != actual) fail("rustup-init checksum mismatch (expected=$expected actual=$actual)")
                log("rustup-init sha256 ok: $actual")
                initBin.setExecutable(true)
                val (rc, out) = runCmd(
                    listOf(initBin.path, "-y", "--no-modify-path", "--profile", "minimal", "--default-toolchain", "none"),
                    mapOf("CARGO_HOME" to File(toolchainHome, "cargo").path, "RUSTUP_HOME" to File(toolchainHome, "rustup").path),
                    toolchainHome,
                )
                if (rc != 0) fail("rustup-init failed (rc=$rc):\n$out")
            }
            rustup = localRustup
            env["CARGO_HOME"] = File(toolchainHome, "cargo").path
            env["RUSTUP_HOME"] = File(toolchainHome, "rustup").path
        }
        val cargoBin = rustup!!.parentFile
        env["PATH"] = cargoBin.path + File.pathSeparator + (System.getenv("PATH") ?: "")

        // --- install pinned toolchain + android target -----------------------------------------
        val (rc1, out1) = runCmd(
            listOf(rustup.path, "toolchain", "install", rustToolchainVersion, "--profile", "minimal", "--no-self-update", "-t", rustTarget),
            env,
        )
        if (rc1 != 0) fail("rustup toolchain install $rustToolchainVersion failed (rc=$rc1):\n$out1")
        env["RUSTUP_TOOLCHAIN"] = rustToolchainVersion
        val cargo = File(cargoBin, "cargo").path
        log("rustc: " + runCmd(listOf(File(cargoBin, "rustc").path, "--version"), env).second.trim())
        log("cargo: " + runCmd(listOf(cargo, "--version"), env).second.trim())

        // --- compile ---------------------------------------------------------------------------
        val buildEnv = HashMap(env)
        buildEnv["CARGO_TARGET_AARCH64_LINUX_ANDROID_LINKER"] = linker.path
        buildEnv["CC_aarch64_linux_android"] = linker.path
        buildEnv["AR_aarch64_linux_android"] = ar.path
        buildEnv["CARGO_TARGET_DIR"] = cargoTargetDir.path
        val (rc2, out2) = runCmd(
            listOf(cargo, "build", "--release", "--locked", "--target", rustTarget, "--manifest-path", File(rustDir, "Cargo.toml").path),
            buildEnv,
        )
        println(out2)
        if (rc2 != 0) fail("cargo build failed (rc=$rc2)")

        // --- verify + stage --------------------------------------------------------------------
        val built = File(cargoTargetDir, "$rustTarget/release/libslimpy.so")
        elfProblem(built)?.let { fail("built library invalid: $it") }
        val expectedSymbol = "Java_com_slimpy_app_NativeBridge_nativeApiVersion"
        if (!String(built.readBytes(), Charsets.ISO_8859_1).contains(expectedSymbol))
            fail("built library does not contain expected JNI symbol $expectedSymbol")
        val staged = File(rustOutDir, "arm64-v8a/libslimpy.so")
        staged.parentFile.mkdirs()
        built.copyTo(staged, overwrite = true)
        log("libslimpy.so: OK (ELF64 little-endian ET_DYN EM_AARCH64), ${staged.length()} bytes, sha256 ${sha256Hex(staged)}")
        reportDir.mkdirs()
        File(reportDir, "slimpy_build_report.txt").writeText(report.toString())
    }
}

tasks.matching { it.name == "preBuild" }.configureEach { dependsOn(buildRustArm64) }

// ---------------------------------------------------------------------------------------------
// Task 2: verify the finished APK really contains the arm64 library (and nothing for other ABIs).
// ---------------------------------------------------------------------------------------------
val verifySlimpyApk = tasks.register("verifySlimpyApk") {
    group = "slimpy"
    doLast {
        val apks = layout.buildDirectory.dir("outputs/apk").get().asFile
            .walkTopDown().filter { it.isFile && it.extension == "apk" }.toList()
        if (apks.isEmpty()) throw GradleException("verifySlimpyApk: no APK found under build/outputs/apk")
        for (apk in apks) {
            ZipFile(apk).use { z ->
                val libs = z.entries().asSequence().map { it.name }.filter { it.startsWith("lib/") }.toList()
                println("[slimpy-poc] ${apk.name}: native entries = $libs")
                if ("lib/arm64-v8a/libslimpy.so" !in libs)
                    throw GradleException("verifySlimpyApk: ${apk.name} lacks lib/arm64-v8a/libslimpy.so")
                val other = libs.filter { !it.startsWith("lib/arm64-v8a/") }
                if (other.isNotEmpty()) throw GradleException("verifySlimpyApk: unexpected non-arm64 libs: $other")
            }
        }
        println("[slimpy-poc] APK verification: OK")
    }
}

tasks.matching { it.name == "assembleDebug" || it.name == "assembleRelease" }
    .configureEach { finalizedBy(verifySlimpyApk) }
